#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

if [[ -d "/Applications/Xcode-beta.app/Contents/Developer" ]]; then
  export DEVELOPER_DIR="/Applications/Xcode-beta.app/Contents/Developer"
fi

BUILD_ROOT="${TMPDIR:-/tmp}/travelbill-macos-swift-build"
swift build --disable-sandbox --scratch-path "$BUILD_ROOT" -c debug
EXECUTABLE="$(find "$BUILD_ROOT" -type f \( -path '*/debug/TravelBillMac' -o -path '*/Products/Debug/TravelBillMac' \) -perm -111 -print -quit)"
if [[ -z "$EXECUTABLE" ]]; then
  print -u2 "找不到 TravelBillMac 可执行文件"
  exit 1
fi

APP_DIR="${1:-$SCRIPT_DIR/dist/旅迹账单.app}"
RUNTIME_DIR="$HOME/Library/Application Support/旅迹账单/runtime"
STAGE_ROOT="${TMPDIR:-/tmp}/travelbill-app.$$.stage"
STAGE_APP="$STAGE_ROOT/旅迹账单.app"
mkdir -p "$STAGE_APP/Contents/MacOS" "$STAGE_APP/Contents/Resources"
cp "$EXECUTABLE" "$STAGE_APP/Contents/MacOS/TravelBillMac"
cp "$SCRIPT_DIR/Info.plist" "$STAGE_APP/Contents/Info.plist"

# Mac App 与 iOS App 共用同一张源图标，避免标题栏和 Finder 图标出现两套视觉。
ICON_SOURCE="$SCRIPT_DIR/../ios/TravelBillApp/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png"
if [[ ! -f "$ICON_SOURCE" ]]; then
  print -u2 "找不到 iOS App 图标：$ICON_SOURCE"
  exit 1
fi
ICONSET_DIR="${TMPDIR:-/tmp}/travelbill-appicon.$$.iconset"
mkdir -p "$ICONSET_DIR"
trap 'rm -rf "$ICONSET_DIR" "$STAGE_ROOT"' EXIT
for spec in \
  "16x16 16" "16x16@2x 32" "32x32 32" "32x32@2x 64" \
  "128x128 128" "128x128@2x 256" "256x256 256" "256x256@2x 512" \
  "512x512 512" "512x512@2x 1024"; do
  name="${spec%% *}"
  size="${spec#* }"
  sips -z "$size" "$size" "$ICON_SOURCE" --out "$ICONSET_DIR/icon_${name}.png" >/dev/null
done
if ! iconutil -c icns "$ICONSET_DIR" -o "$STAGE_APP/Contents/Resources/AppIcon.icns"; then
  EXISTING_ICON="$APP_DIR/Contents/Resources/AppIcon.icns"
  if [[ -f "$EXISTING_ICON" ]]; then
    cp "$EXISTING_ICON" "$STAGE_APP/Contents/Resources/AppIcon.icns"
  else
    print -u2 "无法生成 Mac 图标，且没有可复用的现有图标"
    exit 1
  fi
fi
chmod +x "$STAGE_APP/Contents/MacOS/TravelBillMac"
xattr -cr "$STAGE_APP"
codesign --force --deep --sign - "$STAGE_APP" >/dev/null
codesign --verify --deep --strict "$STAGE_APP"

# iCloud Drive 可能给目标目录重新附加 FinderInfo；先清理旧包，再以不携带扩展属性的方式复制。
rm -rf "$APP_DIR"
ditto --norsrc --noextattr --noacl "$STAGE_APP" "$APP_DIR"
xattr -cr "$APP_DIR"
if codesign --verify --deep --strict "$APP_DIR" >/dev/null 2>&1; then
  print "已生成并完成签名核验：$APP_DIR"
else
  print "已生成：$APP_DIR（iCloud Drive 正在同步，签名核验暂缓）"
fi

# 应用运行时放在本机 Application Support，避免每次打开都从 iCloud Drive
# 逐个下载 Node 组件。data 目录单独保留，更新应用不会覆盖本机账单数据。
mkdir -p "$RUNTIME_DIR" "$RUNTIME_DIR/data"
rsync -a --delete \
  --exclude '/data/' --exclude '/.git/' --exclude '/.build/' \
  --exclude '/ios/' --exclude '/macos/' --exclude '/test/' \
  --exclude '/.ocr-cache/' --exclude '/node_modules/' \
  --exclude '/travel-bill-source.tar.gz' \
  "$SCRIPT_DIR/../" "$RUNTIME_DIR/"
(
  cd "$RUNTIME_DIR"
  /Users/jcz/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm install --prod --frozen-lockfile --ignore-scripts
)
if [[ ! -f "$RUNTIME_DIR/data/travel-bill-server.json" && -f "$SCRIPT_DIR/../data/travel-bill-server.json" ]]; then
  cp "$SCRIPT_DIR/../data/travel-bill-server.json" "$RUNTIME_DIR/data/travel-bill-server.json"
fi
print "本机运行组件已就绪：$RUNTIME_DIR"
