import AppKit
import Foundation
import MapKit
import SwiftUI
import WebKit

private let defaultAppRoot = FileManager.default.homeDirectoryForCurrentUser
    .appendingPathComponent("Library/Application Support/旅迹账单/runtime", isDirectory: true).path
private let defaultNodeBinary = "/Users/jcz/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
private let localServerURL = URL(string: "http://127.0.0.1:4174")!
private let accountAPIBaseURL = "https://travel-bill-api.onrender.com"

struct MacFootprintPlace: Identifiable, Equatable {
    let id: String
    let country: String
    let region: String
    let city: String
    let locationName: String
    let latitude: CLLocationDegrees
    let longitude: CLLocationDegrees
    let mediaCount: Int

    init?(dictionary: [String: Any]) {
        let latitude = (dictionary["latitude"] as? NSNumber)?.doubleValue ?? (dictionary["latitude"] as? Double)
        let longitude = (dictionary["longitude"] as? NSNumber)?.doubleValue ?? (dictionary["longitude"] as? Double)
        guard let latitude, let longitude,
              latitude.isFinite, longitude.isFinite,
              (-90...90).contains(latitude), (-180...180).contains(longitude) else { return nil }

        func string(_ key: String) -> String { (dictionary[key] as? String) ?? "" }
        self.id = string("id").isEmpty ? "\(latitude),\(longitude),\(string("city"))" : string("id")
        self.country = string("country")
        self.region = string("region")
        self.city = string("city")
        self.locationName = string("locationName")
        self.latitude = latitude
        self.longitude = longitude
        self.mediaCount = (dictionary["mediaCount"] as? NSNumber)?.intValue ?? (dictionary["mediaCount"] as? Int ?? 0)
    }

    var label: String {
        [country, region, city.isEmpty ? locationName : city]
            .filter { !$0.isEmpty }
            .joined(separator: " · ")
    }
}

@main
struct TravelBillMacApp: App {
    @StateObject private var server = LocalServerController()
    @State private var selectedTab: MacTab = .personal

    var body: some Scene {
        WindowGroup {
            MacShell(selectedTab: $selectedTab)
                .environmentObject(server)
                .frame(minWidth: 1120, minHeight: 720)
        }
        .windowStyle(.hiddenTitleBar)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("重新载入账单") { NotificationCenter.default.post(name: .travelBillReload, object: nil) }
                    .keyboardShortcut("r", modifiers: [.command])
            }
        }
    }
}

private extension Notification.Name {
    static let travelBillReload = Notification.Name("TravelBillMac.reload")
}

@MainActor
final class LocalServerController: ObservableObject {
    @Published private(set) var isReady = false
    @Published private(set) var status = "正在启动本地服务…"

    private let port = 4174
    private var process: Process?
    private var pollTimer: Timer?
    private var startupDeadline: Date?
    private var automaticRestartCount = 0

    var appRoot: String {
        ProcessInfo.processInfo.environment["TRAVEL_BILL_APP_ROOT"] ?? defaultAppRoot
    }

    init() {
        start()
    }

    deinit {
        pollTimer?.invalidate()
        process?.terminate()
    }

    func start() {
        guard process == nil else {
            pollServer()
            return
        }
        isReady = false
        status = "正在启动本地服务…"
        startupDeadline = Date().addingTimeInterval(12)

        let child = Process()
        child.executableURL = URL(fileURLWithPath: ProcessInfo.processInfo.environment["TRAVEL_BILL_NODE_BIN"] ?? defaultNodeBinary)
        child.arguments = ["server.mjs"]
        child.currentDirectoryURL = URL(fileURLWithPath: appRoot, isDirectory: true)
        child.environment = [
            // iPhone 真机需要通过同一 Wi‑Fi 访问 Mac 服务；健康检查仍走 127.0.0.1。
            "HOST": "0.0.0.0",
            "PORT": String(port),
            "AUTO_OPEN": "0",
            "APPLE_AUTH_MODE": "development",
        ]
        let logDirectory = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Logs/旅迹账单", isDirectory: true)
        try? FileManager.default.createDirectory(at: logDirectory, withIntermediateDirectories: true)
        let logURL = logDirectory.appendingPathComponent("server.log")
        if !FileManager.default.fileExists(atPath: logURL.path) {
            FileManager.default.createFile(atPath: logURL.path, contents: nil)
        }
        let logHandle = try? FileHandle(forWritingTo: logURL)
        _ = try? logHandle?.seekToEnd()
        child.standardOutput = logHandle ?? FileHandle.nullDevice
        child.standardError = logHandle ?? FileHandle.nullDevice
        child.terminationHandler = { [weak self] _ in
            Task { @MainActor in
                guard let self, self.process === child else { return }
                self.process = nil
                self.status = "正在连接本机服务…"
                // 端口上可能已有上一实例留下的健康服务。先做健康检查，
                // 避免新进程因端口占用退出后把可用界面误判成故障。
                self.pollServer()
            }
        }
        do {
            try child.run()
            process = child
            pollServer()
        } catch {
            status = "本地服务启动失败：\(error.localizedDescription)"
        }
    }

    func restart() {
        pollTimer?.invalidate()
        pollTimer = nil
        process?.terminate()
        process = nil
        isReady = false
        status = "正在重新启动本地服务…"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in self?.start() }
    }

    private func pollServer() {
        pollTimer?.invalidate()
        pollTimer = Timer.scheduledTimer(withTimeInterval: 0.45, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.checkHealth() }
        }
        checkHealth()
    }

    private func checkHealth() {
        var request = URLRequest(url: localServerURL.appendingPathComponent("api/health"))
        request.timeoutInterval = 1.2
        request.cachePolicy = .reloadIgnoringLocalCacheData
        URLSession.shared.dataTask(with: request) { [weak self] _, response, _ in
            let healthy = (response as? HTTPURLResponse)?.statusCode == 200
            Task { @MainActor in
                guard let self else { return }
                if healthy {
                    self.isReady = true
                    self.status = "本机服务已启动"
                    self.automaticRestartCount = 0
                    self.startupDeadline = nil
                    self.pollTimer?.invalidate()
                    self.pollTimer = nil
                } else if self.process == nil || self.process?.isRunning == false {
                    self.status = "本地服务意外停止，正在自动恢复…"
                    self.scheduleAutomaticRestart()
                } else if let deadline = self.startupDeadline, Date() >= deadline {
                    self.status = "本地服务启动超时，正在自动恢复…"
                    self.process?.terminationHandler = nil
                    self.process?.terminate()
                    self.process = nil
                    self.scheduleAutomaticRestart()
                }
            }
        }.resume()
    }

    private func scheduleAutomaticRestart() {
        guard automaticRestartCount < 3 else {
            pollTimer?.invalidate()
            pollTimer = nil
            status = "本地服务无法启动，请重新打开应用"
            return
        }
        automaticRestartCount += 1
        pollTimer?.invalidate()
        pollTimer = nil
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in self?.start() }
    }

}

enum MacTab: String, CaseIterable, Identifiable {
    case personal, friends, footprints, me

    var id: String { rawValue }
    var title: String {
        switch self {
        case .personal: "个人账单"
        case .friends: "好友账单"
        case .footprints: "我的足迹"
        case .me: "我的"
        }
    }
    var symbol: String {
        switch self {
        case .personal: "person.crop.circle.fill"
        case .friends: "person.2.fill"
        case .footprints: "map.fill"
        case .me: "person.fill"
        }
    }
}

struct MacShell: View {
    @EnvironmentObject private var server: LocalServerController
    @Environment(\.colorScheme) private var colorScheme
    @Binding var selectedTab: MacTab
    @State private var footprintPlaces: [MacFootprintPlace] = []

    var body: some View {
        ZStack {
            LinearGradient(
                colors: colorScheme == .dark
                    ? [Color(red: 0.025, green: 0.035, blue: 0.045), Color(red: 0.08, green: 0.13, blue: 0.15)]
                    : [Color(red: 0.96, green: 0.99, blue: 1.0), Color(red: 0.86, green: 0.96, blue: 0.98)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                MacHeader()
                Divider().opacity(0.45)

                ZStack(alignment: .bottom) {
                    if server.isReady {
                        ZStack {
                            MacWebView(selectedTab: $selectedTab, footprintPlaces: $footprintPlaces)
                                .opacity(selectedTab == .footprints ? 0.001 : 1)
                                .allowsHitTesting(selectedTab != .footprints)
                                .frame(maxWidth: .infinity, maxHeight: .infinity)

                            if selectedTab == .footprints {
                                MacFootprintPage(places: footprintPlaces)
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                            }
                        }
                    } else {
                        MacLaunchCard(status: server.status, retry: server.restart)
                    }

                    MacTabBar(selectedTab: $selectedTab)
                        .padding(.bottom, 18)
                }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .travelBillReload)) { _ in
            selectedTab = selectedTab
        }
    }
}

struct MacHeader: View {
    @EnvironmentObject private var server: LocalServerController
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        MacGlassSurface(cornerRadius: 22) {
            HStack(spacing: 14) {
                ZStack {
                    if let appIcon = NSImage(named: NSImage.applicationIconName) {
                        Image(nsImage: appIcon)
                            .resizable()
                            .scaledToFit()
                            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    } else {
                        Image(systemName: "map.fill")
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundStyle(Color(red: 0.24, green: 0.62, blue: 0.72))
                    }
                }
                .frame(width: 48, height: 48)
                .shadow(color: .black.opacity(0.08), radius: 12, y: 6)

                VStack(alignment: .leading, spacing: 2) {
                    Text("旅迹账单")
                        .font(.system(size: 27, weight: .bold, design: .rounded))
                        .foregroundStyle(colorScheme == .dark ? Color.white.opacity(0.94) : Color(red: 0.14, green: 0.23, blue: 0.29))
                    Text("旅行账单与 Excel")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                HStack(spacing: 8) {
                    Circle()
                        .fill(server.isReady ? Color.green : Color.orange)
                        .frame(width: 8, height: 8)
                    Text(server.isReady ? "本机服务已启动" : "正在连接")
                        .font(.system(size: 11, weight: .medium))
                }
                .padding(.horizontal, 13)
                .padding(.vertical, 9)
                .background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.72), lineWidth: 1))

            }
            .padding(.horizontal, 22)
            .padding(.vertical, 13)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
    }
}

struct MacLaunchCard: View {
    let status: String
    let retry: () -> Void

    var body: some View {
        VStack(spacing: 15) {
            Image(systemName: "sparkles.rectangle.stack")
                .font(.system(size: 35, weight: .light))
                .foregroundStyle(Color(red: 0.27, green: 0.65, blue: 0.74))
            Text("正在准备旅迹账单")
                .font(.system(size: 24, weight: .bold, design: .rounded))
            Text(status)
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
            Button("重新连接") { retry() }
                .buttonStyle(.borderedProminent)
                .tint(Color(red: 0.48, green: 0.82, blue: 0.88))
        }
        .padding(48)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.8), lineWidth: 1))
        .shadow(color: .black.opacity(0.10), radius: 28, y: 14)
    }
}

struct MacTabBar: View {
    @Binding var selectedTab: MacTab
    @Namespace private var tabNamespace
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        MacGlassSurface(cornerRadius: 26) {
            HStack(spacing: 6) {
                ForEach(MacTab.allCases) { tab in
                    Button {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
                            selectedTab = tab
                        }
                    } label: {
                        ZStack {
                            if selectedTab == tab {
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(Color(red: 0.74, green: 0.95, blue: 0.98).opacity(colorScheme == .dark ? 0.32 : 0.86))
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    .matchedGeometryEffect(id: "mac-tab-selection", in: tabNamespace)
                            }
                            VStack(spacing: 5) {
                                Image(systemName: tab.symbol)
                                    .font(.system(size: 20, weight: .semibold))
                                Text(tab.title)
                                    .font(.system(size: 11, weight: .medium))
                            }
                            .padding(.vertical, 11)
                        }
                        .frame(maxWidth: .infinity, minHeight: 62, maxHeight: 62)
                        .foregroundStyle(selectedTab == tab ? Color(red: 0.12, green: 0.52, blue: 0.64) : (colorScheme == .dark ? Color.white.opacity(0.64) : Color.secondary))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(8)
            .frame(height: 78)
        }
        .frame(width: 600)
        .shadow(color: Color(red: 0.25, green: 0.55, blue: 0.62).opacity(0.20), radius: 25, y: 12)
    }
}

private struct MacGlassSurface<Content: View>: View {
    let cornerRadius: CGFloat
    let content: Content

    init(cornerRadius: CGFloat, @ViewBuilder content: () -> Content) {
        self.cornerRadius = cornerRadius
        self.content = content()
    }

    @ViewBuilder
    var body: some View {
        if #available(macOS 26.0, *) {
            content
                .glassEffect(.regular.interactive(), in: .rect(cornerRadius: cornerRadius))
                .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).stroke(Color.white.opacity(0.78), lineWidth: 1))
        } else {
            content
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).stroke(Color.white.opacity(0.82), lineWidth: 1))
        }
    }
}

private struct MacFootprintPage: View {
    let places: [MacFootprintPlace]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("我的足迹")
                            .font(.system(size: 31, weight: .bold, design: .rounded))
                        Text("根据聊天中发送的照片和视频定位自动整理")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text("\(places.count) 个地点")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Color(red: 0.18, green: 0.58, blue: 0.68))
                }

                ZStack {
                    MacAppleMapView(places: places)
                        .frame(maxWidth: .infinity, minHeight: 360, maxHeight: 500)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 24, style: .continuous)
                                .stroke(Color.white.opacity(0.68), lineWidth: 1)
                        }

                    if places.isEmpty {
                        Text("发送带定位信息的照片或视频后，这里会显示国家、地区和城市。")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 18)
                            .padding(.vertical, 12)
                            .background(.regularMaterial, in: Capsule())
                    }
                }

                if !places.isEmpty {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 190), spacing: 10)], spacing: 10) {
                        ForEach(places) { place in
                            HStack(spacing: 9) {
                                Image(systemName: "mappin.circle.fill")
                                    .foregroundStyle(Color(red: 0.18, green: 0.58, blue: 0.68))
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(place.label.isEmpty ? "已定位地点" : place.label)
                                        .font(.system(size: 12, weight: .semibold))
                                        .lineLimit(2)
                                    Text("\(place.mediaCount) 个媒体")
                                        .font(.system(size: 11))
                                        .foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 0)
                            }
                            .padding(11)
                            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                        }
                    }
                }
            }
            .padding(.horizontal, 30)
            .padding(.top, 26)
            .padding(.bottom, 112)
        }
        .scrollIndicators(.hidden)
    }
}

private struct MacAppleMapView: NSViewRepresentable {
    let places: [MacFootprintPlace]

    func makeNSView(context: Context) -> MKMapView {
        let mapView = MKMapView(frame: .zero)
        mapView.mapType = .standard
        mapView.pointOfInterestFilter = nil
        mapView.showsCompass = true
        mapView.showsScale = true
        mapView.showsBuildings = true
        mapView.isRotateEnabled = false
        mapView.isPitchEnabled = false
        updateNSView(mapView, context: context)
        DispatchQueue.main.async {
            updateNSView(mapView, context: context)
        }
        return mapView
    }

    func updateNSView(_ mapView: MKMapView, context: Context) {
        let oldAnnotations = mapView.annotations.filter { !($0 is MKUserLocation) }
        mapView.removeAnnotations(oldAnnotations)

        let annotations = places.map { place -> MKPointAnnotation in
            let annotation = MKPointAnnotation()
            annotation.coordinate = CLLocationCoordinate2D(latitude: place.latitude, longitude: place.longitude)
            annotation.title = place.city.isEmpty ? (place.locationName.isEmpty ? "足迹" : place.locationName) : place.city
            annotation.subtitle = place.label
            return annotation
        }
        mapView.addAnnotations(annotations)

        if annotations.isEmpty {
            let world = MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: 25, longitude: 105),
                span: MKCoordinateSpan(latitudeDelta: 105, longitudeDelta: 220)
            )
            mapView.setRegion(world, animated: false)
            DispatchQueue.main.async {
                mapView.setRegion(world, animated: false)
            }
        } else {
            let latitudes = annotations.map { $0.coordinate.latitude }
            let longitudes = annotations.map { $0.coordinate.longitude }
            let minLatitude = latitudes.min() ?? 0
            let maxLatitude = latitudes.max() ?? 0
            let minLongitude = longitudes.min() ?? 0
            let maxLongitude = longitudes.max() ?? 0
            let latitudeDelta = max(8, min(160, (maxLatitude - minLatitude) * 1.55))
            let longitudeDelta = max(8, min(320, (maxLongitude - minLongitude) * 1.55))
            let region = MKCoordinateRegion(
                center: CLLocationCoordinate2D(
                    latitude: (minLatitude + maxLatitude) / 2,
                    longitude: (minLongitude + maxLongitude) / 2
                ),
                span: MKCoordinateSpan(latitudeDelta: latitudeDelta, longitudeDelta: longitudeDelta)
            )
            mapView.setRegion(region, animated: false)
            DispatchQueue.main.async {
                mapView.setRegion(region, animated: false)
            }
        }
    }
}

struct MacWebView: NSViewRepresentable {
    @Binding var selectedTab: MacTab
    @Binding var footprintPlaces: [MacFootprintPlace]

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeNSView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        let accountBaseScript = WKUserScript(
            source: "window.travelBillAPIBase = \"\(accountAPIBaseURL)\";",
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        )
        configuration.userContentController.addUserScript(accountBaseScript)
        configuration.userContentController.add(context.coordinator, name: "footprintBridge")
        configuration.userContentController.add(context.coordinator, name: "tripContextMenu")
        configuration.userContentController.addUserScript(WKUserScript(
            source: """
            document.addEventListener('contextmenu', event => {
              const personal = event.target.closest('[data-open-personal-trip]');
              const group = event.target.closest('[data-open-group-trip]');
              const row = personal || group;
              if (!row) return;
              event.preventDefault();
              event.stopPropagation();
              window.webkit.messageHandlers.tripContextMenu.postMessage({
                kind: group ? 'group' : 'personal',
                id: group ? group.dataset.openGroupTrip : personal.dataset.openPersonalTrip
              });
            }, true);
            """,
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: true
        ))
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.customUserAgent = "TravelBillMacApp/1.0 macOS"
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.setValue(false, forKey: "drawsBackground")
        webView.allowsMagnification = true
        context.coordinator.webView = webView
        let placesBinding = $footprintPlaces
        context.coordinator.onFootprints = { places in
            DispatchQueue.main.async {
                placesBinding.wrappedValue = places
            }
        }
        context.coordinator.loadIfNeeded()
        return webView
    }

    func updateNSView(_ webView: WKWebView, context: Context) {
        context.coordinator.select(tab: selectedTab)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        weak var webView: WKWebView?
        var onFootprints: (([MacFootprintPlace]) -> Void)?
        private var lastTab: MacTab?
        private var loaded = false
        private var pendingTripKind = ""
        private var pendingTripID = ""

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "tripContextMenu",
               let payload = message.body as? [String: Any],
               let kind = payload["kind"] as? String,
               let id = payload["id"] as? String,
               let webView {
                pendingTripKind = kind
                pendingTripID = id
                let menu = NSMenu(title: "账单操作")
                let editItem = NSMenuItem(title: "修改名称与封面…", action: #selector(editPendingTrip), keyEquivalent: "")
                editItem.image = NSImage(systemSymbolName: "pencil", accessibilityDescription: "修改旅行")
                editItem.target = self
                menu.addItem(editItem)
                menu.addItem(.separator())
                let deleteItem = NSMenuItem(title: "删除账单", action: #selector(deletePendingTrip), keyEquivalent: "")
                deleteItem.image = NSImage(systemSymbolName: "trash", accessibilityDescription: "删除账单")
                deleteItem.target = self
                menu.addItem(deleteItem)
                let windowPoint = webView.window?.convertPoint(fromScreen: NSEvent.mouseLocation) ?? .zero
                menu.popUp(positioning: editItem, at: webView.convert(windowPoint, from: nil), in: webView)
                return
            }
            guard message.name == "footprintBridge",
                  let payload = message.body as? [String: Any],
                  let rawPlaces = payload["places"] as? [[String: Any]] else { return }
            let places = rawPlaces.compactMap(MacFootprintPlace.init(dictionary:))
            onFootprints?(places)
        }

        @objc private func deletePendingTrip() {
            guard !pendingTripKind.isEmpty, !pendingTripID.isEmpty else { return }
            let kind = pendingTripKind.replacingOccurrences(of: "'", with: "")
            let id = pendingTripID.replacingOccurrences(of: "'", with: "")
            webView?.evaluateJavaScript("window.travelBillDeleteTrip?.('\(kind)','\(id)')")
            pendingTripKind = ""
            pendingTripID = ""
        }

        @objc private func editPendingTrip() {
            guard !pendingTripKind.isEmpty, !pendingTripID.isEmpty else { return }
            let kind = pendingTripKind.replacingOccurrences(of: "'", with: "")
            let id = pendingTripID.replacingOccurrences(of: "'", with: "")
            webView?.evaluateJavaScript("window.travelBillEditTrip?.('\(kind)','\(id)')")
            pendingTripKind = ""
            pendingTripID = ""
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            let alert = NSAlert()
            alert.messageText = "确认删除"
            alert.informativeText = message
            alert.alertStyle = .warning
            alert.addButton(withTitle: "删除")
            alert.addButton(withTitle: "取消")
            completionHandler(alert.runModal() == .alertFirstButtonReturn)
        }

        func loadIfNeeded() {
            guard let webView, !loaded else { return }
            loaded = true
            webView.load(URLRequest(url: localServerURL))
        }

        func select(tab: MacTab) {
            guard loaded, lastTab != tab else { return }
            lastTab = tab
            let rawTab = tab.rawValue
            let script = """
            (() => {
              const activate = () => {
                if (window.travelBillSetTab) {
                  window.travelBillSetTab('\(rawTab)');
                  return true;
                }
                const button = document.querySelector('[data-app-tab="\(rawTab)"]');
                if (button) { button.click(); return true; }
                return false;
              };
              activate();
              setTimeout(activate, 300);
              setTimeout(activate, 900);
            })();
            """
            webView?.evaluateJavaScript(script)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            let css = """
            (() => {
              const style = document.createElement('style');
              style.id = 'travel-bill-mac-style';
              style.textContent = '.topbar{display:none!important} .app-tabbar{display:none!important} body{padding-bottom:22px!important} .page-shell{width:calc(100% - 56px)!important; max-width:none!important; grid-template-columns:minmax(0,1fr)!important; padding-bottom:22px!important; margin-top:22px!important} .workspace{max-width:none!important} .footprint-map{min-height:280px!important} .footprint-map svg{height:280px!important}';
              document.head.appendChild(style);
            })();
            """
            webView.evaluateJavaScript(css)
            lastTab = nil
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in
                self?.select(tab: .personal)
            }
        }

        func webView(
            _ webView: WKWebView,
            runOpenPanelWith parameters: WKOpenPanelParameters,
            initiatedByFrame frame: WKFrameInfo,
            completionHandler: @escaping ([URL]?) -> Void
        ) {
            let panel = NSOpenPanel()
            panel.canChooseFiles = true
            panel.canChooseDirectories = false
            panel.allowsMultipleSelection = parameters.allowsMultipleSelection
            panel.canCreateDirectories = false
            panel.begin { response in
                completionHandler(response == .OK ? panel.urls : nil)
            }
        }
    }
}
