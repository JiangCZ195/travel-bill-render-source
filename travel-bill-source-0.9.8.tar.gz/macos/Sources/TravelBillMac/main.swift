import AppKit
import Foundation
import SwiftUI
import WebKit

private let defaultAppRoot = "/Users/jcz/Library/Mobile Documents/com~apple~CloudDocs/旅游账单/travel-bill-app"
private let defaultNodeBinary = "/Users/jcz/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
private let localServerURL = URL(string: "http://127.0.0.1:4174")!
private let accountAPIBaseURL = "https://travel-bill-api.onrender.com"

@main
struct TravelBillMacApp: App {
    @StateObject private var server = LocalServerController()
    @State private var selectedTab: MacTab = .personal

    var body: some Scene {
        WindowGroup {
            MacShell(selectedTab: $selectedTab)
                .environmentObject(server)
                .frame(minWidth: 1120, minHeight: 720)
        }
        .windowStyle(.hiddenTitleBar)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("重新载入账单") { NotificationCenter.default.post(name: .travelBillReload, object: nil) }
                    .keyboardShortcut("r", modifiers: [.command])
            }
        }
    }
}

private extension Notification.Name {
    static let travelBillReload = Notification.Name("TravelBillMac.reload")
}

@MainActor
final class LocalServerController: ObservableObject {
    @Published private(set) var isReady = false
    @Published private(set) var status = "正在启动本地服务…"

    private let port = 4174
    private var process: Process?
    private var pollTimer: Timer?

    var appRoot: String {
        ProcessInfo.processInfo.environment["TRAVEL_BILL_APP_ROOT"] ?? defaultAppRoot
    }

    init() {
        start()
    }

    deinit {
        pollTimer?.invalidate()
        process?.terminate()
    }

    func start() {
        guard process == nil else {
            pollServer()
            return
        }
        isReady = false
        status = "正在启动本地服务…"

        let child = Process()
        child.executableURL = URL(fileURLWithPath: ProcessInfo.processInfo.environment["TRAVEL_BILL_NODE_BIN"] ?? defaultNodeBinary)
        child.arguments = ["server.mjs"]
        child.currentDirectoryURL = URL(fileURLWithPath: appRoot, isDirectory: true)
        child.environment = [
            // iPhone 真机需要通过同一 Wi‑Fi 访问 Mac 服务；健康检查仍走 127.0.0.1。
            "HOST": "0.0.0.0",
            "PORT": String(port),
            "AUTO_OPEN": "0",
            "APPLE_AUTH_MODE": "development",
        ]
        child.standardOutput = FileHandle.nullDevice
        child.standardError = FileHandle.nullDevice
        do {
            try child.run()
            process = child
            pollServer()
        } catch {
            status = "本地服务启动失败：\(error.localizedDescription)"
        }
    }

    func restart() {
        pollTimer?.invalidate()
        pollTimer = nil
        process?.terminate()
        process = nil
        isReady = false
        status = "正在重新启动本地服务…"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in self?.start() }
    }

    private func pollServer() {
        pollTimer?.invalidate()
        pollTimer = Timer.scheduledTimer(withTimeInterval: 0.45, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.checkHealth() }
        }
        checkHealth()
    }

    private func checkHealth() {
        var request = URLRequest(url: localServerURL.appendingPathComponent("api/health"))
        request.timeoutInterval = 1.2
        request.cachePolicy = .reloadIgnoringLocalCacheData
        URLSession.shared.dataTask(with: request) { [weak self] _, response, _ in
            let healthy = (response as? HTTPURLResponse)?.statusCode == 200
            Task { @MainActor in
                guard let self else { return }
                if healthy {
                    self.isReady = true
                    self.status = "本机服务已启动"
                    self.pollTimer?.invalidate()
                    self.pollTimer = nil
                } else if self.process?.isRunning == false {
                    self.status = "本地服务已退出，请点击重启"
                }
            }
        }.resume()
    }

}

enum MacTab: String, CaseIterable, Identifiable {
    case personal, friends, footprints, me

    var id: String { rawValue }
    var title: String {
        switch self {
        case .personal: "个人账单"
        case .friends: "好友账单"
        case .footprints: "我的足迹"
        case .me: "我的"
        }
    }
    var symbol: String {
        switch self {
        case .personal: "person.crop.circle"
        case .friends: "person.2"
        case .footprints: "map"
        case .me: "person"
        }
    }
}

struct MacShell: View {
    @EnvironmentObject private var server: LocalServerController
    @Environment(\.colorScheme) private var colorScheme
    @Binding var selectedTab: MacTab

    var body: some View {
        ZStack {
            LinearGradient(
                colors: colorScheme == .dark
                    ? [Color(red: 0.025, green: 0.035, blue: 0.045), Color(red: 0.08, green: 0.13, blue: 0.15)]
                    : [Color(red: 0.96, green: 0.99, blue: 1.0), Color(red: 0.86, green: 0.96, blue: 0.98)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                MacHeader()
                Divider().opacity(0.45)

                ZStack(alignment: .bottom) {
                    if server.isReady {
                        MacWebView(selectedTab: $selectedTab)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                    } else {
                        MacLaunchCard(status: server.status, retry: server.restart)
                    }

                    MacTabBar(selectedTab: $selectedTab)
                        .padding(.bottom, 18)
                }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .travelBillReload)) { _ in
            selectedTab = selectedTab
        }
    }
}

struct MacHeader: View {
    @EnvironmentObject private var server: LocalServerController
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        MacGlassSurface(cornerRadius: 22) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .fill((colorScheme == .dark ? Color.white.opacity(0.12) : Color.white.opacity(0.72)))
                    Image(systemName: "map.fill")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(Color(red: 0.24, green: 0.62, blue: 0.72))
                }
                .frame(width: 48, height: 48)
                .shadow(color: .black.opacity(0.08), radius: 12, y: 6)

                VStack(alignment: .leading, spacing: 2) {
                    Text("旅迹账单")
                        .font(.system(size: 23, weight: .semibold, design: .serif))
                        .foregroundStyle(colorScheme == .dark ? Color.white.opacity(0.94) : Color(red: 0.14, green: 0.23, blue: 0.29))
                    Text("Mac 版 · 旅行记账与 Excel")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                }

                Spacer()

                HStack(spacing: 8) {
                    Circle()
                        .fill(server.isReady ? Color.green : Color.orange)
                        .frame(width: 8, height: 8)
                    Text(server.isReady ? "本机服务已启动" : "正在连接")
                        .font(.system(size: 11, weight: .medium))
                }
                .padding(.horizontal, 13)
                .padding(.vertical, 9)
                .background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.72), lineWidth: 1))

                Button { server.restart() } label: {
                    Label("重启服务", systemImage: "arrow.clockwise")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(colorScheme == .dark ? Color(red: 0.75, green: 0.92, blue: 0.96) : Color(red: 0.12, green: 0.34, blue: 0.40))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background((colorScheme == .dark ? Color.white.opacity(0.12) : Color.white.opacity(0.78)), in: Capsule())
                        .overlay(Capsule().stroke(Color(red: 0.35, green: 0.69, blue: 0.75).opacity(0.75), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 22)
            .padding(.vertical, 13)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
    }
}

struct MacLaunchCard: View {
    let status: String
    let retry: () -> Void

    var body: some View {
        VStack(spacing: 15) {
            Image(systemName: "sparkles.rectangle.stack")
                .font(.system(size: 35, weight: .light))
                .foregroundStyle(Color(red: 0.27, green: 0.65, blue: 0.74))
            Text("正在准备旅迹账单")
                .font(.system(size: 24, weight: .semibold, design: .serif))
            Text(status)
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
            Button("重新连接") { retry() }
                .buttonStyle(.borderedProminent)
                .tint(Color(red: 0.48, green: 0.82, blue: 0.88))
        }
        .padding(48)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.8), lineWidth: 1))
        .shadow(color: .black.opacity(0.10), radius: 28, y: 14)
    }
}

struct MacTabBar: View {
    @Binding var selectedTab: MacTab
    @Namespace private var tabNamespace
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        MacGlassSurface(cornerRadius: 26) {
            HStack(spacing: 6) {
                ForEach(MacTab.allCases) { tab in
                    Button {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
                            selectedTab = tab
                        }
                    } label: {
                        ZStack {
                            if selectedTab == tab {
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(Color(red: 0.74, green: 0.95, blue: 0.98).opacity(colorScheme == .dark ? 0.32 : 0.86))
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    .matchedGeometryEffect(id: "mac-tab-selection", in: tabNamespace)
                            }
                            VStack(spacing: 5) {
                                Image(systemName: tab.symbol)
                                    .font(.system(size: 18, weight: .medium))
                                Text(tab.title)
                                    .font(.system(size: 11, weight: .semibold))
                            }
                            .padding(.vertical, 11)
                        }
                        .frame(maxWidth: .infinity, minHeight: 62, maxHeight: 62)
                        .foregroundStyle(selectedTab == tab ? Color(red: 0.12, green: 0.52, blue: 0.64) : (colorScheme == .dark ? Color.white.opacity(0.64) : Color.secondary))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(8)
            .frame(height: 78)
        }
        .frame(width: 600)
        .shadow(color: Color(red: 0.25, green: 0.55, blue: 0.62).opacity(0.20), radius: 25, y: 12)
    }
}

private struct MacGlassSurface<Content: View>: View {
    let cornerRadius: CGFloat
    let content: Content

    init(cornerRadius: CGFloat, @ViewBuilder content: () -> Content) {
        self.cornerRadius = cornerRadius
        self.content = content()
    }

    @ViewBuilder
    var body: some View {
        if #available(macOS 26.0, *) {
            content
                .glassEffect(.regular.interactive(), in: .rect(cornerRadius: cornerRadius))
                .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).stroke(Color.white.opacity(0.78), lineWidth: 1))
        } else {
            content
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).stroke(Color.white.opacity(0.82), lineWidth: 1))
        }
    }
}

struct MacWebView: NSViewRepresentable {
    @Binding var selectedTab: MacTab

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeNSView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        let accountBaseScript = WKUserScript(
            source: "window.travelBillAPIBase = \"\(accountAPIBaseURL)\";",
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        )
        configuration.userContentController.addUserScript(accountBaseScript)
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.customUserAgent = "TravelBillMacApp/1.0 macOS"
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.setValue(false, forKey: "drawsBackground")
        webView.allowsMagnification = true
        context.coordinator.webView = webView
        context.coordinator.loadIfNeeded()
        return webView
    }

    func updateNSView(_ webView: WKWebView, context: Context) {
        context.coordinator.select(tab: selectedTab)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        weak var webView: WKWebView?
        private var lastTab: MacTab?
        private var loaded = false

        func loadIfNeeded() {
            guard let webView, !loaded else { return }
            loaded = true
            webView.load(URLRequest(url: localServerURL))
        }

        func select(tab: MacTab) {
            guard loaded, lastTab != tab else { return }
            lastTab = tab
            let rawTab = tab.rawValue
            let script = """
            (() => {
              const activate = () => {
                if (window.travelBillSetTab) {
                  window.travelBillSetTab('\(rawTab)');
                  return true;
                }
                const button = document.querySelector('[data-app-tab="\(rawTab)"]');
                if (button) { button.click(); return true; }
                return false;
              };
              activate();
              setTimeout(activate, 300);
              setTimeout(activate, 900);
            })();
            """
            webView?.evaluateJavaScript(script)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            let css = """
            (() => {
              const style = document.createElement('style');
              style.id = 'travel-bill-mac-style';
              style.textContent = '.topbar{display:none!important} .app-tabbar{display:none!important} body{padding-bottom:22px!important} .page-shell{width:calc(100% - 56px)!important; max-width:none!important; grid-template-columns:minmax(0,1fr)!important; padding-bottom:22px!important; margin-top:22px!important} .workspace{max-width:none!important}';
              document.head.appendChild(style);
            })();
            """
            webView.evaluateJavaScript(css)
            lastTab = nil
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in
                self?.select(tab: .personal)
            }
        }

        func webView(
            _ webView: WKWebView,
            runOpenPanelWith parameters: WKOpenPanelParameters,
            initiatedByFrame frame: WKFrameInfo,
            completionHandler: @escaping ([URL]?) -> Void
        ) {
            let panel = NSOpenPanel()
            panel.canChooseFiles = true
            panel.canChooseDirectories = false
            panel.allowsMultipleSelection = parameters.allowsMultipleSelection
            panel.canCreateDirectories = false
            panel.begin { response in
                completionHandler(response == .OK ? panel.urls : nil)
            }
        }
    }
}
