import Foundation
import ImageIO
import Vision

struct TextLine: Codable {
    let text: String
    let confidence: Float
    let x: Double
    let y: Double
    let width: Double
    let height: Double
}

guard CommandLine.arguments.count >= 2 else {
    FileHandle.standardError.write(Data("缺少图片路径\n".utf8))
    exit(2)
}

let imageURL = URL(fileURLWithPath: CommandLine.arguments[1])
guard let source = CGImageSourceCreateWithURL(imageURL as CFURL, nil),
      let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else {
    FileHandle.standardError.write(Data("无法读取图片\n".utf8))
    exit(3)
}

func recognize(target: CGImage, xOffset: Double = 0, widthScale: Double = 1, minimumTextHeight: Float, numericOnly: Bool = false) throws -> [TextLine] {
    let request = VNRecognizeTextRequest()
    request.recognitionLevel = .accurate
    request.recognitionLanguages = numericOnly ? ["en-US"] : ["zh-Hans", "zh-Hant", "en-US"]
    request.usesLanguageCorrection = !numericOnly
    request.minimumTextHeight = minimumTextHeight
    let handler = VNImageRequestHandler(cgImage: target, options: [:])
    try handler.perform([request])
    return (request.results ?? []).compactMap { observation -> TextLine? in
        guard let candidate = observation.topCandidates(3).max(by: { $0.confidence < $1.confidence }) else { return nil }
        let box = observation.boundingBox
        return TextLine(text: candidate.string, confidence: candidate.confidence, x: xOffset + box.origin.x * widthScale, y: box.origin.y, width: box.width * widthScale, height: box.height)
    }
}

do {
    // 第二遍只看右侧金额栏。账单截图里的金额字号较小，整图识别经常会漏掉。
    let cropStart = Int(Double(image.width) * 0.55)
    let cropWidth = image.width - cropStart
    let rightImage = image.cropping(to: CGRect(x: cropStart, y: 0, width: cropWidth, height: image.height)) ?? image
    let full = try recognize(target: image, minimumTextHeight: 0.004)
    let amountColumn = try recognize(target: rightImage, xOffset: 0.55, widthScale: 0.45, minimumTextHeight: 0.003, numericOnly: true)
    let narrowStart = Int(Double(image.width) * 0.76)
    let narrowImage = image.cropping(to: CGRect(x: narrowStart, y: 0, width: image.width - narrowStart, height: image.height)) ?? image
    let narrowAmounts = try recognize(target: narrowImage, xOffset: 0.76, widthScale: 0.24, minimumTextHeight: 0.003, numericOnly: true)
    var unique: [TextLine] = []
    func isAmountCandidate(_ line: TextLine) -> Bool {
        line.text.range(of: #"^\s*[-−－—–+]\s*[¥￥]?\s*\d{1,7}(?:[.,]\d{1,2})?\s*$"#, options: .regularExpression) != nil
    }
    for line in full + amountColumn.filter(isAmountCandidate) + narrowAmounts.filter(isAmountCandidate) {
        let normalized = line.text.replacingOccurrences(of: " ", with: "")
        let duplicate = unique.contains {
            $0.text.replacingOccurrences(of: " ", with: "") == normalized &&
            abs(($0.y + $0.height / 2) - (line.y + line.height / 2)) < max($0.height, line.height) * 0.8
        }
        if !duplicate { unique.append(line) }
    }
    let lines = unique.sorted { left, right in
        let tolerance = max(left.height, right.height) * 0.55
        if abs(left.y - right.y) > tolerance { return left.y > right.y }
        return left.x < right.x
    }
    let encoder = JSONEncoder()
    let data = try encoder.encode(lines)
    FileHandle.standardOutput.write(data)
} catch {
    FileHandle.standardError.write(Data("Vision OCR 失败：\(error.localizedDescription)\n".utf8))
    exit(4)
}
