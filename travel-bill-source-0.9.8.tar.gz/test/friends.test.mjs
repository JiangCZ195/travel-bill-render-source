import assert from "node:assert/strict";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";

test("独立好友码可以建立好友关系并直接私聊", async () => {
  process.env.TRAVEL_BILL_DATA_DIR = await mkdtemp(path.join(tmpdir(), "travel-bill-friends-"));
  const store = await import(`../lib/account-store.mjs?friends=${Date.now()}`);
  const first = await store.findOrCreateUser({ provider: "test", providerSubject: "first", displayName: "甲" });
  const second = await store.findOrCreateUser({ provider: "test", providerSubject: "second", displayName: "乙" });

  const invite = await store.createFriendInvite(first.id);
  assert.match(invite.code, /^[A-HJ-NP-Z2-9]{8}$/);
  assert.equal(await store.acceptFriendInvite(first.id, invite.code), null, "不能添加自己");
  assert.equal((await store.acceptFriendInvite(second.id, invite.code)).id, first.id);
  assert.equal(await store.acceptFriendInvite(second.id, invite.code), null, "好友码只能使用一次");

  const firstFriends = await store.listFriends(first.id);
  const secondFriends = await store.listFriends(second.id);
  assert.deepEqual(firstFriends.map((friend) => friend.id), [second.id]);
  assert.deepEqual(secondFriends.map((friend) => friend.id), [first.id]);
  assert.equal(firstFriends[0].sharedGroupCount, 0, "好友关系不依赖共同账单");

  const message = await store.createDirectMessage(first.id, second.id, { type: "text", body: "你好" });
  assert.equal(message.body, "你好");

  assert.equal(await store.deleteFriend(first.id, second.id), true);
  assert.deepEqual(await store.listFriends(first.id), []);
  assert.deepEqual(await store.listFriends(second.id), []);
  assert.equal(await store.createDirectMessage(first.id, second.id, { type: "text", body: "已删除" }), null, "删除后不能继续私聊");

  const secondInvite = await store.createFriendInvite(first.id);
  assert.equal((await store.acceptFriendInvite(second.id, secondInvite.code)).id, first.id, "重新添加后恢复好友关系");

  const group = await store.createGroup(first.id, { name: "误建账单" });
  const renamed = await store.updateGroup(first.id, group.id, { name: "修改后的共同旅行", coverMediaId: "cover-group" });
  assert.equal(renamed.name, "修改后的共同旅行");
  assert.equal(renamed.coverMediaId, "cover-group");
  const guest = await store.addGuestParticipant(first.id, group.id, { name: "未安装 App 的朋友" });
  assert.match(guest.id, /^guest:/);
  const groupWithGuest = await store.getGroup(first.id, group.id);
  assert.deepEqual(groupWithGuest.guestParticipants.map((item) => item.name), ["未安装 App 的朋友"]);
  assert.equal((await store.listGroups(first.id)).find((item) => item.id === group.id).participantCount, 2);
  const sharedExpense = await store.createExpense(first.id, group.id, { date: "8月25日", item: "聚餐", category: "吃喝", amountCents: 20000, splitMode: "all", splitParticipants: [first.id, guest.id] });
  assert.deepEqual(sharedExpense.splitParticipants, [first.id, guest.id], "未安装 App 的参与人可进入 AA 分账");
  await assert.rejects(() => store.removeGuestParticipant(first.id, group.id, guest.id), /已有分账记录/);
  assert.equal(await store.archiveGroup(second.id, group.id), false, "非创建者不能删除共同账单");
  assert.equal(await store.archiveGroup(first.id, group.id), true);
  assert.equal((await store.listGroups(first.id)).some((item) => item.id === group.id), false, "删除后不再出现在列表");
  assert.equal(await store.getGroup(first.id, group.id), null, "删除后不能继续打开");

  const personal = await store.createPersonalTrip(first.id, { name: "临时个人旅行" });
  const editedPersonal = await store.updatePersonalTrip(first.id, personal.id, { name: "修改后的个人旅行", coverMediaId: "cover-personal" });
  assert.equal(editedPersonal.name, "修改后的个人旅行");
  assert.equal(editedPersonal.coverMediaId, "cover-personal");
  assert.equal(await store.archivePersonalTrip(first.id, personal.id), true);
  assert.equal((await store.listPersonalTrips(first.id)).some((item) => item.id === personal.id), false);
});
