import Foundation
import ImageIO
import UIKit
@preconcurrency import Vision

enum VisionOCRService {
    static func recognize(_ image: UIImage) async throws -> [RecognizedTextLine] {
        guard let cgImage = image.cgImage else { throw OCRError.invalidImage }
        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    func perform(target: CGImage, xOffset: Double = 0, widthScale: Double = 1, minimumTextHeight: Float, numericOnly: Bool = false) throws -> [RecognizedTextLine] {
                        let request = VNRecognizeTextRequest()
                        request.recognitionLevel = .accurate
                        request.usesLanguageCorrection = !numericOnly
                        request.recognitionLanguages = numericOnly ? ["en-US"] : ["zh-Hans", "zh-Hant", "en-US"]
                        request.minimumTextHeight = minimumTextHeight
                        let handler = VNImageRequestHandler(cgImage: target, orientation: image.cgOrientation)
                        try handler.perform([request])
                        let observations = request.results ?? []
                        return observations.compactMap { observation -> RecognizedTextLine? in
                    guard let candidate = observation.topCandidates(3).max(by: { $0.confidence < $1.confidence }) else { return nil }
                    let box = observation.boundingBox
                    return RecognizedTextLine(
                        text: candidate.string,
                        confidence: candidate.confidence,
                        x: xOffset + box.minX * widthScale,
                        y: box.minY,
                        width: box.width * widthScale,
                        height: box.height
                    )
                }
                    }
                    let cropStart = Int(Double(cgImage.width) * 0.55)
                    let rightImage = cgImage.cropping(to: CGRect(x: cropStart, y: 0, width: cgImage.width - cropStart, height: cgImage.height)) ?? cgImage
                    let full = try perform(target: cgImage, minimumTextHeight: 0.004)
                    let amountColumn = try perform(target: rightImage, xOffset: 0.55, widthScale: 0.45, minimumTextHeight: 0.003, numericOnly: true)
                    let narrowStart = Int(Double(cgImage.width) * 0.76)
                    let narrowImage = cgImage.cropping(to: CGRect(x: narrowStart, y: 0, width: cgImage.width - narrowStart, height: cgImage.height)) ?? cgImage
                    let narrowAmounts = try perform(target: narrowImage, xOffset: 0.76, widthScale: 0.24, minimumTextHeight: 0.003, numericOnly: true)
                    var unique: [RecognizedTextLine] = []
                    func isAmountCandidate(_ line: RecognizedTextLine) -> Bool {
                        line.text.range(of: #"^\s*[-−－—–+]\s*[¥￥]?\s*\d{1,7}(?:[.,]\d{1,2})?\s*$"#, options: .regularExpression) != nil
                    }
                    for line in full + amountColumn.filter(isAmountCandidate) + narrowAmounts.filter(isAmountCandidate) {
                        let normalized = line.text.replacingOccurrences(of: " ", with: "")
                        let duplicate = unique.contains {
                            $0.text.replacingOccurrences(of: " ", with: "") == normalized &&
                            abs(($0.y + $0.height / 2) - (line.y + line.height / 2)) < max($0.height, line.height) * 0.8
                        }
                        if !duplicate { unique.append(line) }
                    }
                    continuation.resume(returning: unique)
                }
                catch { continuation.resume(throwing: error) }
            }
        }
    }

    enum OCRError: LocalizedError {
        case invalidImage
        var errorDescription: String? { "无法读取这张图片" }
    }
}

private extension UIImage {
    var cgOrientation: CGImagePropertyOrientation {
        switch imageOrientation {
        case .up: .up
        case .upMirrored: .upMirrored
        case .down: .down
        case .downMirrored: .downMirrored
        case .left: .left
        case .leftMirrored: .leftMirrored
        case .right: .right
        case .rightMirrored: .rightMirrored
        @unknown default: .up
        }
    }
}
