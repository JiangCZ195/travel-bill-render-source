import Foundation

public enum ExpenseCategory: String, CaseIterable, Codable, Identifiable, Sendable {
    case stayPlay = "玩住"
    case transport = "交通"
    case food = "吃喝"
    case shopping = "购物"
    case supplies = "用品"

    public var id: String { rawValue }

    public var colorHex: String {
        switch self {
        case .stayPlay: "F2BA02"
        case .transport: "4874CB"
        case .food: "E54C5E"
        case .shopping: "30C0B4"
        case .supplies: "75BD42"
        }
    }

    public var paleHex: String {
        switch self {
        case .stayPlay: "FCF1CC"
        case .transport: "DAE3F5"
        case .food: "FADBDF"
        case .shopping: "D6F2F0"
        case .supplies: "E3F2D9"
        }
    }
}

public enum ExpenseSource: String, Codable, Sendable {
    case manual
    case image
    case fuel
}

public enum ExpenseVisibility: String, Codable, Sendable {
    case group
    case `private`
}

public enum BillWorkspace: String, Sendable {
    case personal
    case friends
}

public struct AccountUser: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public var displayName: String
    public var email: String
    public var avatarMediaId: String
    public let createdAt: String

    public init(id: String, displayName: String, email: String = "", avatarMediaId: String = "", createdAt: String = "") {
        self.id = id
        self.displayName = displayName
        self.email = email
        self.avatarMediaId = avatarMediaId
        self.createdAt = createdAt
    }

    private enum CodingKeys: String, CodingKey { case id, displayName, email, avatarMediaId, createdAt }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(String.self, forKey: .id)
        displayName = try values.decode(String.self, forKey: .displayName)
        email = try values.decodeIfPresent(String.self, forKey: .email) ?? ""
        avatarMediaId = try values.decodeIfPresent(String.self, forKey: .avatarMediaId) ?? ""
        createdAt = try values.decodeIfPresent(String.self, forKey: .createdAt) ?? ""
    }
}

public enum SplitMode: String, CaseIterable, Codable, Sendable {
    case none
    case all
    case selected
    case custom

    public var title: String {
        switch self {
        case .none: "不分账"
        case .all: "全部 AA"
        case .selected: "指定人员平摊"
        case .custom: "按人填写金额"
        }
    }
}

public struct ExpenseEntry: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var date: String
    public var item: String
    public var category: ExpenseCategory
    public var amount: Double
    public var source: ExpenseSource
    public var reason: String
    public var needsReview: Bool
    public var fuelID: UUID?
    public var transactionTime: String
    public var splitMode: SplitMode
    public var splitParticipants: [String]
    public var splitAmounts: [String: Double]
    public var splitAutomatic: Bool
    public var cloudID: String?
    public var groupID: String?
    public var personalTripID: String?
    public var visibility: ExpenseVisibility
    public var syncStatus: String
    public var payerUserID: String?
    public var splitParticipantIDs: [String]
    public var splitAmountCents: [String: Int]

    public init(
        id: UUID = UUID(),
        date: String,
        item: String,
        category: ExpenseCategory,
        amount: Double,
        source: ExpenseSource = .manual,
        reason: String = "",
        needsReview: Bool = false,
        fuelID: UUID? = nil,
        transactionTime: String = "",
        splitMode: SplitMode = .none,
        splitParticipants: [String] = [],
        splitAmounts: [String: Double] = [:],
        splitAutomatic: Bool = false,
        cloudID: String? = nil,
        groupID: String? = nil,
        personalTripID: String? = nil,
        visibility: ExpenseVisibility = .private,
        syncStatus: String = "local",
        payerUserID: String? = nil,
        splitParticipantIDs: [String] = [],
        splitAmountCents: [String: Int] = [:]
    ) {
        self.id = id
        self.date = date
        self.item = item
        self.category = category
        self.amount = amount
        self.source = source
        self.reason = reason
        self.needsReview = needsReview
        self.fuelID = fuelID
        self.transactionTime = transactionTime
        self.splitMode = splitMode
        self.splitParticipants = splitParticipants
        self.splitAmounts = splitAmounts
        self.splitAutomatic = splitAutomatic
        self.cloudID = cloudID
        self.groupID = groupID
        self.personalTripID = personalTripID
        self.visibility = visibility
        self.syncStatus = syncStatus
        self.payerUserID = payerUserID
        self.splitParticipantIDs = splitParticipantIDs
        self.splitAmountCents = splitAmountCents
    }

    private enum CodingKeys: String, CodingKey {
        case id, date, item, category, amount, source, reason, needsReview, fuelID, transactionTime, splitMode, splitParticipants, splitAmounts, splitAutomatic, cloudID, groupID, personalTripID, visibility, syncStatus, payerUserID, splitParticipantIDs, splitAmountCents
    }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        date = try values.decodeIfPresent(String.self, forKey: .date) ?? ""
        item = try values.decodeIfPresent(String.self, forKey: .item) ?? ""
        category = try values.decodeIfPresent(ExpenseCategory.self, forKey: .category) ?? .shopping
        amount = try values.decodeIfPresent(Double.self, forKey: .amount) ?? 0
        source = try values.decodeIfPresent(ExpenseSource.self, forKey: .source) ?? .manual
        reason = try values.decodeIfPresent(String.self, forKey: .reason) ?? ""
        needsReview = try values.decodeIfPresent(Bool.self, forKey: .needsReview) ?? false
        fuelID = try values.decodeIfPresent(UUID.self, forKey: .fuelID)
        transactionTime = try values.decodeIfPresent(String.self, forKey: .transactionTime) ?? ""
        splitMode = try values.decodeIfPresent(SplitMode.self, forKey: .splitMode) ?? .none
        splitParticipants = try values.decodeIfPresent([String].self, forKey: .splitParticipants) ?? []
        splitAmounts = try values.decodeIfPresent([String: Double].self, forKey: .splitAmounts) ?? [:]
        splitAutomatic = try values.decodeIfPresent(Bool.self, forKey: .splitAutomatic) ?? false
        cloudID = try values.decodeIfPresent(String.self, forKey: .cloudID)
        groupID = try values.decodeIfPresent(String.self, forKey: .groupID)
        personalTripID = try values.decodeIfPresent(String.self, forKey: .personalTripID)
        visibility = try values.decodeIfPresent(ExpenseVisibility.self, forKey: .visibility) ?? .private
        syncStatus = try values.decodeIfPresent(String.self, forKey: .syncStatus) ?? "local"
        payerUserID = try values.decodeIfPresent(String.self, forKey: .payerUserID)
        splitParticipantIDs = try values.decodeIfPresent([String].self, forKey: .splitParticipantIDs) ?? []
        splitAmountCents = try values.decodeIfPresent([String: Int].self, forKey: .splitAmountCents) ?? [:]
    }
}

public struct CloudGroupSummary: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public var name: String
    public let ownerId: String
    public let role: String
    public let memberCount: Int
    public let participantCount: Int?
    public let createdAt: String
    public let updatedAt: String
    public let coverMediaId: String?
}

public struct CloudGuestParticipant: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public let name: String
    public let createdBy: String
    public let createdAt: String
}

public struct CloudFriend: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public let displayName: String
    public let email: String
    public let avatarMediaId: String
    public let sharedGroupCount: Int
    public let lastGroupId: String
    public let lastGroupName: String
}

public struct CloudGroupMember: Codable, Equatable, Identifiable, Sendable {
    public let groupId: String
    public let userId: String
    public let role: String
    public let joinedAt: String
    public let user: AccountUser?
    public var id: String { userId }
}

public struct CloudExpense: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public let groupId: String
    public let createdBy: String
    public let visibility: ExpenseVisibility
    public let date: String
    public let item: String
    public let category: ExpenseCategory
    public let amountCents: Int
    public let payerUserId: String
    public let splitMode: SplitMode
    public let splitParticipants: [String]
    public let splitAmounts: [String: Int]
    public let version: Int
    public let createdAt: String
    public let updatedAt: String
}

public struct PersonalTripSummary: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public var name: String
    public let tripMeta: [String: String]
    public let expenseCount: Int
    public let totalCents: Int
    public let mediaCount: Int
    public let createdAt: String
    public let updatedAt: String
    public let coverMediaId: String?
}

public struct CloudMessage: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public let groupId: String
    public let senderId: String
    public let type: String
    public let body: String
    public let mediaId: String
    public let createdAt: String
    public let sender: AccountUser?

    public init(id: String, groupId: String = "", senderId: String, type: String, body: String, mediaId: String = "", createdAt: String, sender: AccountUser? = nil) {
        self.id = id
        self.groupId = groupId
        self.senderId = senderId
        self.type = type
        self.body = body
        self.mediaId = mediaId
        self.createdAt = createdAt
        self.sender = sender
    }
}

public struct MediaAsset: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public let groupId: String
    public let tripKey: String
    public let createdBy: String
    public let visibility: ExpenseVisibility
    public let mediaType: String
    public let mimeType: String
    public let originalName: String
    public let byteSize: Int
    public let capturedAt: String
    public let latitude: Double?
    public let longitude: Double?
    public let locationName: String
    public let country: String
    public let region: String
    public let city: String
    public let locationSource: String
    public let createdAt: String
    public let updatedAt: String
}

public struct FootprintSummary: Codable, Equatable, Sendable {
    public let countries: [String]
    public let cities: [String]
    public let places: [FootprintPlace]
}

public struct FootprintPlace: Codable, Equatable, Identifiable, Sendable {
    public let country: String
    public let region: String
    public let city: String
    public let locationName: String
    public let latitude: Double?
    public let longitude: Double?
    public let mediaCount: Int
    public let latestAt: String
    public var id: String { [country, region, city, locationName, latitude.map { String($0) } ?? "", longitude.map { String($0) } ?? ""].joined(separator: "|") }
}

public struct CloudGroup: Codable, Equatable, Identifiable, Sendable {
    public let id: String
    public var name: String
    public let ownerId: String
    public let createdAt: String
    public let updatedAt: String
    public let members: [CloudGroupMember]
    public let guestParticipants: [CloudGuestParticipant]?
    public let expenses: [CloudExpense]
    public var media: [MediaAsset]
}

public struct FuelRecord: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var date: String
    public var route: String
    public var distance: Double
    public var consumption: Double
    public var province: String
    public var grade: String
    public var price: Double
    public var priceDate: String
    public var duration: String

    public init(
        id: UUID = UUID(),
        date: String,
        route: String = "自驾行程",
        distance: Double,
        consumption: Double,
        province: String = "",
        grade: String = "95#",
        price: Double = 0,
        priceDate: String = "",
        duration: String = ""
    ) {
        self.id = id
        self.date = date
        self.route = route
        self.distance = distance
        self.consumption = consumption
        self.province = province
        self.grade = ["92#", "95#", "98#"].contains(grade) ? grade : "95#"
        self.price = price
        self.priceDate = priceDate
        self.duration = duration
    }

    private enum CodingKeys: String, CodingKey { case id, date, route, distance, consumption, province, grade, price, priceDate, duration }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        self.init(
            id: try values.decodeIfPresent(UUID.self, forKey: .id) ?? UUID(),
            date: try values.decodeIfPresent(String.self, forKey: .date) ?? "",
            route: try values.decodeIfPresent(String.self, forKey: .route) ?? "自驾行程",
            distance: try values.decodeIfPresent(Double.self, forKey: .distance) ?? 0,
            consumption: try values.decodeIfPresent(Double.self, forKey: .consumption) ?? 0,
            province: try values.decodeIfPresent(String.self, forKey: .province) ?? "",
            grade: try values.decodeIfPresent(String.self, forKey: .grade) ?? "95#",
            price: try values.decodeIfPresent(Double.self, forKey: .price) ?? 0,
            priceDate: try values.decodeIfPresent(String.self, forKey: .priceDate) ?? "",
            duration: try values.decodeIfPresent(String.self, forKey: .duration) ?? ""
        )
    }

    public var liters: Double { distance * consumption / 100 }
    public var cost: Double { liters * price }
}

public struct BillDraft: Codable, Equatable, Sendable {
    public var entries: [ExpenseEntry]
    public var fuelRecords: [FuelRecord]
    public var participants: [String]
    public var learnedCategories: [String: ExpenseCategory]
    public var selectedDate: String

    public init(
        entries: [ExpenseEntry] = [],
        fuelRecords: [FuelRecord] = [],
        participants: [String] = [],
        learnedCategories: [String: ExpenseCategory] = [:],
        selectedDate: String = DateText.isoDate()
    ) {
        self.entries = entries
        self.fuelRecords = fuelRecords
        self.participants = participants
        self.learnedCategories = learnedCategories
        self.selectedDate = selectedDate
    }

    private enum CodingKeys: String, CodingKey { case entries, fuelRecords, participants, learnedCategories, selectedDate }

    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        entries = try values.decodeIfPresent([ExpenseEntry].self, forKey: .entries) ?? []
        fuelRecords = try values.decodeIfPresent([FuelRecord].self, forKey: .fuelRecords) ?? []
        participants = try values.decodeIfPresent([String].self, forKey: .participants) ?? []
        learnedCategories = try values.decodeIfPresent([String: ExpenseCategory].self, forKey: .learnedCategories) ?? [:]
        selectedDate = try values.decodeIfPresent(String.self, forKey: .selectedDate) ?? DateText.isoDate()
    }
}

public struct Classification: Equatable, Sendable {
    public var category: ExpenseCategory
    public var confidence: Double
    public var reason: String
    public var usedWeb: Bool

    public init(category: ExpenseCategory, confidence: Double, reason: String, usedWeb: Bool = false) {
        self.category = category
        self.confidence = confidence
        self.reason = reason
        self.usedWeb = usedWeb
    }
}

public struct TripInfo: Equatable, Sendable {
    public var startDate: String
    public var endDate: String
    public var dateLabel: String
    public var locations: [String]
    public var flags: [String]
    public var province: String

    public init(
        startDate: String = "",
        endDate: String = "",
        dateLabel: String = "",
        locations: [String] = [],
        flags: [String] = [],
        province: String = ""
    ) {
        self.startDate = startDate
        self.endDate = endDate
        self.dateLabel = dateLabel
        self.locations = locations
        self.flags = flags
        self.province = province
    }

    public var destinationLabel: String {
        guard !locations.isEmpty else { return "" }
        var previousFlag = ""
        return locations.enumerated().map { index, location in
            let flag = flags.indices.contains(index) ? flags[index] : ""
            let prefix = flag == previousFlag ? "、" : flag
            previousFlag = flag
            return "\(prefix)\(location)"
        }.joined()
    }

    public var title: String {
        [dateLabel, destinationLabel].filter { !$0.isEmpty }.joined(separator: " · ")
    }
}

public enum DateText {
    private static let calendar = Calendar(identifier: .gregorian)

    public static func isoDate(_ date: Date = Date()) -> String {
        let parts = calendar.dateComponents(in: TimeZone.current, from: date)
        return String(format: "%04d-%02d-%02d", parts.year ?? 0, parts.month ?? 0, parts.day ?? 0)
    }

    public static func date(from value: String, fallbackYear: Int = Calendar.current.component(.year, from: Date())) -> Date? {
        let numbers = value.matches(of: #/(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})/#)
        if let first = numbers.first {
            return calendar.date(from: DateComponents(year: Int(first.1), month: Int(first.2), day: Int(first.3)))
        }
        let short = value.matches(of: #/(\d{1,2})[-/.月](\d{1,2})日?/#)
        if let first = short.first {
            return calendar.date(from: DateComponents(year: fallbackYear, month: Int(first.1), day: Int(first.2)))
        }
        return nil
    }

    public static func display(_ value: String) -> String {
        guard let date = date(from: value) else { return value.isEmpty ? "选择日期" : value }
        let components = calendar.dateComponents([.month, .day], from: date)
        return "\(components.month ?? 0)月\(components.day ?? 0)日"
    }

    public static func shortFileDate(_ value: String, includeYear: Bool) -> String {
        guard let date = date(from: value) else { return "" }
        let components = calendar.dateComponents([.year, .month, .day], from: date)
        if includeYear {
            return "\(components.year ?? 0).\(components.month ?? 0).\(components.day ?? 0)"
        }
        return "\(components.month ?? 0).\(components.day ?? 0)"
    }
}

extension String {
    public var xmlEscaped: String {
        replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
            .replacingOccurrences(of: "'", with: "&apos;")
    }

    public var normalizedExpenseText: String {
        applyingTransform(.fullwidthToHalfwidth, reverse: false)?
            .replacingOccurrences(of: "￫", with: "→")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression) ?? self
    }
}
