import Combine
import Foundation
import UIKit

@MainActor
final class BillStore: ObservableObject {
    @Published var entries: [ExpenseEntry] = []
    @Published var fuelRecords: [FuelRecord] = []
    @Published var participants: [String] = []
    @Published var learnedCategories: [String: ExpenseCategory] = [:]
    @Published var currentUser: AccountUser?
    @Published var avatarImage: UIImage?
    @Published var avatarImageLoading = false
    @Published var tripCoverImages: [String: UIImage] = [:]
    @Published var accountMessage = ""
    @Published var developmentName = ""
    @Published var loginIdentifier = ""
    @Published var loginCode = ""
    @Published var loginDisplayName = ""
    @Published var loginCodeHint = ""
    @Published var loginResendRemaining = 0
    @Published var isRequestingLoginCode = false
    @Published var isVerifyingLoginCode = false
    @Published var manualPairingCode = ""
    @Published var groups: [CloudGroupSummary] = []
    @Published var friends: [CloudFriend] = []
    @Published var activeGroup: CloudGroup?
    @Published var personalTrips: [PersonalTripSummary] = []
    @Published var activePersonalTripID: String?
    @Published var chatMessages: [CloudMessage] = []
    @Published var chatGroupID: String?
    @Published var chatFriendID: String?
    @Published var chatSearch = ""
    @Published var unreadByGroup: [String: Int] = [:]
    @Published var unreadChatCount = 0
    @Published var isShowingChatNotification = false
    @Published var chatNotificationGroupID: String?
    @Published var chatNotificationTitle = "新消息"
    @Published var chatNotificationBody = ""
    @Published var manualGroupName = ""
    @Published var manualInviteCode = ""
    @Published var inviteCode = ""
    @Published var manualFriendCode = ""
    @Published var friendInviteCode = ""
    @Published var manualVisibility: ExpenseVisibility = .group
    @Published var manualDate = Date()
    @Published var manualItem = ""
    @Published var manualCategory: ExpenseCategory = .shopping
    @Published var manualAmount = ""
    @Published var manualParticipantName = ""
    @Published var classificationReason = ""
    @Published var isWorking = false
    @Published var isRecognizingImages = false
    @Published var imageRecognitionCompleted = 0
    @Published var imageRecognitionTotal = 0
    @Published var message = ""
    @Published var lastExportURL: URL?
    @Published var footprintSummary = FootprintSummary(countries: [], cities: [], places: [])
    @Published var workspace: BillWorkspace = .personal

    private let defaultsKey = "TravelBillDraftV3"
    private let accountKey = "TravelBillAccountV1"
    private let sessionKey = "TravelBillSessionV1"
    private var classificationTask: Task<Void, Never>?
    private var loginChallengeID = ""
    private var loginRequestedIdentifier = ""
    private var loginResendTask: Task<Void, Never>?
    private var loginResendUntil: Date?
    private var messagePollTask: Task<Void, Never>?
    private var chatReadMarkers: [String: String] = UserDefaults.standard.dictionary(forKey: "TravelBillChatReadV1") as? [String: String] ?? [:]

    init() {
        restore()
        restoreAccount()
        Task { await AuthAPI.warmUp() }
        if currentUser != nil { Task { await validateAccountSession() } }
    }

    var currentEntries: [ExpenseEntry] {
        let filtered: [ExpenseEntry] = switch workspace {
        case .personal:
            if let activePersonalTripID { entries.filter { $0.groupID == nil && $0.personalTripID == activePersonalTripID } }
            else { entries.filter { $0.groupID == nil } }
        case .friends:
            if let groupID = activeGroup?.id { entries.filter { $0.groupID == groupID } }
            else { [] }
        }
        return filtered.enumerated().sorted { left, right in
            let leftDate = left.element.date.isEmpty ? "9999-99-99" : left.element.date
            let rightDate = right.element.date.isEmpty ? "9999-99-99" : right.element.date
            if leftDate != rightDate { return leftDate < rightDate }
            let leftTime = left.element.transactionTime.isEmpty ? "99:99:99" : left.element.transactionTime
            let rightTime = right.element.transactionTime.isEmpty ? "99:99:99" : right.element.transactionTime
            if leftTime != rightTime { return leftTime < rightTime }
            return left.offset < right.offset
        }.map(\.element)
    }

    var trip: TripInfo { TripInference.infer(entries: currentEntries, fuelRecords: fuelRecords) }
    var total: Double { currentEntries.reduce(0) { $0 + $1.amount } }
    var personalTotal: Double { currentEntries.reduce(0) { $0 + personalShare($1) } }
    var reviewCount: Int { currentEntries.filter(\.needsReview).count }
    var splitReviewCount: Int { currentEntries.filter { SplitDetails.issue(for: $0, participants: participants) != nil }.count }
    var categoryTotals: [ExpenseCategory: Double] {
        Dictionary(grouping: currentEntries, by: \.category).mapValues { $0.reduce(0) { $0 + $1.amount } }
    }
    var canExport: Bool { !currentEntries.isEmpty && reviewCount == 0 && splitReviewCount == 0 }

    private func personalShare(_ entry: ExpenseEntry) -> Double {
        guard let user = currentUser, let group = activeGroup, entry.groupID == group.id else { return entry.amount }
        if entry.visibility == .private { return entry.amount }
        switch entry.splitMode {
        case .custom:
            if let cents = entry.splitAmountCents[user.id] { return Double(cents) / 100 }
            return entry.splitAmounts[user.displayName] ?? 0
        case .all, .selected:
            let ids = entry.splitParticipantIDs.isEmpty
                ? entry.splitParticipants.compactMap { name in group.members.first(where: { ($0.user?.displayName ?? "旅伴") == name })?.userId }
                : entry.splitParticipantIDs
            guard let index = ids.firstIndex(of: user.id), !ids.isEmpty else { return 0 }
            let average = (entry.amount / Double(ids.count) * 100).rounded() / 100
            return index == ids.count - 1 ? ((entry.amount - average * Double(ids.count - 1)) * 100).rounded() / 100 : average
        case .none:
            return entry.payerUserID == user.id ? entry.amount : 0
        }
    }

    func signInWithApple() {
        Task { @MainActor in
            do {
                let credential = try await AppleAuthService().signIn()
                let result = try await AuthAPI.signInWithApple(identityToken: credential.token, displayName: credential.displayName, appleSubject: credential.subject)
                currentUser = result.user
                UserDefaults.standard.set(result.session, forKey: sessionKey)
                if let data = try? JSONEncoder().encode(result.user) { UserDefaults.standard.set(data, forKey: accountKey) }
                accountMessage = "已使用 Apple ID 登录"
                await refreshGroups()
            } catch {
                accountMessage = loginErrorMessage(error)
            }
        }
    }

    func signInDevelopment() {
        let name = developmentName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { accountMessage = "请输入姓名"; return }
        Task { @MainActor in
            do {
                let result = try await AuthAPI.signInDevelopment(displayName: name)
                currentUser = result.user
                UserDefaults.standard.set(result.session, forKey: sessionKey)
                if let data = try? JSONEncoder().encode(result.user) { UserDefaults.standard.set(data, forKey: accountKey) }
                accountMessage = "已使用本机开发账号登录"
                await refreshGroups()
            } catch {
                accountMessage = error.localizedDescription
            }
        }
    }

    func requestLoginCode() {
        let identifier = loginIdentifier.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !identifier.isEmpty else { accountMessage = "请输入邮箱"; return }
        guard !isRequestingLoginCode else { accountMessage = "正在发送验证码，请稍候"; return }
        guard loginResendRemaining == 0 else {
            accountMessage = "验证码已发送，请等待 \(loginResendRemaining) 秒后再获取"
            return
        }
        isRequestingLoginCode = true
        Task { @MainActor in
            defer { isRequestingLoginCode = false }
            do {
                let result = try await AuthAPI.requestLoginCode(identifier: identifier)
                loginChallengeID = result.challengeId
                loginRequestedIdentifier = identifier.lowercased()
                loginCodeHint = if let code = result.code, !code.isEmpty {
                    "验证码已生成（本地开发）：" + code + "，5 分钟内有效"
                } else {
                    "验证码已发送至 " + result.destination + "，请查收邮件后输入 6 位验证码；5 分钟内有效"
                }
                startLoginResendCountdown(seconds: result.resendAfter)
                accountMessage = "验证码已发送，请查收邮件"
            } catch {
                accountMessage = loginErrorMessage(error)
            }
        }
    }

    private func startLoginResendCountdown(seconds: Int) {
        loginResendTask?.cancel()
        let duration = max(60, seconds)
        loginResendUntil = Date().addingTimeInterval(TimeInterval(duration))
        loginResendRemaining = duration
        loginResendTask = Task { @MainActor [weak self] in
            guard let self else { return }
            while !Task.isCancelled, let deadline = self.loginResendUntil {
                let remaining = max(0, Int(ceil(deadline.timeIntervalSinceNow)))
                self.loginResendRemaining = remaining
                if remaining == 0 {
                    self.loginResendUntil = nil
                    self.loginResendTask = nil
                    return
                }
                try? await Task.sleep(for: .milliseconds(250))
            }
        }
    }

    private func loginErrorMessage(_ error: Error) -> String {
        let raw = error.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = raw.lowercased()
        if raw.contains("频繁") || raw.contains("过多") || lower.contains("rate limit") || lower.contains("too many") || lower.contains("security purposes") {
            return "验证码请求过于频繁，请等待倒计时结束后再获取"
        }
        if lower.contains("network") || lower.contains("could not connect") || lower.contains("not connected") || lower.contains("timed out") || raw.contains("无法连接") {
            return "暂时无法连接账号服务，请检查网络后重试"
        }
        if lower.contains("expired") || lower.contains("invalid otp") || lower.contains("invalid token") {
            return "验证码不正确或已过期，请重新获取"
        }
        if raw.isEmpty || lower.contains("the operation couldn") || lower.contains("decoding") {
            return "账号服务暂时不可用，请稍后重试"
        }
        return raw
    }

    func verifyLoginCode() {
        let identifier = loginIdentifier.trimmingCharacters(in: .whitespacesAndNewlines)
        let code = String(loginCode.filter(\.isNumber).prefix(6))
        guard !loginChallengeID.isEmpty else { accountMessage = "请先获取验证码"; return }
        guard loginRequestedIdentifier.isEmpty || loginRequestedIdentifier == identifier.lowercased() else {
            accountMessage = "邮箱已变更，请重新获取验证码"
            return
        }
        guard !isVerifyingLoginCode else { accountMessage = "正在验证验证码，请稍候"; return }
        guard code.count == 6, code.allSatisfy({ $0.isNumber }) else { accountMessage = "请输入 6 位验证码"; return }
        isVerifyingLoginCode = true
        accountMessage = "正在验证验证码…"
        Task { @MainActor in
            defer { isVerifyingLoginCode = false }
            do {
                let result = try await AuthAPI.verifyLoginCode(challengeID: loginChallengeID, identifier: identifier, code: code, displayName: loginDisplayName.trimmingCharacters(in: .whitespacesAndNewlines))
                currentUser = result.user
                UserDefaults.standard.set(result.session, forKey: sessionKey)
                if let data = try? JSONEncoder().encode(result.user) { UserDefaults.standard.set(data, forKey: accountKey) }
                accountMessage = "登录成功"
                loginCode = ""
                loginCodeHint = ""
                loginChallengeID = ""
                loginRequestedIdentifier = ""
                loginResendTask?.cancel()
                loginResendTask = nil
                loginResendUntil = nil
                loginResendRemaining = 0
                await refreshGroups()
            } catch {
                accountMessage = loginErrorMessage(error)
            }
        }
    }

    func signOut() {
        messagePollTask?.cancel()
        messagePollTask = nil
        loginResendTask?.cancel()
        loginResendTask = nil
        loginResendUntil = nil
        loginResendRemaining = 0
        loginChallengeID = ""
        loginRequestedIdentifier = ""
        currentUser = nil
        avatarImage = nil
        groups = []
        friends = []
        activeGroup = nil
        personalTrips = []
        activePersonalTripID = nil
        chatMessages = []
        chatGroupID = nil
        chatFriendID = nil
        unreadByGroup = [:]
        unreadChatCount = 0
        isShowingChatNotification = false
        chatNotificationGroupID = nil
        participants = []
        footprintSummary = FootprintSummary(countries: [], cities: [], places: [])
        UserDefaults.standard.removeObject(forKey: accountKey)
        UserDefaults.standard.removeObject(forKey: sessionKey)
        accountMessage = "已退出登录"
    }

    func updateAvatar(data: Data, filename: String = "avatar.jpg", mimeType: String = "image/jpeg") {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            accountMessage = "请先登录账号"
            return
        }
        Task { @MainActor in
            do {
                currentUser = try await AuthAPI.uploadAvatar(data: data, filename: filename, mimeType: mimeType, session: session)
                avatarImage = UIImage(data: data)
                if let currentUser, let encoded = try? JSONEncoder().encode(currentUser) { UserDefaults.standard.set(encoded, forKey: accountKey) }
                accountMessage = "头像已更新"
            } catch { accountMessage = "头像更新失败：\(error.localizedDescription)" }
        }
    }

    func refreshAvatarImage() async {
        guard let avatarMediaID = currentUser?.avatarMediaId,
              !avatarMediaID.isEmpty,
              let session = UserDefaults.standard.string(forKey: sessionKey),
              !session.isEmpty else {
            avatarImage = nil
            return
        }
        avatarImageLoading = true
        defer { avatarImageLoading = false }
        do {
            let (data, _) = try await AuthAPI.mediaData(id: avatarMediaID, session: session)
            guard let image = UIImage(data: data) else {
                throw NSError(domain: "TravelBillAvatar", code: 1, userInfo: [NSLocalizedDescriptionKey: "服务器返回的头像不是有效图片"])
            }
            avatarImage = image
        } catch {
            // 保留已有头像，避免网络短暂失败时把已显示的头像闪回默认图标。
            accountMessage = "头像读取失败，请稍后重试：\(error.localizedDescription)"
        }
    }

    func refreshGroups() async {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        do {
            // 首屏所需的独立数据并行读取。免费云端单次请求通常需要约 1–3 秒，
            // 串行等待会把总时间累加成十几秒。
            async let groupsRequest = AuthAPI.listGroups(session: session)
            async let friendsRequest = AuthAPI.listFriends(session: session)
            async let personalTripsRequest = AuthAPI.listPersonalTrips(session: session)
            async let footprintsRequest = AuthAPI.listFootprints(session: session)
            let (newGroups, newFriends, newPersonalTrips, newFootprints) = try await (
                groupsRequest, friendsRequest, personalTripsRequest, footprintsRequest
            )
            groups = newGroups
            friends = newFriends
            personalTrips = newPersonalTrips
            footprintSummary = newFootprints
            if let current = activeGroup, groups.contains(where: { $0.id == current.id }) {
                activeGroup = try await AuthAPI.getGroup(id: current.id, session: session)
            } else if let first = groups.first {
                activeGroup = try await AuthAPI.getGroup(id: first.id, session: session)
            } else {
                activeGroup = nil
                participants = []
            }
            if let activeGroup { syncCloudGroup(activeGroup) }
            await refreshTripCovers(session: session)
            startMessagePolling()
        } catch {
            accountMessage = "账单组同步失败：\(error.localizedDescription)"
        }
    }

    func refreshPersonalTrips() async {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            personalTrips = []
            return
        }
        do {
            personalTrips = try await AuthAPI.listPersonalTrips(session: session)
            await refreshTripCovers(session: session)
        } catch { accountMessage = "个人旅程同步失败：\(error.localizedDescription)" }
    }

    func createPersonalTrip(name: String) {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanName.isEmpty else { message = "请输入旅程名称"; return }
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            message = "请先登录账号"
            return
        }
        Task { @MainActor in
            do {
                let trip = try await AuthAPI.createPersonalTrip(name: cleanName, session: session)
                personalTrips.insert(trip, at: 0)
                await selectPersonalTrip(trip.id)
                message = "个人账单已创建"
            } catch { message = "创建个人账单失败：\(error.localizedDescription)" }
        }
    }

    func deletePersonalTrip(_ id: String) {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { message = "请先登录账号"; return }
        Task { @MainActor in
            do {
                try await AuthAPI.deletePersonalTrip(id: id, session: session)
                personalTrips.removeAll { $0.id == id }
                entries.removeAll { $0.personalTripID == id }
                if activePersonalTripID == id { activePersonalTripID = nil }
                persist()
                message = "个人账单已删除"
            } catch { message = "删除失败：\(error.localizedDescription)" }
        }
    }

    func deleteGroup(_ group: CloudGroupSummary) {
        guard group.role == "owner" else { accountMessage = "只有创建者可以删除共同账单"; return }
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { accountMessage = "请先登录账号"; return }
        Task { @MainActor in
            do {
                try await AuthAPI.deleteGroup(id: group.id, session: session)
                groups.removeAll { $0.id == group.id }
                entries.removeAll { $0.groupID == group.id }
                if activeGroup?.id == group.id { activeGroup = nil; participants = [] }
                accountMessage = "共同账单已删除"
            } catch { accountMessage = "删除失败：\(error.localizedDescription)" }
        }
    }

    func updatePersonalTrip(_ id: String, name: String, coverData: Data?) async -> Bool {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { message = "请先登录账号"; return false }
        do {
            var updated = try await AuthAPI.updatePersonalTrip(id: id, name: name, session: session)
            if let coverData { updated = try await AuthAPI.uploadPersonalTripCover(id: id, data: coverData, session: session) }
            if let index = personalTrips.firstIndex(where: { $0.id == id }) { personalTrips[index] = updated }
            if let coverData, let image = UIImage(data: coverData) { tripCoverImages["personal:\(id)"] = image }
            message = "旅行信息已更新"
            return true
        } catch { message = "更新失败：\(error.localizedDescription)"; return false }
    }

    func updateGroup(_ group: CloudGroupSummary, name: String, coverData: Data?) async -> Bool {
        guard group.role == "owner" else { accountMessage = "只有创建者可以修改共同账单"; return false }
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { accountMessage = "请先登录账号"; return false }
        do {
            var updated = try await AuthAPI.updateGroup(id: group.id, name: name, session: session)
            if let coverData { updated = try await AuthAPI.uploadGroupCover(id: group.id, data: coverData, session: session) }
            if let index = groups.firstIndex(where: { $0.id == group.id }) { groups[index] = updated }
            if activeGroup?.id == group.id { activeGroup?.name = updated.name }
            if let coverData, let image = UIImage(data: coverData) { tripCoverImages["group:\(group.id)"] = image }
            accountMessage = "共同旅行信息已更新"
            return true
        } catch { accountMessage = "更新失败：\(error.localizedDescription)"; return false }
    }

    func deleteFriend(_ friend: CloudFriend) async -> Bool {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { accountMessage = "请先登录账号"; return false }
        do {
            try await AuthAPI.deleteFriend(id: friend.id, session: session)
            friends.removeAll { $0.id == friend.id }
            if chatFriendID == friend.id { chatFriendID = nil; chatMessages = [] }
            accountMessage = "已删除好友 \(friend.displayName)"
            return true
        } catch { accountMessage = "删除好友失败：\(error.localizedDescription)"; return false }
    }

    private func refreshTripCovers(session: String) async {
        let covers = personalTrips.compactMap { trip in trip.coverMediaId.map { ("personal:\(trip.id)", $0) } }
            + groups.compactMap { group in group.coverMediaId.map { ("group:\(group.id)", $0) } }
        let pending = covers.filter { tripCoverImages[$0.0] == nil }
        let downloaded = await withTaskGroup(of: (String, Data)?.self, returning: [(String, Data)].self) { group in
            for (key, mediaID) in pending {
                group.addTask {
                    guard let (data, _) = try? await AuthAPI.mediaData(id: mediaID, session: session) else { return nil }
                    return (key, data)
                }
            }
            var results: [(String, Data)] = []
            for await result in group {
                if let result { results.append(result) }
            }
            return results
        }
        for (key, data) in downloaded {
            if let image = UIImage(data: data) { tripCoverImages[key] = image }
        }
    }

    func selectPersonalTrip(_ id: String) async {
        workspace = .personal
        activePersonalTripID = id
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        do {
            let detail = try await AuthAPI.getPersonalTrip(id: id, session: session)
            entries.removeAll { $0.groupID == nil && $0.personalTripID == id }
            entries.append(contentsOf: detail.expenses.map { expense in
                ExpenseEntry(id: UUID(uuidString: expense.id) ?? UUID(), date: expense.date, item: expense.item, category: expense.category, amount: Double(expense.amountCents) / 100, source: ExpenseSource(rawValue: expense.source) ?? .manual, reason: "云端个人账单", personalTripID: id, visibility: .private, syncStatus: "synced")
            })
            persist()
        } catch { message = "旅程详情加载失败：\(error.localizedDescription)" }
    }

    func loadChat(groupID: String, search: String = "") {
        chatGroupID = groupID
        chatFriendID = nil
        chatSearch = search
        let scope = LocalChatStore.groupScope(groupID)
        chatMessages = LocalChatStore.messages(scope: scope, query: search)
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        Task { @MainActor in
            do {
                let remote = try await AuthAPI.listMessages(groupID: groupID, query: search, session: session)
                chatMessages = LocalChatStore.merge(remote, into: scope, query: search)
                await cacheAndAcknowledge(remote, groupID: groupID, session: session)
                markChatRead(groupID: groupID, messages: chatMessages)
            }
            catch { message = "聊天记录加载失败：\(error.localizedDescription)" }
        }
    }

    func loadDirectChat(friendID: String, search: String = "") {
        chatFriendID = friendID
        chatGroupID = nil
        chatSearch = search
        let scope = LocalChatStore.directScope(friendID)
        chatMessages = LocalChatStore.messages(scope: scope, query: search)
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        Task { @MainActor in
            do {
                let remote = try await AuthAPI.listDirectMessages(friendID: friendID, query: search, session: session)
                chatMessages = LocalChatStore.merge(remote, into: scope, query: search)
                await cacheAndAcknowledge(remote, friendID: friendID, session: session)
            } catch { message = "私聊记录加载失败：\(error.localizedDescription)" }
        }
    }

    func openChat(groupID: String) {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        Task { @MainActor in
            do {
                activeGroup = try await AuthAPI.getGroup(id: groupID, session: session)
                if let activeGroup { syncCloudGroup(activeGroup) }
                loadChat(groupID: groupID)
            } catch { message = "聊天窗口打开失败：\(error.localizedDescription)" }
        }
    }

    func openFriendChat(friendID: String) {
        loadDirectChat(friendID: friendID)
    }

    func sendChatMessage(_ body: String) {
        let cleanBody = body.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanBody.isEmpty, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        Task { @MainActor in
            let draftID = "local-\(UUID().uuidString)"
            let draft = makeLocalMessage(id: draftID, type: "text", body: cleanBody)
            do {
                if let groupID = chatGroupID {
                    let scope = LocalChatStore.groupScope(groupID)
                    LocalChatStore.append(draft, scope: scope)
                    chatMessages = LocalChatStore.messages(scope: scope, query: chatSearch)
                    let sent = try await AuthAPI.sendMessage(groupID: groupID, body: cleanBody, session: session)
                    LocalChatStore.remove(messageID: draftID, scope: scope)
                    LocalChatStore.append(sent, scope: scope)
                    let remote = try await AuthAPI.listMessages(groupID: groupID, query: chatSearch, session: session)
                    chatMessages = LocalChatStore.merge(remote, into: scope, query: chatSearch)
                    await cacheAndAcknowledge(remote, groupID: groupID, session: session)
                    markChatRead(groupID: groupID, messages: chatMessages)
                } else if let friendID = chatFriendID {
                    let scope = LocalChatStore.directScope(friendID)
                    LocalChatStore.append(draft, scope: scope)
                    chatMessages = LocalChatStore.messages(scope: scope, query: chatSearch)
                    let sent = try await AuthAPI.sendDirectMessage(friendID: friendID, body: cleanBody, session: session)
                    LocalChatStore.remove(messageID: draftID, scope: scope)
                    LocalChatStore.append(sent, scope: scope)
                    let remote = try await AuthAPI.listDirectMessages(friendID: friendID, query: chatSearch, session: session)
                    chatMessages = LocalChatStore.merge(remote, into: scope, query: chatSearch)
                    await cacheAndAcknowledge(remote, friendID: friendID, session: session)
                }
            } catch { message = "消息发送失败：\(error.localizedDescription)" }
        }
    }

    func dismissChatNotification() {
        isShowingChatNotification = false
        chatNotificationGroupID = nil
    }

    private func messageStamp(_ message: CloudMessage) -> String {
        "\(message.createdAt)|\(message.id)"
    }

    private func messageIsAfter(_ message: CloudMessage, marker: String?) -> Bool {
        guard let marker else { return true }
        let current = messageStamp(message)
        return current > marker
    }

    private func latestMessage(_ messages: [CloudMessage]) -> CloudMessage? {
        messages.sorted { messageStamp($0) < messageStamp($1) }.last
    }

    private func makeLocalMessage(id: String, type: String, body: String, mediaID: String = "") -> CloudMessage {
        CloudMessage(
            id: id,
            groupId: chatGroupID ?? "",
            senderId: currentUser?.id ?? "local",
            type: type,
            body: body,
            mediaId: mediaID,
            createdAt: ISO8601DateFormatter().string(from: Date()),
            sender: currentUser
        )
    }

    private func cacheAndAcknowledge(_ messages: [CloudMessage], groupID: String? = nil, friendID: String? = nil, session: String) async {
        for message in messages {
            if !message.mediaId.isEmpty && LocalChatStore.mediaData(mediaID: message.mediaId) == nil {
                if let (data, _) = try? await AuthAPI.mediaData(id: message.mediaId, session: session) {
                    LocalChatStore.saveMedia(data, mediaID: message.mediaId)
                }
            }
            if message.mediaId.isEmpty || LocalChatStore.mediaData(mediaID: message.mediaId) != nil {
                if let groupID {
                    try? await AuthAPI.acknowledgeMessage(groupID: groupID, messageID: message.id, session: session)
                } else if let friendID {
                    try? await AuthAPI.acknowledgeDirectMessage(friendID: friendID, messageID: message.id, session: session)
                }
            }
        }
    }

    private func saveChatReadMarkers() {
        UserDefaults.standard.set(chatReadMarkers, forKey: "TravelBillChatReadV1")
    }

    func markChatRead(groupID: String, messages: [CloudMessage]? = nil) {
        let source = messages ?? chatMessages
        guard let latest = latestMessage(source) else { return }
        chatReadMarkers[groupID] = messageStamp(latest)
        saveChatReadMarkers()
        unreadByGroup[groupID] = 0
        unreadChatCount = unreadByGroup.values.reduce(0, +)
    }

    private func showChatNotification(group: CloudGroupSummary, message: CloudMessage) {
        guard chatGroupID != group.id else { return }
        chatNotificationGroupID = group.id
        chatNotificationTitle = "\(group.name) · 新消息"
        chatNotificationBody = "\(message.sender?.displayName ?? "旅伴")：\(message.body.isEmpty ? (message.type == "video" ? "发来一段视频" : message.type == "audio" ? "发来一条语音" : "发来一张图片") : message.body)"
        isShowingChatNotification = true
    }

    private func pollMessages(initial: Bool) async {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty, let currentUser else { return }
        var nextUnread: [String: Int] = [:]
        for group in groups {
            guard let messages = try? await AuthAPI.listMessages(groupID: group.id, session: session) else {
                nextUnread[group.id] = unreadByGroup[group.id] ?? 0
                continue
            }
            let scope = LocalChatStore.groupScope(group.id)
            let mergedMessages = LocalChatStore.merge(messages, into: scope)
            await cacheAndAcknowledge(messages, groupID: group.id, session: session)
            let latest = latestMessage(messages)
            guard let marker = chatReadMarkers[group.id] else {
                if let latest { chatReadMarkers[group.id] = messageStamp(latest) }
                nextUnread[group.id] = 0
                continue
            }
            let incoming = messages.filter { messageIsAfter($0, marker: marker) && $0.senderId != currentUser.id }
            if chatGroupID == group.id {
                chatMessages = LocalChatStore.messages(scope: scope, query: chatSearch)
                markChatRead(groupID: group.id, messages: chatSearch.isEmpty ? mergedMessages : chatMessages)
                nextUnread[group.id] = 0
            } else {
                let count = incoming.count
                let previous = unreadByGroup[group.id] ?? 0
                nextUnread[group.id] = count
                if !initial && count > previous, let newest = incoming.sorted(by: { messageStamp($0) < messageStamp($1) }).last {
                    showChatNotification(group: group, message: newest)
                }
            }
        }
        saveChatReadMarkers()
        unreadByGroup = nextUnread
        unreadChatCount = nextUnread.values.reduce(0, +)
    }

    private func startMessagePolling() {
        messagePollTask?.cancel()
        guard currentUser != nil else { return }
        messagePollTask = Task { @MainActor [weak self] in
            guard let self else { return }
            var initial = true
            while !Task.isCancelled {
                await self.pollMessages(initial: initial)
                initial = false
                try? await Task.sleep(for: .seconds(3))
            }
        }
    }

    private func validateAccountSession() async {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            signOut()
            return
        }
        do {
            currentUser = try await AuthAPI.currentUser(session: session)
            if let currentUser, let encoded = try? JSONEncoder().encode(currentUser) {
                UserDefaults.standard.set(encoded, forKey: accountKey)
            }
            await refreshGroups()
        } catch {
            signOut()
            accountMessage = "账号会话已失效，请重新登录"
        }
    }

    func selectGroup(_ id: String) {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        Task { @MainActor in
            do {
                activeGroup = try await AuthAPI.getGroup(id: id, session: session)
                if let activeGroup { syncCloudGroup(activeGroup) }
                await refreshFootprints()
            } catch { accountMessage = error.localizedDescription }
        }
    }

    func createGroup() {
        let name = manualGroupName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { accountMessage = "请输入账单组名称"; return }
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { accountMessage = "请先登录账号"; return }
        Task { @MainActor in
            do {
                activeGroup = try await AuthAPI.createGroup(name: name, session: session)
                manualGroupName = ""
                manualVisibility = .group
                if let activeGroup { syncCloudGroup(activeGroup) }
                groups = try await AuthAPI.listGroups(session: session)
                await refreshFootprints()
                accountMessage = "账单组已创建"
            } catch { accountMessage = error.localizedDescription }
        }
    }

    func joinGroup() {
        let code = manualInviteCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !code.isEmpty else { accountMessage = "请输入邀请码"; return }
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { accountMessage = "请先登录账号"; return }
        Task { @MainActor in
            do {
                activeGroup = try await AuthAPI.joinGroup(code: code, session: session)
                manualInviteCode = ""
                if let activeGroup { syncCloudGroup(activeGroup) }
                groups = try await AuthAPI.listGroups(session: session)
                await refreshFootprints()
                accountMessage = "已加入账单组"
            } catch { accountMessage = error.localizedDescription }
        }
    }

    func createFriendInvite() {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            accountMessage = "请先登录账号"
            return
        }
        Task { @MainActor in
            do {
                friendInviteCode = try await AuthAPI.createFriendInvite(session: session)
                accountMessage = "好友码已生成，24 小时内有效"
            } catch {
                accountMessage = "好友码生成失败：\(error.localizedDescription)"
            }
        }
    }

    func addFriend() {
        let code = manualFriendCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !code.isEmpty else { accountMessage = "请输入好友码"; return }
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            accountMessage = "请先登录账号"
            return
        }
        Task { @MainActor in
            do {
                friends = try await AuthAPI.acceptFriendInvite(code: code, session: session)
                manualFriendCode = ""
                accountMessage = "好友添加成功"
            } catch {
                accountMessage = "添加好友失败：\(error.localizedDescription)"
            }
        }
    }

    func refreshFootprints() async {
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            footprintSummary = FootprintSummary(countries: [], cities: [], places: [])
            return
        }
        do {
            footprintSummary = try await AuthAPI.listFootprints(session: session)
        } catch {
            message = "足迹同步失败：\(error.localizedDescription)"
        }
    }

    func sendChatMedia(data: Data, metadata: MediaUploadMetadata, type: String, mediaType: String? = nil) {
        guard chatGroupID != nil || chatFriendID != nil, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else {
            message = "请先进入好友聊天"
            return
        }
        Task { @MainActor in
            let draftID = "local-\(UUID().uuidString)"
            let draft = makeLocalMessage(id: draftID, type: type, body: "", mediaID: draftID)
            do {
                if let groupID = chatGroupID {
                    let scope = LocalChatStore.groupScope(groupID)
                    LocalChatStore.saveMedia(data, mediaID: draftID)
                    LocalChatStore.append(draft, scope: scope)
                    chatMessages = LocalChatStore.messages(scope: scope, query: chatSearch)
                    let asset = try await AuthAPI.uploadMedia(data: data, groupID: groupID, visibility: .group, metadata: metadata, session: session, mediaType: mediaType)
                    let sent = try await AuthAPI.sendMessage(groupID: groupID, type: type, body: "", mediaID: asset.id, session: session)
                    LocalChatStore.remove(messageID: draftID, scope: scope)
                    LocalChatStore.saveMedia(data, mediaID: asset.id)
                    LocalChatStore.append(sent, scope: scope)
                    let remote = try await AuthAPI.listMessages(groupID: groupID, query: chatSearch, session: session)
                    chatMessages = LocalChatStore.merge(remote, into: scope, query: chatSearch)
                    await cacheAndAcknowledge(remote, groupID: groupID, session: session)
                } else if let friendID = chatFriendID {
                    let scope = LocalChatStore.directScope(friendID)
                    LocalChatStore.saveMedia(data, mediaID: draftID)
                    LocalChatStore.append(draft, scope: scope)
                    chatMessages = LocalChatStore.messages(scope: scope, query: chatSearch)
                    let asset = try await AuthAPI.uploadMedia(data: data, groupID: nil, directFriendID: friendID, visibility: .private, metadata: metadata, session: session, mediaType: mediaType)
                    let sent = try await AuthAPI.sendDirectMessage(friendID: friendID, type: type, body: "", mediaID: asset.id, session: session)
                    LocalChatStore.remove(messageID: draftID, scope: scope)
                    LocalChatStore.saveMedia(data, mediaID: asset.id)
                    LocalChatStore.append(sent, scope: scope)
                    let remote = try await AuthAPI.listDirectMessages(friendID: friendID, query: chatSearch, session: session)
                    chatMessages = LocalChatStore.merge(remote, into: scope, query: chatSearch)
                    await cacheAndAcknowledge(remote, friendID: friendID, session: session)
                }
                await refreshFootprints()
                message = "原图媒体已发送"
            } catch { message = "媒体发送失败：\(error.localizedDescription)" }
        }
    }

    func createInvite() {
        guard let group = activeGroup, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        Task { @MainActor in
            do {
                inviteCode = try await AuthAPI.createInvite(groupID: group.id, session: session)
                accountMessage = "邀请码：\(inviteCode)"
            } catch { accountMessage = error.localizedDescription }
        }
    }

    func addGuestParticipant(_ name: String) async -> Bool {
        guard let group = activeGroup, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return false }
        do {
            let updated = try await AuthAPI.addGuestParticipant(groupID: group.id, name: name, session: session)
            activeGroup = updated
            syncCloudGroup(updated)
            await refreshGroups()
            accountMessage = "已将 \(name) 加入本次账单"
            return true
        } catch {
            accountMessage = error.localizedDescription
            return false
        }
    }

    private func syncCloudGroup(_ group: CloudGroup) {
        let memberNames = group.members.map { ($0.userId, $0.user?.displayName ?? "旅伴") }
        let guestNames = (group.guestParticipants ?? []).map { ($0.id, $0.name) }
        let namesByID = Dictionary(uniqueKeysWithValues: memberNames + guestNames)
        participants = memberNames.map(\.1) + guestNames.map(\.1)
        let remoteEntries = group.expenses.map { expense in
            ExpenseEntry(
                id: UUID(uuidString: expense.id) ?? UUID(),
                date: expense.date,
                item: expense.item,
                category: expense.category,
                amount: Double(expense.amountCents) / 100,
                source: .manual,
                reason: expense.visibility == .private ? "云端私人小项目" : "云端公共账单",
                splitMode: expense.splitMode,
                splitParticipants: expense.splitParticipants.compactMap { namesByID[$0] },
                splitAmounts: Dictionary(uniqueKeysWithValues: expense.splitAmounts.compactMap { id, cents in namesByID[id].map { ($0, Double(cents) / 100) } }),
                splitAutomatic: false,
                cloudID: expense.id,
                groupID: expense.groupId,
                visibility: expense.visibility,
                syncStatus: "synced",
                payerUserID: expense.payerUserId,
                splitParticipantIDs: expense.splitParticipants,
                splitAmountCents: expense.splitAmounts
            )
        }
        let remoteIDs = Set(group.expenses.map(\.id))
        let localPending = entries.filter { entry in
            if entry.groupID == nil { return true }
            return entry.groupID == group.id && (entry.cloudID == nil || !remoteIDs.contains(entry.cloudID ?? ""))
        }
        entries = localPending + remoteEntries
        persist()
    }

    private func syncEntryToCloud(_ entry: ExpenseEntry) {
        guard let group = activeGroup, entry.groupID == group.id, let user = currentUser, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        guard entry.amount > 0, !entry.date.isEmpty, !entry.item.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            if let index = entries.firstIndex(where: { $0.id == entry.id }) {
                entries[index].syncStatus = "waiting-review"
                persist()
            }
            return
        }
        let registered = group.members.map { ($0.user?.displayName ?? "旅伴", $0.userId) }
        let guests = (group.guestParticipants ?? []).map { ($0.name, $0.id) }
        let memberID = Dictionary(uniqueKeysWithValues: registered + guests)
        let allIDs = group.members.map(\.userId) + (group.guestParticipants ?? []).map(\.id)
        let selectedIDs = entry.splitParticipants.compactMap { memberID[$0] }
        let customAmounts = Dictionary(uniqueKeysWithValues: entry.splitAmounts.compactMap { name, amount in memberID[name].map { ($0, Int((amount * 100).rounded())) } })
        let mode = entry.visibility == .private ? SplitMode.none : entry.splitMode
        let body: [String: Any] = [
            "date": entry.date,
            "item": entry.item,
            "category": entry.category.rawValue,
            "amountCents": Int((entry.amount * 100).rounded()),
            "visibility": entry.visibility.rawValue,
            "payerUserId": user.id,
            "splitMode": mode.rawValue,
            "splitParticipants": mode == .all ? allIDs : selectedIDs,
            "splitAmounts": customAmounts,
        ]
        let participantIDs = mode == .all ? allIDs : selectedIDs
        if let index = entries.firstIndex(where: { $0.id == entry.id }) {
            entries[index].payerUserID = user.id
            entries[index].splitParticipantIDs = participantIDs
            entries[index].splitAmountCents = customAmounts
            persist()
        }
        Task { @MainActor in
            do {
                let saved = if let cloudID = entry.cloudID {
                    try await AuthAPI.updateExpense(groupID: group.id, expenseID: cloudID, body: body, session: session)
                } else {
                    try await AuthAPI.createExpense(groupID: group.id, body: body, session: session)
                }
                guard let index = entries.firstIndex(where: { $0.id == entry.id }) else { return }
                entries[index].cloudID = saved.id
                entries[index].groupID = group.id
                entries[index].syncStatus = "synced"
                entries[index].payerUserID = user.id
                entries[index].splitParticipantIDs = participantIDs
                entries[index].splitAmountCents = customAmounts
                persist()
            } catch {
                accountMessage = "费用已保存在本机，云端同步失败：\(error.localizedDescription)"
            }
        }
    }

    private func syncPersonalEntry(_ entry: ExpenseEntry) {
        guard entry.groupID == nil, let tripID = entry.personalTripID, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { return }
        guard entry.amount > 0, !entry.date.isEmpty, !entry.item.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            if let index = entries.firstIndex(where: { $0.id == entry.id }) {
                entries[index].syncStatus = "waiting-review"
                persist()
            }
            return
        }
        let body: [String: Any] = [
            "date": entry.date,
            "item": entry.item,
            "category": entry.category.rawValue,
            "amountCents": Int((entry.amount * 100).rounded()),
            "source": entry.source.rawValue,
        ]
        Task { @MainActor in
            do {
                let saved = if let cloudID = entry.cloudID {
                    try await AuthAPI.updatePersonalExpense(tripID: tripID, expenseID: cloudID, body: body, session: session)
                } else {
                    try await AuthAPI.createPersonalExpense(tripID: tripID, body: body, session: session)
                }
                guard let index = entries.firstIndex(where: { $0.id == entry.id }) else { return }
                entries[index].cloudID = saved.id
                entries[index].syncStatus = "synced"
                persist()
                await refreshPersonalTrips()
            } catch { message = "个人账单云端同步失败：\(error.localizedDescription)" }
        }
    }

    func claimMacPairing() {
        let code = manualPairingCode.filter(\.isNumber)
        manualPairingCode = code
        guard code.count == 6 else {
            accountMessage = "请输入 Mac 上显示的 6 位配对码"
            return
        }
        guard let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty else { accountMessage = "请先登录账号"; return }
        Task { @MainActor in
            do {
                try await AuthAPI.claimPairing(code: code, session: session)
                manualPairingCode = ""
                accountMessage = "Mac 配对成功，Mac 会自动完成独立登录"
            } catch {
                accountMessage = error.localizedDescription
            }
        }
    }

    func addParticipant() {
        let name = manualParticipantName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { message = "请输入同行人姓名"; return }
        guard !participants.contains(name) else { message = "这个姓名已经加入"; return }
        participants.append(name)
        manualParticipantName = ""
        entries.indices.forEach { index in
            if entries[index].splitAutomatic { entries[index].splitMode = SplitDetails.suggest(item: entries[index].item, category: entries[index].category).mode }
        }
        persist()
        entries.forEach { syncEntryToCloud($0) }
    }

    func removeParticipant(_ name: String) {
        participants.removeAll { $0 == name }
        entries.indices.forEach { index in
            if participants.isEmpty && entries[index].splitAutomatic { entries[index].splitMode = .none }
            entries[index].splitParticipants.removeAll { $0 == name }
            entries[index].splitAmounts[name] = nil
        }
        persist()
        entries.forEach { syncEntryToCloud($0) }
    }

    func setSplitMode(id: UUID, mode: SplitMode) {
        guard let index = entries.firstIndex(where: { $0.id == id }) else { return }
        entries[index].splitMode = mode
        entries[index].splitAutomatic = false
        if mode == .selected && entries[index].splitParticipants.isEmpty { entries[index].splitParticipants = participants }
        if mode != .custom { entries[index].splitAmounts = [:] }
        persist()
        syncEntryToCloud(entries[index])
    }

    func toggleSplitParticipant(id: UUID, name: String) {
        guard let index = entries.firstIndex(where: { $0.id == id }) else { return }
        if entries[index].splitParticipants.contains(name) {
            entries[index].splitParticipants.removeAll { $0 == name }
        } else {
            entries[index].splitParticipants.append(name)
        }
        entries[index].splitAutomatic = false
        persist()
        syncEntryToCloud(entries[index])
    }

    func setSplitAmount(id: UUID, name: String, amount: Double) {
        guard let index = entries.firstIndex(where: { $0.id == id }) else { return }
        entries[index].splitAmounts[name] = amount
        persist()
        syncEntryToCloud(entries[index])
    }

    func scheduleManualClassification() {
        classificationTask?.cancel()
        let item = manualItem
        guard item.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2 else {
            classificationReason = ""
            return
        }
        classificationTask = Task {
            try? await Task.sleep(for: .milliseconds(550))
            guard !Task.isCancelled else { return }
            let result = await CategoryClassifier.classifySmart(item, learned: learnedCategories)
            guard !Task.isCancelled, manualItem == item else { return }
            manualCategory = result.category
            classificationReason = result.reason
        }
    }

    func addManualEntry() {
        let item = manualItem.trimmingCharacters(in: .whitespacesAndNewlines)
        let amount = Double(manualAmount.replacingOccurrences(of: ",", with: "")) ?? 0
        guard !item.isEmpty else { message = "请填写项目"; return }
        guard amount > 0 else { message = "请填写正确金额"; return }
        let inFriendsBill = workspace == .friends && activeGroup != nil
        let targetGroupID = inFriendsBill ? activeGroup?.id : nil
        let targetVisibility: ExpenseVisibility = inFriendsBill ? manualVisibility : .private
        entries.append(ExpenseEntry(
            date: DateText.isoDate(manualDate),
            item: item,
            category: manualCategory,
            amount: amount,
            reason: classificationReason,
            splitMode: (!inFriendsBill || manualVisibility == .private) ? .none : (participants.isEmpty ? .none : SplitDetails.suggest(item: item, category: manualCategory).mode),
            splitAutomatic: true,
            groupID: targetGroupID,
            personalTripID: targetGroupID == nil ? activePersonalTripID : nil,
            visibility: targetVisibility,
            syncStatus: targetGroupID == nil ? "local" : "pending"
        ))
        remember(item: item, category: manualCategory)
        manualItem = ""
        manualAmount = ""
        manualCategory = .shopping
        classificationReason = ""
        message = "已加入账单"
        persist()
        if let entry = entries.last {
            if entry.groupID != nil { syncEntryToCloud(entry) }
            else { syncPersonalEntry(entry) }
        }
    }

    func updateEntry(_ entry: ExpenseEntry) {
        guard let index = entries.firstIndex(where: { $0.id == entry.id }) else { return }
        var value = entry
        value.needsReview = value.date.isEmpty || value.item.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || value.amount <= 0
        if !value.needsReview { value.reason = "已检查" }
        entries[index] = value
        persist()
        if value.groupID != nil { syncEntryToCloud(value) } else { syncPersonalEntry(value) }
    }

    func reclassifyEntry(id: UUID, item: String) {
        Task {
            let result = await CategoryClassifier.classifySmart(item, learned: learnedCategories)
            guard let index = entries.firstIndex(where: { $0.id == id }), entries[index].item == item else { return }
            entries[index].category = result.category
            entries[index].reason = result.reason
            if entries[index].splitAutomatic { entries[index].splitMode = participants.isEmpty ? .none : SplitDetails.suggest(item: item, category: result.category).mode }
            entries[index].needsReview = entries[index].date.isEmpty || entries[index].amount <= 0 || result.confidence < 0.7
            persist()
            if entries[index].groupID != nil { syncEntryToCloud(entries[index]) } else { syncPersonalEntry(entries[index]) }
        }
    }

    func setCategory(id: UUID, category: ExpenseCategory) {
        guard let index = entries.firstIndex(where: { $0.id == id }) else { return }
        entries[index].category = category
        entries[index].reason = "已手动选择分类"
        entries[index].needsReview = entries[index].date.isEmpty || entries[index].amount <= 0
        if entries[index].splitAutomatic { entries[index].splitMode = participants.isEmpty ? .none : SplitDetails.suggest(item: entries[index].item, category: category).mode }
        remember(item: entries[index].item, category: category)
        persist()
        if entries[index].groupID != nil { syncEntryToCloud(entries[index]) } else { syncPersonalEntry(entries[index]) }
    }

    func deleteEntry(id: UUID) {
        let deleted = entries.first(where: { $0.id == id })
        if let fuelID = deleted?.fuelID {
            fuelRecords.removeAll { $0.id == fuelID }
        }
        entries.removeAll { $0.id == id }
        persist()
        if let deleted, let cloudID = deleted.cloudID, let group = activeGroup, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty {
            Task { @MainActor in
                do {
                    try await AuthAPI.deleteExpense(groupID: group.id, expenseID: cloudID, session: session)
                } catch {
                    accountMessage = "本机已删除，云端删除失败：\(error.localizedDescription)"
                }
            }
        } else if let deleted, let cloudID = deleted.cloudID, let tripID = deleted.personalTripID, let session = UserDefaults.standard.string(forKey: sessionKey), !session.isEmpty {
            Task { @MainActor in
                do {
                    try await AuthAPI.deletePersonalExpense(tripID: tripID, expenseID: cloudID, session: session)
                    await refreshPersonalTrips()
                } catch {
                    message = "本机已删除，云端删除失败：\(error.localizedDescription)"
                }
            }
        }
    }

    func clearAll() {
        if workspace == .friends, let groupID = activeGroup?.id {
            entries.removeAll { $0.groupID == groupID }
            fuelRecords.removeAll { fuel in !entries.contains(where: { $0.fuelID == fuel.id }) }
            message = "已清空当前好友账单的本机明细"
        } else {
            entries.removeAll { $0.groupID == nil }
            fuelRecords.removeAll { fuel in !entries.contains(where: { $0.fuelID == fuel.id }) }
            participants = []
            message = "已清空当前个人账单"
        }
        lastExportURL = nil
        persist()
        if let activeGroup { syncCloudGroup(activeGroup) }
    }

    func importImages(_ images: [UIImage]) async {
        guard !images.isEmpty else { return }
        isWorking = true
        isRecognizingImages = true
        imageRecognitionCompleted = 0
        imageRecognitionTotal = images.count
        message = "正在识别 0 / \(images.count) 张图片…"
        var added = 0
        var duplicates = 0
        var failed = 0
        for (index, image) in images.enumerated() {
            do {
                let observations = try await VisionOCRService.recognize(image)
                let document = OCRParser.parse(observations: observations, learned: learnedCategories, referenceDate: DateText.isoDate())
                switch document {
                case let .expenses(candidates):
                    for candidate in candidates {
                        let smart = await CategoryClassifier.classifySmart(candidate.item, learned: learnedCategories)
                        let date = candidate.date
                        let amount = candidate.amount ?? 0
                        var reviewFields = candidate.reviewFields
                        if smart.confidence < 0.7 { reviewFields.append("分类") }
                        let entry = ExpenseEntry(
                            date: date,
                            item: candidate.item,
                            category: smart.category,
                            amount: amount,
                            source: .image,
                            reason: reviewFields.isEmpty ? smart.reason : "\(Array(Set(reviewFields)).joined(separator: "、"))待确认",
                            needsReview: !reviewFields.isEmpty || date.isEmpty || amount <= 0,
                            transactionTime: candidate.transactionTime,
                            splitMode: (workspace != .friends || activeGroup == nil || manualVisibility == .private) ? .none : (participants.isEmpty ? .none : SplitDetails.suggest(item: candidate.item, category: smart.category).mode),
                            splitAutomatic: true,
                            groupID: workspace == .friends ? activeGroup?.id : nil,
                            personalTripID: workspace == .personal ? activePersonalTripID : nil,
                            visibility: workspace == .friends ? manualVisibility : .private,
                            syncStatus: workspace == .friends && activeGroup != nil ? "pending" : "local"
                        )
                        if isDuplicate(entry) {
                            duplicates += 1
                        } else {
                            entries.append(entry)
                            added += 1
                            if entry.groupID != nil { syncEntryToCloud(entry) }
                            else { syncPersonalEntry(entry) }
                        }
                    }
                case let .fuel(candidate):
                    try await addExplicitFuel(candidate)
                    added += 1
                case .empty:
                    break
                }
            } catch {
                failed += 1
            }
            imageRecognitionCompleted = index + 1
            message = "正在识别 \(imageRecognitionCompleted) / \(imageRecognitionTotal) 张图片…"
        }
        message = "已识别 \(added) 笔\(duplicates > 0 ? "，合并 \(duplicates) 笔重复记录" : "")\(reviewCount > 0 ? "，\(reviewCount) 笔待确认" : "")\(failed > 0 ? "，\(failed) 张未能识别" : "")"
        persist()
        isRecognizingImages = false
        imageRecognitionCompleted = 0
        imageRecognitionTotal = 0
        isWorking = false
    }

    func importFuelTable(data: Data, filename: String) async {
        isWorking = true
        message = "正在读取油耗表…"
        do {
            let records = try FuelTableImporter.read(data: data, filename: filename)
            for record in records {
                let candidate = OCRFuelCandidate(date: record.date, route: record.route, distance: record.distance, consumption: record.consumption)
                try await addExplicitFuel(candidate, imported: record)
            }
            message = "已加入 \(records.count) 笔油耗费用"
            persist()
        } catch {
            message = error.localizedDescription
        }
        isWorking = false
    }

    func refreshFuel(id: UUID, province: String, grade: String) async {
        guard let fuelIndex = fuelRecords.firstIndex(where: { $0.id == id }) else { return }
        do {
            let quote = try await FuelPriceService.quote(province: province, grade: grade)
            fuelRecords[fuelIndex].province = quote.province
            fuelRecords[fuelIndex].grade = grade
            fuelRecords[fuelIndex].price = quote.price
            fuelRecords[fuelIndex].priceDate = quote.date
            syncFuelExpense(fuelRecords[fuelIndex], priceAvailable: true)
            message = "已更新 \(quote.province) \(grade) 当前参考油价"
            persist()
        } catch {
            message = error.localizedDescription
        }
    }

    func exportExcel() {
        guard !entries.isEmpty else { message = "请先加入费用"; return }
        guard reviewCount == 0 else { message = "还有 \(reviewCount) 笔待确认，检查后才能导出"; return }
        guard splitReviewCount == 0 else { message = "还有 \(splitReviewCount) 笔分账未完成，检查后才能导出"; return }
        do {
            let result = try XLSXExporter.makeWorkbook(entries: currentEntries, fuelRecords: fuelRecords, participants: participants, personalUserID: workspace == .friends ? currentUser?.id : nil, personalName: currentUser?.displayName ?? "")
            try XLSXExporter.verify(result.data, expectsFuel: !fuelRecords.isEmpty, expectsSplit: !participants.isEmpty && currentEntries.contains { $0.splitMode != .none }, expectsPersonal: currentUser != nil && workspace == .friends)
            let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
            let url = folder.appendingPathComponent(result.filename)
            try result.data.write(to: url, options: .atomic)
            let saved = try Data(contentsOf: url)
            guard saved.count == result.data.count else { throw XLSXExporter.ExportError.incompleteWorkbook }
            lastExportURL = url
            message = "Excel 已生成并核对成功"
        } catch {
            message = error.localizedDescription
        }
    }

    private func addExplicitFuel(_ candidate: OCRFuelCandidate, imported: FuelRecord? = nil) async throws {
        let date = candidate.date.isEmpty ? DateText.isoDate(manualDate) : candidate.date
        let inferredTrip = TripInference.infer(entries: [ExpenseEntry(date: date, item: candidate.route, category: .transport, amount: 0)], fuelRecords: [])
        var record = imported ?? FuelRecord(date: date, route: candidate.route, distance: candidate.distance, consumption: candidate.consumption)
        record.date = date
        if record.province.isEmpty { record.province = inferredTrip.province }
        if record.grade.isEmpty { record.grade = "95#" }
        var hasPrice = record.price > 0
        if !hasPrice, !record.province.isEmpty {
            do {
                let quote = try await FuelPriceService.quote(province: record.province, grade: record.grade)
                record.price = quote.price
                record.priceDate = quote.date
                hasPrice = true
            } catch { hasPrice = false }
        }
        fuelRecords.append(record)
            syncFuelExpense(record, priceAvailable: hasPrice)
    }

    private func syncFuelExpense(_ record: FuelRecord, priceAvailable: Bool) {
        let item = "自驾油费\(record.route.isEmpty ? "" : "（\(record.route)）") · \(record.grade)"
        if let index = entries.firstIndex(where: { $0.fuelID == record.id }) {
            entries[index].date = record.date
            entries[index].item = item
            entries[index].amount = record.cost
            entries[index].needsReview = !priceAvailable
            entries[index].reason = priceAvailable ? "由明确导入的油耗记录与当前参考油价计算" : "当前油价待确认"
            if entries[index].groupID != nil { syncEntryToCloud(entries[index]) } else { syncPersonalEntry(entries[index]) }
        } else {
            entries.append(ExpenseEntry(
                date: record.date,
                item: item,
                category: .transport,
                amount: record.cost,
                source: .fuel,
                reason: priceAvailable ? "由明确导入的油耗记录与当前参考油价计算" : "当前油价待确认",
                needsReview: !priceAvailable,
                fuelID: record.id,
                splitMode: participants.isEmpty ? .none : .all,
                splitParticipants: participants,
                splitAutomatic: true,
                groupID: workspace == .friends ? activeGroup?.id : nil,
                personalTripID: workspace == .personal ? activePersonalTripID : nil,
                visibility: workspace == .friends ? .group : .private,
                syncStatus: workspace == .friends && activeGroup != nil ? "pending" : "local"
            ))
            if let entry = entries.last {
                if entry.groupID != nil { syncEntryToCloud(entry) } else { syncPersonalEntry(entry) }
            }
        }
    }

    private func isDuplicate(_ candidate: ExpenseEntry) -> Bool {
        entries.contains { entry in
            abs(entry.amount - candidate.amount) < 0.005 &&
            CategoryClassifier.normalize(entry.item) == CategoryClassifier.normalize(candidate.item) &&
            (entry.date == candidate.date || (!entry.transactionTime.isEmpty && entry.transactionTime == candidate.transactionTime))
        }
    }

    private func remember(item: String, category: ExpenseCategory) {
        let key = CategoryClassifier.normalize(item)
        guard key.count >= 2 else { return }
        learnedCategories[key] = category
    }

    private func persist() {
        let draft = BillDraft(entries: entries, fuelRecords: fuelRecords, participants: participants, learnedCategories: learnedCategories, selectedDate: DateText.isoDate(manualDate))
        if let data = try? JSONEncoder().encode(draft) { UserDefaults.standard.set(data, forKey: defaultsKey) }
    }

    private func restore() {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey), let draft = try? JSONDecoder().decode(BillDraft.self, from: data) else { return }
        entries = draft.entries
        fuelRecords = draft.fuelRecords
        participants = draft.participants
        learnedCategories = draft.learnedCategories
        manualDate = DateText.date(from: draft.selectedDate) ?? Date()
    }

    private func restoreAccount() {
        guard let data = UserDefaults.standard.data(forKey: accountKey), let account = try? JSONDecoder().decode(AccountUser.self, from: data) else { return }
        currentUser = account
    }
}
