import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { cloudFetch } from '../lib/cloud-transport.mjs';

function environment(t, values) {
  const before = Object.fromEntries(Object.keys(values).map(key => [key, process.env[key]]));
  for (const [key, value] of Object.entries(values)) value === undefined ? delete process.env[key] : process.env[key] = value;
  t.after(() => { for (const [key, value] of Object.entries(before)) value === undefined ? delete process.env[key] : process.env[key] = value; });
}
const legacyPayload = database => Buffer.from(JSON.stringify(database)).toString('base64');
const response = (value, status = 200) => new Response(JSON.stringify(value), { status, headers: { 'content-type': 'application/json' } });
async function remoteStore(t, fetcher) {
  environment(t, { TRAVEL_BILL_STATE_STORE: 'supabase', SUPABASE_URL: 'https://cloud-fixture.invalid', SUPABASE_SERVICE_ROLE_KEY: 'test-only-not-a-credential', TRAVEL_BILL_RELAY_KEY: 'test-only-relay-key' });
  t.mock.method(globalThis, 'fetch', fetcher);
  return import(`../lib/account-store.mjs?test=${randomUUID()}`);
}

test('cloud transport categorizes failures without secrets or automatic retries', async () => {
  for (const [reason, expected] of [['ENOTFOUND', 'CLOUD_DNS_UNAVAILABLE'], ['ECONNRESET', 'CLOUD_CONNECTION_UNAVAILABLE'], ['UND_ERR_CONNECT_TIMEOUT', 'CLOUD_TIMEOUT'], ['UNKNOWN', 'CLOUD_TRANSPORT_UNAVAILABLE']]) {
    let calls = 0;
    await assert.rejects(() => cloudFetch('https://cloud-fixture.invalid/auth/v1/otp', { method: 'POST', body: 'private OTP request' }, { fetcher: async (_url, options) => {
      calls++; assert.ok(options.signal); assert.equal(options.redirect, 'error');
      throw Object.assign(new TypeError('fetch failed: private-email-and-key'), { cause: { code: reason } });
    } }), error => error.statusCode === 503 && error.code === expected && !JSON.stringify(error).includes('private-email-and-key'));
    assert.equal(calls, 1);
  }
});

test('cloud transport enforces a deadline rather than leaving a request pending', async () => {
  const keepAlive = setTimeout(() => {}, 1000);
  try {
    await assert.rejects(() => cloudFetch('https://cloud-fixture.invalid', {}, { timeoutMs: 10, fetcher: (_url, { signal }) => new Promise((_, reject) => signal.addEventListener('abort', () => reject(signal.reason), { once: true })) }), { code: 'CLOUD_TIMEOUT', statusCode: 503 });
  } finally { clearTimeout(keepAlive); }
});

test('corrupt cloud payloads fail closed and cannot initialize or overwrite an empty bill', async t => {
  let writes = 0;
  let payload = 'unreadable-encrypted-data';
  const store = await remoteStore(t, async (_url, options) => {
    if (options.method === 'POST') { writes++; return response({}); }
    return response([{ payload }]);
  });
  for (const value of ['unreadable-encrypted-data', legacyPayload({}), legacyPayload({ users: [], expenses: 'corrupt' }), null, '']) {
    payload = value;
    await assert.rejects(() => store.findUser('keeper'), { code: 'CLOUD_STATE_UNREADABLE' });
    await assert.rejects(() => store.findOrCreateUser({ provider: 'test', providerSubject: 'new' }), { code: 'CLOUD_STATE_UNREADABLE' });
  }
  assert.equal(writes, 0);
});

test('failed cloud save does not publish a draft and forces a fresh read before another write', async t => {
  const initial = { users: [{ id: 'keeper', provider: 'test', providerSubject: 'owner', displayName: '旅伴' }] };
  let payload = legacyPayload(initial), reads = 0, failWrite = true;
  const store = await remoteStore(t, async (_url, options) => {
    if (options.method === 'POST') {
      if (failWrite) return response({}, 503);
      payload = JSON.parse(options.body).payload;
      return response({});
    }
    reads++; return response([{ payload }]);
  });
  await assert.rejects(() => store.bindUserName('keeper', '未保存的名称'));
  assert.equal((await store.findUser('keeper')).displayName, '旅伴');
  assert.equal(reads, 2);
  failWrite = false;
  await store.bindUserName('keeper', '已保存的名称');
  assert.equal((await store.findUser('keeper')).displayName, '已保存的名称');
});

test('an unknown remote commit is re-read, not overwritten from a stale cached snapshot', async t => {
  let payload = legacyPayload({ users: [{ id: 'keeper', provider: 'test', providerSubject: 'owner', displayName: '旅伴' }] });
  const store = await remoteStore(t, async (_url, options) => {
    if (options.method === 'POST') {
      payload = JSON.parse(options.body).payload; // Server accepted it before the connection broke.
      throw Object.assign(Error('fetch failed'), { cause: { code: 'ECONNRESET' } });
    }
    return response([{ payload }]);
  });
  await assert.rejects(() => store.bindUserName('keeper', '已到达云端'), { code: 'CLOUD_CONNECTION_UNAVAILABLE' });
  assert.equal((await store.findUser('keeper')).displayName, '已到达云端');
  assert.equal((await store.bindUserName('keeper', '已到达云端')).nameBound, true, 'Retry after lost response must return the saved binding without another write');
});

test('concurrent initial reads initialize a truly empty cloud table only once', async t => {
  let reads = 0, writes = 0;
  const store = await remoteStore(t, async (_url, options) => {
    if (options.method === 'POST') { writes++; return response({}); }
    reads++; await new Promise(resolve => setTimeout(resolve, 5)); return response([]);
  });
  assert.deepEqual(await Promise.all([store.findUser('a'), store.findUser('b')]), [null, null]);
  assert.equal(reads, 1); assert.equal(writes, 1);
});

test('corrupt local data stays byte-for-byte unchanged and never becomes an empty account', async t => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'travelbill-local-safety-'));
  environment(t, { TRAVEL_BILL_STATE_STORE: undefined, TRAVEL_BILL_DATA_DIR: directory });
  const file = path.join(directory, 'travel-bill-server.json');
  const original = '{"users": [broken fixture';
  await fs.writeFile(file, original);
  const store = await import(`../lib/account-store.mjs?test=${randomUUID()}`);
  await assert.rejects(() => store.findOrCreateUser({ provider: 'test', providerSubject: 'owner' }), { code: 'LOCAL_STATE_UNREADABLE' });
  assert.equal(await fs.readFile(file, 'utf8'), original);
});

test('auth provider outages and credential errors are distinct from a genuine expired OTP', async t => {
  environment(t, { SUPABASE_URL: 'https://cloud-fixture.invalid', SUPABASE_SERVICE_ROLE_KEY: 'test-only-not-a-credential' });
  let status = 503, body = { message: 'do not expose upstream details' }, calls = 0;
  t.mock.method(globalThis, 'fetch', async () => { calls++; return response(body, status); });
  const { requestSupabaseEmailOtp, verifySupabaseEmailOtp } = await import('../lib/auth.mjs');
  await assert.rejects(() => requestSupabaseEmailOtp({ type: 'email', value: 'test@example.invalid' }), { code: 'CLOUD_AUTH_UNAVAILABLE' });
  status = 401; body = { code: 'bad_jwt', message: 'Expired service credential' };
  await assert.rejects(() => verifySupabaseEmailOtp({ email: 'test@example.invalid', code: '123456' }), { code: 'CLOUD_AUTH_CONFIGURATION' });
  status = 403; body = { code: 'otp_expired', message: 'Token has expired or is invalid' };
  await assert.rejects(() => verifySupabaseEmailOtp({ email: 'test@example.invalid', code: '123456' }), { statusCode: 400, message: '验证码不正确或已过期，请重新获取' });
  assert.equal(calls, 3);
});

test('a malformed successful upstream response must not be announced as an OTP sent', async t => {
  environment(t, { SUPABASE_URL: 'https://cloud-fixture.invalid', SUPABASE_SERVICE_ROLE_KEY: 'test-only-not-a-credential' });
  t.mock.method(globalThis, 'fetch', async () => new Response('gateway incomplete response', { status: 200 }));
  const { requestSupabaseEmailOtp } = await import('../lib/auth.mjs');
  await assert.rejects(() => requestSupabaseEmailOtp({ type: 'email', value: 'test@example.invalid' }), { code: 'CLOUD_AUTH_INVALID_RESPONSE', statusCode: 503 });
});
