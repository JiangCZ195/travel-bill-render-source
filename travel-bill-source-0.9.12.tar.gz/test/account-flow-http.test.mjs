import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

test('isolated account, Mac pairing and bill workflows over real HTTP', { timeout: 45000 }, async t => {
  const source = fileURLToPath(new URL('../', import.meta.url));
  const sandbox = await fs.mkdtemp(path.join(os.tmpdir(), 'travelbill-account-flow-'));
  await fs.mkdir(path.join(sandbox, 'accounts'));
  await fs.writeFile(path.join(sandbox, 'accounts/travel-bill-server.json'), JSON.stringify({ users: [
    { id: 'legacy-named', provider: 'supabase', providerSubject: 'fixture:legacy@example.invalid', email: 'legacy@example.invalid', displayName: '已有名字', createdAt: '2026-08-17T00:00:00Z' },
  ] }));
  await fs.copyFile(path.join(source, 'server.mjs'), path.join(sandbox, 'server.mjs'));
  await fs.mkdir(path.join(sandbox, 'lib'));
  for (const name of (await fs.readdir(path.join(source, 'lib'))).filter(name => name.endsWith('.mjs'))) {
    await fs.writeFile(path.join(sandbox, 'lib', name), await fs.readFile(path.join(source, 'lib', name)));
  }
  const protocol = path.join(source, 'services/local-vision/protocol.mjs');
  try {
    await fs.access(protocol);
    await fs.mkdir(path.join(sandbox, 'services/local-vision'), { recursive: true });
    await fs.copyFile(protocol, path.join(sandbox, 'services/local-vision/protocol.mjs'));
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  await fs.symlink(process.env.TRAVEL_BILL_TEST_NODE_MODULES || path.join(source, 'node_modules'), path.join(sandbox, 'node_modules'));
  await fs.symlink(path.join(source, 'public'), path.join(sandbox, 'public'));
  const socket = createServer(); socket.listen(0, '127.0.0.1'); await once(socket, 'listening');
  const port = socket.address().port; await new Promise(resolve => socket.close(resolve));
  const base = `http://127.0.0.1:${port}`;
  let child, logs = '';
  async function stop() {
    if (!child || child.exitCode !== null || child.signalCode !== null) return;
    const done = once(child, 'exit'); child.kill('SIGTERM');
    const timer = setTimeout(() => child.kill('SIGKILL'), 2000);
    try { await done; } finally { clearTimeout(timer); }
  }
  async function start() {
    child = spawn(process.execPath, ['--import', path.join(source, 'test-support/account-flow-provider.mjs'), 'server.mjs'], {
      cwd: sandbox, stdio: ['ignore', 'pipe', 'pipe'], env: {
        NODE_ENV: 'production', PORT: String(port), HOST: '127.0.0.1', AUTO_OPEN: '0',
        TRAVEL_BILL_FAULT_TEST: 'account-flow-fixture', TRAVEL_BILL_DATA_DIR: path.join(sandbox, 'accounts'),
        TRAVEL_BILL_STATE_STORE: 'local', TRAVEL_BILL_MEDIA_STORE: 'local', TRAVEL_BILL_OTP_PROVIDER: 'supabase',
        TRAVEL_BILL_AUTH_SECRET: 'test-only-not-production', SUPABASE_URL: 'https://cloud-fixture.invalid', SUPABASE_SERVICE_ROLE_KEY: 'test-only',
      },
    });
    child.stdout.on('data', value => { logs += value; }); child.stderr.on('data', value => { logs += value; });
    for (let i = 0; i < 200; i++) {
      if (child.exitCode !== null) throw Error(`Fixture exited: ${logs}`);
      try { if ((await fetch(base + '/api/health', { signal: AbortSignal.timeout(200) })).ok) return; } catch {}
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    throw Error(`Fixture startup deadline: ${logs}`);
  }
  t.after(stop); await start();
  async function call(route, { method = 'GET', body, session = '', headers = {} } = {}) {
    const response = await fetch(base + route, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(session ? { Authorization: `Bearer ${session}` } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(5000) });
    const raw = await response.text();
    return { status: response.status, headers: response.headers, body: raw ? JSON.parse(raw) : null };
  }
  let phone, other, mac, personalId, groupId;
  await t.test('OTP success establishes one account and the next request is throttled', async () => {
    const first = await call('/api/auth/request-code', { method: 'POST', body: { identifier: 'owner@example.invalid' } });
    assert.equal(first.status, 200); assert.equal(first.body.expiresIn, 300); assert.equal(first.body.resendAfter, 60);
    assert.equal((await call('/api/auth/request-code', { method: 'POST', body: { identifier: 'owner@example.invalid' } })).status, 429);
    phone = (await call('/api/auth/verify-code', { method: 'POST', body: { identifier: 'owner@example.invalid', code: '333333', displayName: '验收账号' } })).body;
    assert.ok(phone.session); assert.equal(phone.user.displayName, '旅伴');
    assert.equal(phone.user.nameBound, false, 'Name in old login request must be ignored');
    assert.equal((await call('/api/auth/me', { session: phone.session })).body.user.id, phone.user.id);
    other = (await call('/api/auth/verify-code', { method: 'POST', body: { identifier: 'other@example.invalid', code: '333333' } })).body;
  });
  await t.test('name binding is authenticated, validated, persistent and idempotent', async () => {
    const route = '/api/account/bind-name';
    assert.equal((await call(route, { method: 'POST', body: { displayName: '冒用名字' } })).status, 401);
    for (const displayName of ['', '  ', '字'.repeat(21), '名\n字', { name: '不是字符串' }]) {
      assert.equal((await call(route, { method: 'POST', session: phone.session, body: { displayName } })).status, 400);
    }
    assert.equal((await call('/api/auth/me', { session: phone.session })).body.user.nameBound, false);
    const bound = await call(route, { method: 'POST', session: phone.session, body: { displayName: '  验收账号  ', userId: other.user.id } });
    assert.equal(bound.status, 200); assert.equal(bound.body.user.id, phone.user.id);
    assert.equal(bound.body.user.displayName, '验收账号'); assert.equal(bound.body.user.nameBound, true);
    assert.equal((await call('/api/auth/me', { session: other.session })).body.user.nameBound, false, 'Cannot bind another account by supplying userId');
    assert.equal((await call(route, { method: 'POST', session: phone.session, body: { displayName: '验收账号' } })).status, 200);
    assert.equal((await call(route, { method: 'POST', session: phone.session, body: { displayName: '另一个名字' } })).status, 409);
    const again = await call('/api/auth/verify-code', { method: 'POST', body: { identifier: ' OWNER@example.invalid ', code: '333333', displayName: '不能覆盖' } });
    assert.equal(again.body.user.id, phone.user.id); assert.equal(again.body.user.displayName, '验收账号');
    assert.equal(again.body.user.nameBound, true);
    const sameName = await call(route, { method: 'POST', session: other.session, body: { displayName: '验收账号' } });
    assert.equal(sameName.status, 200, 'Different accounts can have the same real-world name');
    assert.notEqual(sameName.body.user.id, phone.user.id);
  });
  await t.test('legacy account keeps its existing name without onboarding again', async () => {
    const result = await call('/api/auth/verify-code', { method: 'POST', body: { identifier: 'legacy@example.invalid', code: '333333' } });
    assert.equal(result.body.user.id, 'legacy-named');
    assert.equal(result.body.user.displayName, '已有名字'); assert.equal(result.body.user.nameBound, true);
    assert.equal((await call('/api/account/bind-name', { method: 'POST', session: result.body.session, body: { displayName: '覆盖老用户' } })).status, 409);
  });
  await t.test('concurrent devices cannot overwrite the first bound name', async () => {
    const login = (await call('/api/auth/verify-code', { method: 'POST', body: { identifier: 'race@example.invalid', code: '333333' } })).body;
    const results = await Promise.all(['先绑定', '后绑定'].map(displayName => call('/api/account/bind-name', { method: 'POST', session: login.session, body: { displayName } })));
    assert.deepEqual(results.map(result => result.status).sort(), [200, 409]);
    const saved = (await call('/api/auth/me', { session: login.session })).body.user;
    assert.equal(saved.displayName, results.find(result => result.status === 200).body.user.displayName);
    assert.equal(saved.nameBound, true);
  });
  await t.test('parallel OTP taps are coalesced before sending email', async () => {
    const count = () => logs.split('FIXTURE_OTP_DELIVERY').length - 1;
    const before = count();
    const results = await Promise.all(Array.from({ length: 3 }, () => call('/api/auth/request-code', { method: 'POST', body: { identifier: 'parallel@example.invalid' } })));
    assert.deepEqual(results.map(r => r.status).sort(), [200, 429, 429]);
    assert.equal(count() - before, 1);
  });
  await t.test('Mac pairing grants the same account and rejects reuse or a wrong polling secret', async () => {
    const pairing = (await call('/api/pairing/create', { method: 'POST', body: { deviceId: 'mac-acceptance' } })).body;
    assert.equal((await call('/api/pairing/create', { method: 'POST', body: { deviceId: 'mac-acceptance' } })).status, 429);
    assert.equal((await call('/api/pairing/status?id=' + pairing.id + '&token=wrong')).body.status, 'pending');
    assert.equal((await call('/api/pairing/claim', { method: 'POST', session: phone.session, body: { code: pairing.displayCode } })).status, 200);
    mac = (await call('/api/pairing/status?id=' + pairing.id + '&token=' + encodeURIComponent(pairing.token))).body;
    assert.equal(mac.status, 'claimed'); assert.equal(mac.user.id, phone.user.id);
    assert.equal(mac.user.nameBound, true); assert.equal(mac.user.displayName, '验收账号');
    assert.equal((await call('/api/pairing/claim', { method: 'POST', session: phone.session, body: { code: pairing.code } })).status, 404);
    assert.equal((await call('/api/pairing/status?id=' + pairing.id + '&token=' + encodeURIComponent(pairing.token))).body.status, 'pending');
  });
  await t.test('Mac rename preflight is allowed only for the local app origin', async () => {
    const valid = await call('/api/personal/trips/test', { method: 'OPTIONS', headers: { Origin: 'http://127.0.0.1:4174', 'Access-Control-Request-Method': 'PATCH' } });
    assert.equal(valid.status, 204); assert.match(valid.headers.get('access-control-allow-methods'), /PATCH/);
    const denied = await fetch(base + '/api/personal/trips/test', { method: 'OPTIONS', headers: { Origin: 'https://untrusted.invalid' } });
    assert.equal(denied.status, 403); assert.equal(denied.headers.get('access-control-allow-origin'), null);
  });
  await t.test('personal bills can be renamed and read on paired Mac but are private to the owner', async () => {
    personalId = (await call('/api/personal/trips', { method: 'POST', session: phone.session, body: { name: '个人验收旅行' } })).body.trip.id;
    assert.equal((await call('/api/personal/trips/' + personalId, { method: 'PATCH', session: mac.session, body: { name: '已修改旅行名' } })).body.trip.name, '已修改旅行名');
    assert.equal((await call('/api/personal/trips/' + personalId + '/expenses', { method: 'POST', session: phone.session, body: { date: '10月3日', item: '麦当劳早饭', amountCents: 2500, category: '吃喝' } })).status, 201);
    assert.equal((await call('/api/personal/trips/' + personalId, { session: other.session })).status, 404);
    assert.equal((await call('/api/personal/trips', { session: mac.session })).body.trips.length, 1);
  });
  await t.test('group members see public expenses but never another member private expenses', async () => {
    groupId = (await call('/api/bills', { method: 'POST', session: phone.session, body: { name: '共同验收旅行' } })).body.group.id;
    const invite = (await call('/api/bills/' + groupId + '/invites', { method: 'POST', session: phone.session, body: {} })).body.invite;
    assert.equal((await call('/api/bills/join', { method: 'POST', session: other.session, body: { code: invite.code } })).status, 200);
    for (const visibility of ['group', 'private']) {
      const result = await call('/api/bills/' + groupId + '/expenses', { method: 'POST', session: phone.session, body: { date: '10月3日', item: visibility === 'group' ? '共同吃饭' : '个人纪念品', amountCents: 12000, category: '吃喝', visibility, splitMode: visibility === 'group' ? 'all' : 'none', splitParticipants: visibility === 'group' ? [phone.user.id, other.user.id] : [] } });
      assert.equal(result.status, 201, JSON.stringify(result.body));
    }
    const view = (await call('/api/bills/' + groupId, { session: other.session })).body.group;
    assert.deepEqual(view.expenses.map(e => e.item), ['共同吃饭']);
    assert.equal((await call('/api/bills/' + groupId, { method: 'DELETE', session: other.session })).status, 404);
  });
  await t.test('sessions, trips and ownership survive a server restart; deletion remains effective', async () => {
    await stop(); await start();
    assert.equal((await call('/api/auth/me', { session: mac.session })).body.user.id, phone.user.id);
    assert.equal((await call('/api/auth/me', { session: mac.session })).body.user.displayName, '验收账号');
    assert.equal((await call('/api/auth/me', { session: mac.session })).body.user.nameBound, true);
    assert.equal((await call('/api/personal/trips', { session: phone.session })).body.trips[0].name, '已修改旅行名');
    assert.equal((await call('/api/bills/' + groupId, { method: 'DELETE', session: mac.session })).status, 200);
    assert.equal((await call('/api/personal/trips/' + personalId, { method: 'DELETE', session: mac.session })).status, 200);
    await stop(); await start();
    assert.equal((await call('/api/personal/trips', { session: phone.session })).body.trips.length, 0);
    assert.equal((await call('/api/bills', { session: phone.session })).body.groups.length, 0);
  });
});
