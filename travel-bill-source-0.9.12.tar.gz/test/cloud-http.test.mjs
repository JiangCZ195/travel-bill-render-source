import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

test('real HTTP routes preserve 503 for upstream outages, 400 for expired OTP and redact diagnostics', { timeout: 45000 }, async t => {
  const reservation = createServer(); reservation.listen(0, '127.0.0.1'); await once(reservation, 'listening');
  const port = reservation.address().port; await new Promise(resolve => reservation.close(resolve));
  const sandbox = await fs.mkdtemp(path.join(os.tmpdir(), 'travelbill-http-safety-'));
  const folder = path.join(sandbox, 'isolated-accounts');
  await fs.mkdir(folder);
  const source = fileURLToPath(new URL('../', import.meta.url));
  // Copy source only; never load real account files, local vision credentials or
  // let server startup create media directories in the user's checkout.
  await fs.copyFile(path.join(source, 'server.mjs'), path.join(sandbox, 'server.mjs'));
  await fs.mkdir(path.join(sandbox, 'lib'));
  // Stream file contents instead of APFS clone/copy: cloning evicted iCloud
  // files can stall before the test server has even started.
  await Promise.all((await fs.readdir(path.join(source, 'lib'))).filter(name => name.endsWith('.mjs')).map(async name => {
    await fs.writeFile(path.join(sandbox, 'lib', name), await fs.readFile(path.join(source, 'lib', name)));
  }));
  await fs.symlink(path.join(source, 'public'), path.join(sandbox, 'public'));
  const dependencies = process.env.TRAVEL_BILL_TEST_NODE_MODULES || path.join(source, 'node_modules');
  await fs.symlink(dependencies, path.join(sandbox, 'node_modules'));
  const child = spawn(process.execPath, ['--import', fileURLToPath(new URL('../test-support/cloud-provider-loader.mjs', import.meta.url)), 'server.mjs'], {
    cwd: sandbox, stdio: ['ignore', 'pipe', 'pipe'], env: {
      NODE_ENV: 'production', PORT: String(port), HOST: '127.0.0.1', AUTO_OPEN: '0',
      TRAVEL_BILL_FAULT_TEST: 'isolated-fixture', TRAVEL_BILL_DATA_DIR: folder,
      TRAVEL_BILL_STATE_STORE: 'local', TRAVEL_BILL_MEDIA_STORE: 'local',
      TRAVEL_BILL_OTP_PROVIDER: 'supabase', TRAVEL_BILL_AUTH_SECRET: 'test-only',
      SUPABASE_URL: 'https://cloud-fixture.invalid', SUPABASE_SERVICE_ROLE_KEY: 'test-only',
    },
  });
  let logs = ''; child.stdout.on('data', value => { logs += value; }); child.stderr.on('data', value => { logs += value; });
  t.after(async () => {
    if (child.exitCode !== null || child.signalCode !== null) return;
    const done = once(child, 'exit'); child.kill('SIGTERM');
    const timer = setTimeout(() => child.kill('SIGKILL'), 3000);
    try { await done; } finally { clearTimeout(timer); }
  });
  const base = `http://127.0.0.1:${port}`;
  let ready = false;
  for (let index = 0; index < 200; index++) {
    if (child.exitCode !== null) throw Error(`Isolated server failed to start: ${logs}`);
    try { ready = (await fetch(base + '/api/health', { signal: AbortSignal.timeout(200) })).ok; } catch {}
    if (ready) break; await new Promise(resolve => setTimeout(resolve, 50));
  }
  assert.ok(ready, `Server did not start: ${logs}`);
  // Allow cold dependency loading on an iCloud checkout. Transport deadline
  // behavior itself is verified independently in cloud-safety.test.mjs.
  const post = (route, body) => fetch(base + route, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(8000) });
  const unavailable = await post('/api/auth/request-code', { identifier: 'test@example.invalid' });
  assert.equal(unavailable.status, 503); assert.equal((await unavailable.json()).code, 'CLOUD_DNS_UNAVAILABLE');
  const expired = await post('/api/auth/verify-code', { identifier: 'test@example.invalid', code: '111111' });
  assert.equal(expired.status, 400); assert.match((await expired.json()).error, /验证码不正确或已过期/);
  const credential = await post('/api/auth/verify-code', { identifier: 'test@example.invalid', code: '222222' });
  assert.equal(credential.status, 503); assert.equal((await credential.json()).code, 'CLOUD_AUTH_CONFIGURATION');
  assert.doesNotMatch(logs, /credential-must-not-appear|secret-service-key-expired|test@example\.invalid/);
  assert.deepEqual(await fs.readdir(folder), [], 'Error handling must not create a bill/account database');
});
