import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';

async function fixture(pairings = []) {
  const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'travelbill-pairing-regression-'));
  const file = path.join(folder, 'travel-bill-server.json');
  await fs.writeFile(file, JSON.stringify({ users: [{ id: 'phone-user' }], pairings }));
  process.env.TRAVEL_BILL_DATA_DIR = folder;
  process.env.TRAVEL_BILL_STATE_STORE = 'local';
  const store = await import(`../lib/account-store.mjs?pairing=${encodeURIComponent(folder)}`);
  return { file, store };
}
const hash = value => createHash('sha256').update(value).digest('hex');
const pairing = overrides => ({ id: 'active', code: '123456', tokenHash: hash('mac-secret'), deviceId: 'mac', expiresAt: new Date(Date.now() + 300000).toISOString(), consumedAt: '', claimedUserId: '', ...overrides });

test('an expired or consumed historical code cannot shadow a current pairing', async () => {
  for (const old of [pairing({ id: 'expired', expiresAt: '2000-01-01T00:00:00Z' }), pairing({ id: 'used', consumedAt: '2000-01-01T00:00:00Z' })]) {
    const { store } = await fixture([old, pairing({})]);
    assert.deepEqual(await store.claimPairing('phone-user', '', '123 456'), { ok: true });
    assert.equal(await store.consumePairing('active', 'mac-secret'), 'phone-user');
    assert.equal(await store.consumePairing('active', 'mac-secret'), null, 'pairing exchange is one-use');
  }
});

test('pending, invalid-token and already consumed polling never rewrites account state', async () => {
  const { file, store } = await fixture([pairing({})]);
  const sentinel = new Date('2000-01-01T00:00:00Z');
  await fs.utimes(file, sentinel, sentinel);
  const before = await fs.readFile(file, 'utf8');
  assert.equal(await store.consumePairing('active', 'mac-secret'), null);
  assert.equal(await store.consumePairing('active', 'wrong-token'), null);
  assert.equal(await fs.readFile(file, 'utf8'), before);
  assert.equal((await fs.stat(file)).mtimeMs, sentinel.getTime());
  await store.claimPairing('phone-user', '', '123456');
  const result = await Promise.all([store.consumePairing('active', 'mac-secret'), store.consumePairing('active', 'mac-secret')]);
  assert.equal(result.filter(Boolean).length, 1);
  await fs.utimes(file, sentinel, sentinel);
  assert.equal(await store.consumePairing('active', 'mac-secret'), null);
  assert.equal((await fs.stat(file)).mtimeMs, sentinel.getTime());
});

test('pairing keeps five-minute expiry, cooldown and account claim isolation', async () => {
  const { store } = await fixture();
  const first = await store.createPairing({ deviceId: 'mac-1' });
  assert.match(first.code, /^\d{6}$/);
  assert.ok(Date.parse(first.expiresAt) - Date.now() <= 300000);
  assert.ok(Date.parse(first.expiresAt) - Date.now() > 295000);
  const duplicate = await store.createPairing({ deviceId: 'mac-1' });
  assert.equal(duplicate.reason, 'cooldown');
  assert.equal(duplicate.token, undefined);
  assert.equal(duplicate.code, undefined);
  const claims = await Promise.all([store.claimPairing('phone-user', first.id, first.code), store.claimPairing('another-user', first.id, first.code)]);
  assert.equal(claims.filter(value => value.ok).length, 1);
  assert.equal((await store.claimPairing('phone-user', 'not-this-id', first.code)).reason, 'not_found');
});
