// Motion is presentation-only: data refreshes never replay navigation transitions.
export function routeKey(state) {
  return JSON.stringify([state.activeTab, state.viewMode,
    state.viewMode === 'detail' ? (state.activeTab === 'personal' ? state.activePersonalTripId : state.activeGroup?.id) : '',
    state.activeChatGroupId || state.activeChatFriendId || '']);
}

export function createPageMotion(win, doc) {
  const positions = new Map();
  let previousKey = null, revision = 0, animations = [];
  return {
    begin(key) {
      if (previousKey === key) return () => {};
      if (previousKey !== null) positions.set(previousKey, win.scrollY);
      const first = previousKey === null;
      previousKey = key;
      const current = ++revision;
      animations.forEach(animation => animation.cancel());
      animations = [];
      // Do not leave the keyboard or focus in an element on the outgoing page.
      doc.activeElement?.blur?.();
      return () => {
        win.requestAnimationFrame(() => {
          if (current !== revision) return;
          win.scrollTo({ top: positions.get(key) || 0, behavior: 'instant' });
          if (first || win.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
          for (const surface of doc.querySelectorAll('.workspace, .summary-card:not(.hidden)')) {
            if (typeof surface.animate !== 'function') continue;
            animations.push(surface.animate([
              { opacity: 0.45, transform: 'translateY(6px)' },
              { opacity: 1, transform: 'translateY(0)' },
            ], { duration: 200, easing: 'cubic-bezier(.2,.8,.2,1)' }));
          }
        });
      };
    },
  };
}
