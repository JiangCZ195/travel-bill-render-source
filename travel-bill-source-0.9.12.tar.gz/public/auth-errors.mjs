// A reachable API can still fail to reach its authentication provider.
// Do not blame the code or expose internal English transport errors.
export function friendlyLoginError(error) {
  const raw = String(error?.message || '').trim();
  const lower = raw.toLowerCase();
  if (error?.status === 429 || /频繁|过多/.test(raw) || /rate limit|too many|security purposes/.test(lower)) return '验证码请求过于频繁，请等待倒计时结束后再获取';
  if (/fetch failed|failed to fetch|econnreset|enotfound|econnrefused|upstream/.test(lower) || error?.status >= 500) return '账号服务暂时无法完成请求，请稍后重试；这不代表验证码错误，本机账单不会被清空';
  if (/network|could not connect|not connected|timed out/.test(lower) || raw.includes('无法连接')) return '暂时无法连接账号服务，请检查网络后重试';
  if (/expired|invalid otp|invalid token/.test(lower)) return '验证码不正确或已过期，请重新获取';
  return raw || '账号服务暂时不可用，请稍后重试';
}
