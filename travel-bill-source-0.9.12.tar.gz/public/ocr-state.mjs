export function canSyncExpense(entry) {
  return !entry.needsReview && !entry.ocrConfirmationRequired && Number.isFinite(Number(entry.amount)) && Number(entry.amount) > 0 && Boolean(entry.date) && Boolean(String(entry.item || '').trim());
}
export function sameBill(a, b) { return (a.groupId || '') === (b.groupId || '') && (a.personalTripId || '') === (b.personalTripId || '') && (a.visibility || 'private') === (b.visibility || 'private'); }
export function requiredOCRChecks(entry) {
  const labels = { date: '日期', amount: '金额', item: '项目', category: '分类', hotel: '酒店', refund: '退款' };
  const required = (entry.reviewFields || []).map(field => labels[field] || field);
  if (!entry.date) required.push('日期');
  if (!Number.isFinite(Number(entry.amount)) || !(Number(entry.amount) > 0)) required.push('金额');
  if (!String(entry.item || '').trim() || /待确认|图片识别/.test(entry.item)) required.push('项目');
  if (Number(entry.confidence) < 0.7 || /请确认/.test(entry.reason || '')) required.push('分类');
  return [...new Set(required)];
}
export function learnableItem(value) {
  const key = String(value || '').normalize('NFKC').replace(/\s+/g, '');
  return key.length >= 2 && !/待确认|图片识别|[¥￥]|\d{3,}|(?:^|→)酒店(?=→|[（(]|$)/.test(key) && !/^(?:酒店|饭店|吃饭|购物|交通|其他|美团(?:外卖|闪购)?|抖音|微信|支付宝|高德|打车|车费|早饭|午饭|晚饭)$/.test(key);
}
export function mergeRemoteBill(local, remote, { groupId, personalTripId }) {
  if (Boolean(groupId) === Boolean(personalTripId)) return local;
  const belongs = entry => groupId ? entry.groupId === groupId : !entry.groupId && entry.personalTripId === personalTripId;
  const pending = local.filter(entry => belongs(entry) && (!entry.remoteId || entry.needsReview || entry.ocrConfirmationRequired || entry.syncStatus !== 'synced'));
  const protectedIDs = new Set(pending.map(entry => entry.remoteId).filter(Boolean));
  return [...local.filter(entry => !belongs(entry)), ...pending, ...remote.filter(entry => belongs(entry) && !protectedIDs.has(entry.remoteId)).map(entry => {
    const previous = local.find(old => sameBill(old, entry) && old.remoteId === entry.remoteId && old.date === entry.date && old.item === entry.item && Number(old.amount) === Number(entry.amount));
    return previous ? { ...previous, ...entry, source: previous.source, reviewImageID: previous.reviewImageID, transactionTime: previous.transactionTime } : entry;
  })];
}
export function matchingImageExpense(entries, next) {
  const compact = value => String(value || '').normalize('NFKC').toLowerCase().replace(/[^\u4e00-\u9fffA-Za-z0-9]/g, '');
  return entries.find(entry => {
    if (entry.source !== 'image' || !sameBill(entry, next)) return false;
    if (entry.sourceEvidenceID && entry.sourceEvidenceID === next.sourceEvidenceID) return true;
    if (!next.date || !next.transactionTime || next.date !== entry.date || next.transactionTime !== entry.transactionTime || /待确认|图片识别/.test(next.item)) return false;
    return Number(next.amount) > 0 && Number(entry.amount) > 0 && Math.abs(Number(entry.amount) - Number(next.amount)) < 0.005 && compact(entry.item) === compact(next.item);
  });
}
