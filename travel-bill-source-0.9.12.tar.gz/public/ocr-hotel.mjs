// A payment date is not proof of a stay. These are references for human review.
export function fullHotelName(value) {
  const name = String(value || '').replace(/[（(]\d+晚[）)]/g, '').trim();
  if (!/酒店|宾馆|民宿|客栈|青旅/.test(name) || /退款|已退|待确认|→/.test(name) || /^(?:酒店|宾馆|民宿|客栈|青旅)(?:住宿|费用|住宿费)?$/.test(name)) return '';
  return name;
}
export function hasHotelPlaceholder(item) { return /(?:^|→)酒店(?=→|（|$)/.test(String(item || '')); }
export function replaceHotelPlaceholder(item, name) {
  const hotel = fullHotelName(name);
  return hotel ? String(item).replace(/(^|→)酒店(?=→|（|$)/g, (_, prefix) => prefix + hotel) : item;
}
export function hotelReferences(entries, current) {
  if (current.category !== '交通' || !hasHotelPlaceholder(current.item)) return [];
  if (!current.groupId && !current.personalTripId) return [];
  const seen = new Set();
  return entries.filter(entry => (entry.groupId || '') === (current.groupId || '') && (entry.personalTripId || '') === (current.personalTripId || '') && entry.category === '玩住' && !entry.needsReview && !entry.ocrConfirmationRequired && !entry.itemNeedsReview && !entry.categoryNeedsReview && Number(entry.amount) > 0)
    .map(entry => ({ name: fullHotelName(entry.item), date: entry.date || '' }))
    .filter(entry => { if (!entry.name || seen.has(entry.name)) return false; seen.add(entry.name); return true; });
}
