// Search only explicit bill fields, never OCR source text or unrelated trips.
export function matchesExpense(entry, query) {
  const tokens = String(query || "").normalize("NFKC").trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  const date = String(entry.date || "");
  const shortDate = /^\d{4}-\d{2}-\d{2}$/.test(date) ? `${Number(date.slice(5, 7))}月${Number(date.slice(8, 10))}日` : "";
  const amount = Number(entry.amount);
  const text = [entry.item, entry.category, date, shortDate, Number.isFinite(amount) ? amount.toFixed(2) : ""]
    .join(" ").normalize("NFKC").toLocaleLowerCase();
  return tokens.every((token) => text.includes(token));
}

export function filterExpenses(entries, { query = "", category = "", reviewOnly = false, needsReview = (entry) => entry.needsReview } = {}) {
  return entries.filter((entry) => matchesExpense(entry, query) && (!category || entry.category === category) && (!reviewOnly || needsReview(entry)));
}
