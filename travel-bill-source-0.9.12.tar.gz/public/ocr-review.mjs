import { replaceHotelPlaceholder } from './ocr-hotel.mjs';
const headers = { 'Content-Type': 'application/json', 'X-TravelBill-Vision': '1' };
async function api(route, input, signal) {
  const response = await fetch(`/api/local-vision/${route}`, { method: input ? 'POST' : 'GET', headers, body: input ? JSON.stringify(input) : undefined, signal });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || '辅助识别暂不可用');
  return payload;
}
function dialog(title) {
  const element = document.createElement('dialog'); element.className = 'ocr-review-dialog';
  element.innerHTML = `<header><h2></h2><button type="button" aria-label="关闭">×</button></header><div class="ocr-review-content"></div>`;
  element.querySelector('h2').textContent = title;
  const controller = new AbortController();
  element.querySelector('button').onclick = () => element.close();
  element.addEventListener('close', () => { controller.abort(); element.remove(); }, { once: true });
  document.body.append(element); element.showModal();
  return { element, content: element.querySelector('.ocr-review-content'), signal: controller.signal };
}
function showSourceImage(source, ownerSignal) {
  const { element, content, signal } = dialog('查看原图');
  element.classList.add('ocr-image-dialog');
  content.innerHTML = `<div class="ocr-image-tools"><button type="button" aria-label="缩小原图">−</button><output aria-live="polite"></output><button type="button" aria-label="放大原图">＋</button><button type="button" class="ocr-image-fit">适合窗口</button><button type="button" class="ocr-image-actual">原始大小</button></div><div class="ocr-image-stage" tabindex="0" aria-label="原图，放大后可滚动查看"><img alt="当前费用原图，轻点两下放大或还原" draggable="false" /></div>`;
  const stage = content.querySelector('.ocr-image-stage'), image = stage.querySelector('img');
  const [minus, plus, fitButton, actualButton] = content.querySelectorAll('.ocr-image-tools button');
  let scale = 1, fit = 1;
  const applyScale = next => {
    if (!image.naturalWidth) return;
    const centerX = (stage.scrollLeft + stage.clientWidth / 2) / Math.max(image.offsetWidth, stage.clientWidth);
    const centerY = (stage.scrollTop + stage.clientHeight / 2) / Math.max(image.offsetHeight, stage.clientHeight);
    scale = Math.max(fit, Math.min(Math.max(2, fit * 8), next));
    image.style.width = `${image.naturalWidth * scale}px`;
    content.querySelector('output').textContent = `${Math.round(scale * 100)}%`;
    minus.disabled = scale <= fit + .0001;
    plus.disabled = scale >= Math.max(2, fit * 8) - .0001;
    stage.scrollLeft = centerX * Math.max(image.offsetWidth, stage.clientWidth) - stage.clientWidth / 2;
    stage.scrollTop = centerY * Math.max(image.offsetHeight, stage.clientHeight) - stage.clientHeight / 2;
  };
  const resize = () => {
    if (!image.naturalWidth || !stage.clientWidth) return;
    const previousFit = fit;
    fit = Math.min(stage.clientWidth / image.naturalWidth, stage.clientHeight / image.naturalHeight, 1);
    applyScale(scale <= previousFit + .0001 ? fit : scale);
  };
  const observer = new ResizeObserver(resize); observer.observe(stage);
  image.onload = () => { resize(); applyScale(fit); };
  image.src = source;
  minus.onclick = () => applyScale(scale / 1.5);
  plus.onclick = () => applyScale(scale * 1.5);
  fitButton.onclick = () => applyScale(fit);
  actualButton.onclick = () => applyScale(1);
  image.ondblclick = () => applyScale(scale > fit + .0001 ? fit : Math.max(1, fit * 2));
  stage.addEventListener('keydown', event => {
    if (['+', '=', '-', '0'].includes(event.key)) {
      event.preventDefault(); applyScale(event.key === '0' ? fit : event.key === '-' ? scale / 1.5 : scale * 1.5);
    }
  });
  const close = () => element.close();
  ownerSignal.addEventListener('abort', close, { once: true });
  signal.addEventListener('abort', () => { observer.disconnect(); ownerSignal.removeEventListener('abort', close); }, { once: true });
}
// Internal import rule. Candidates are source-bound in the service cache; no bill is changed.
export async function reviewImportedImages(imageIDs, { signal, isCurrent = () => true, progress = () => {} } = {}) {
  const ids = [...new Set(imageIDs.filter(Boolean))];
  if (!ids.length || signal?.aborted || !isCurrent()) return;
  try {
    const status = await api('status', undefined, signal);
    if (!status.available || status.busy || signal?.aborted || !isCurrent()) return;
    for (const [index, imageID] of ids.entries()) {
      if (signal?.aborted || !isCurrent()) return;
      progress(index, ids.length);
      await api('recognize', { imageID }, signal);
      if (signal?.aborted || !isCurrent()) return;
      progress(index + 1, ids.length);
    }
  } catch { /* Keep local OCR and review flags; stop this batch on unavailable assistance. */ }
}
export async function showOCRReview(entry, apply, { hotels = [] } = {}) {
  const { element, content, signal } = dialog('原图核对');
  content.innerHTML = `<div class="ocr-source"><p role="status">正在读取原图…</p><img hidden alt="当前费用对应的原图区域" /></div><div class="ocr-review-grid"><label>日期<input name="date" type="date" required /></label><label>金额<input name="amount" type="number" min="0.01" step="0.01" required /></label><label class="ocr-wide">项目<input name="item" maxlength="200" required /></label></div><button type="button" class="vision-run" hidden>重新识别备注</button><div class="vision-progress" hidden><progress></progress><span role="status"></span></div><div class="vision-candidates" hidden></div><p class="vision-error" role="status"></p><label class="ocr-confirm"><input type="checkbox" />我已对照原图核对日期、金额与项目</label><button class="vision-save" type="button">确认并保存</button>`;
  const categoryLabel = document.createElement('label'); categoryLabel.className = 'ocr-wide'; categoryLabel.textContent = '分类';
  const category = document.createElement('select'); category.name = 'category';
  for (const value of ['玩住', '交通', '吃喝', '购物', '用品']) { const option = document.createElement('option'); option.value = option.textContent = value; category.append(option); }
  category.value = ['玩住', '交通', '吃喝', '购物', '用品'].includes(entry.category) ? entry.category : '购物';
  categoryLabel.append(category); content.querySelector('.ocr-review-grid').append(categoryLabel);
  content.querySelector('.ocr-confirm').lastChild.textContent = '我已对照原图核对日期、金额、项目与分类';
  const date = content.querySelector('[name=date]'), amount = content.querySelector('[name=amount]'), item = content.querySelector('[name=item]');
  date.value = entry.date || ''; amount.value = entry.amount > 0 ? entry.amount : ''; item.value = entry.item || '';
  if (hotels.length) {
    const label = document.createElement('label'); label.className = 'ocr-wide'; label.textContent = '本账单的酒店参考';
    const select = document.createElement('select'); select.name = 'hotel';
    const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = '选择实际入住酒店'; select.append(placeholder);
    for (const hotel of hotels) { const option = document.createElement('option'); option.value = hotel.name; option.textContent = `${hotel.name}${hotel.date ? ` · 账单日期 ${hotel.date}` : ''}`; select.append(option); }
    const note = document.createElement('small'); note.textContent = '付款日期不代表入住日期。选择后仅替换路线中的“酒店”简称，不改动已有地点名称。';
    let routeTemplate = item.value;
    item.addEventListener('input', () => { routeTemplate = item.value; select.value = ''; });
    select.onchange = () => { if (select.value) { item.value = replaceHotelPlaceholder(routeTemplate, select.value); content.querySelector('[type=checkbox]').checked = false; } };
    label.append(select, note); content.querySelector('.ocr-review-grid').append(label);
  }
  const errorBox = content.querySelector('.vision-error'), run = content.querySelector('.vision-run'), progress = content.querySelector('.vision-progress'), candidates = content.querySelector('.vision-candidates');
  const image = content.querySelector('img');
  const zoom = document.createElement('button'); zoom.type = 'button'; zoom.className = 'ocr-source-zoom'; zoom.textContent = '放大查看原图'; zoom.hidden = true;
  zoom.onclick = () => showSourceImage(image.src, signal);
  content.querySelector('.ocr-source').append(zoom);
  image.onclick = () => showSourceImage(image.src, signal);
  run.disabled = true;
  run.onclick = async () => {
    errorBox.textContent = ''; run.disabled = true; run.hidden = true; progress.hidden = false;
    const started = Date.now();
    const update = () => { progress.querySelector('span').textContent = `正在复核图片 · ${Math.floor((Date.now() - started) / 1000)} 秒`; };
    const timer = setInterval(update, 1000); update();
    try {
      const result = await api('recognize', { imageID: entry.reviewImageID }, signal);
      if (signal.aborted) return;
      candidates.replaceChildren(); candidates.hidden = false;
      const heading = document.createElement('h3'); heading.textContent = '识别参考 · 请对照原图确认'; candidates.append(heading);
      for (const [key, label] of [['merchant','商户'],['annotation','备注'],['amount','金额'],['date','日期']]) {
        const row = document.createElement('p'); row.textContent = `${label}：${result.fields[key] || '未识别'}`; candidates.append(row);
      }
      const hint = document.createElement('p'); hint.textContent = '请放大原图核对后修改上方字段。退款不应计入费用；“酒店”需与这次旅程的住宿记录核对。'; candidates.append(hint);
    } catch { if (!signal.aborted) { errorBox.textContent = '进一步识别暂不可用，本机结果已保留，可以直接核对并保存。'; run.hidden = false; } }
    finally { clearInterval(timer); if (!signal.aborted) { run.disabled = false; progress.hidden = true; } }
  };
  const save = content.querySelector('.vision-save');
  let saving = false;
  // Bind before fetching the preview: controls are already visible and usable.
  save.onclick = async () => {
    if (saving || signal.aborted) return;
    if (!content.querySelector('[type=checkbox]').checked) { errorBox.textContent = '请先对照原图核对并勾选确认'; return; }
    if (![date, amount, item].every(field => field.reportValidity()) || !item.value.trim() || /待确认|图片识别记录/.test(item.value)) { errorBox.textContent = '请填写完整、准确的日期、项目和正数金额'; return; }
    saving = true; save.disabled = true; save.textContent = '正在保存…'; errorBox.textContent = '';
    try { await apply({ date: date.value, amount: Number(amount.value), item: item.value.trim(), category: category.value }); if (!signal.aborted) element.close(); }
    catch (error) { if (!signal.aborted) errorBox.textContent = error.message || '保存失败，请重试'; }
    finally { saving = false; if (!signal.aborted) { save.disabled = false; save.textContent = '确认并保存'; } }
  };
  try {
    const source = await api('preview', { imageID: entry.reviewImageID }, signal);
    if (signal.aborted) return;
    image.src = `data:image/png;base64,${source.image}`; image.hidden = false; zoom.hidden = false; content.querySelector('.ocr-source p').remove(); run.disabled = false;
    if (entry.needsReview || entry.ocrConfirmationRequired) void run.onclick();
  } catch (error) { if (!signal.aborted) { content.querySelector('.ocr-source p').textContent = `${error.message}。也可以在系统相册打开原图，逐项核对后在这里确认。`; } }
}
