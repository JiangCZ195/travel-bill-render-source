const CACHE = "travel-bill-app-v33-name-binding";
const APP_SHELL = ["/", "/styles.css", "/experience.css", "/motion.mjs", "/ocr-review.css", "/ocr-review.mjs", "/ocr-state.mjs", "/ocr-hotel.mjs", "/auth-errors.mjs", "/app.js", "/expense-query.mjs", "/split-details.mjs", "/manifest.webmanifest", "/travel-icon.svg", "/world-map.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key)))));
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET" || new URL(event.request.url).pathname.startsWith("/api/")) return;
  event.respondWith(fetch(event.request).then((response) => {
    const copy = response.clone();
    if (response.ok && new URL(event.request.url).origin === self.location.origin) {
      caches.open(CACHE).then((cache) => cache.put(event.request, copy));
    }
    return response;
  }).catch(() => caches.match(event.request)));
});
