// Used only by a child server with an isolated temporary data directory.
if (process.env.TRAVEL_BILL_FAULT_TEST !== 'account-flow-fixture') throw Error('Not a test process');
globalThis.fetch = async (url, options) => {
  if (new URL(url).hostname !== 'cloud-fixture.invalid') throw Error('External network prohibited by fixture');
  const body = JSON.parse(options.body);
  if (String(url).endsWith('/otp')) {
    console.info('FIXTURE_OTP_DELIVERY');
    await new Promise(resolve => setTimeout(resolve, 80));
    return Response.json({});
  }
  if (String(url).endsWith('/verify') && body.token === '333333') {
    return Response.json({ user: { id: `fixture:${body.email}`, email: body.email } });
  }
  return Response.json({ code: 'otp_expired', message: 'Token has expired or is invalid' }, { status: 403 });
};
