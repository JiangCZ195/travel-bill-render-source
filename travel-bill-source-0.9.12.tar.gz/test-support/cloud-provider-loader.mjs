// This loader is exclusively for the isolated HTTP regression child process.
// Keep it outside test/ so `node --test` never executes it as a test suite.
if (process.env.TRAVEL_BILL_FAULT_TEST !== 'isolated-fixture') throw Error('Not a test process');
globalThis.fetch = async (url, options) => {
  if (new URL(url).hostname !== 'cloud-fixture.invalid') throw Error('External network prohibited by fixture');
  const body = JSON.parse(options.body);
  if (String(url).endsWith('/otp')) throw Object.assign(new TypeError('fetch failed; credential-must-not-appear'), { cause: { code: 'ENOTFOUND' } });
  const result = body.token === '111111'
    ? { code: 'otp_expired', message: 'Token has expired or is invalid' }
    : { code: 'bad_jwt', message: 'secret-service-key-expired' };
  return new Response(JSON.stringify(result), { status: body.token === '111111' ? 403 : 401, headers: { 'content-type': 'application/json' } });
};
