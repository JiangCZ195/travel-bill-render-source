import test from 'node:test';
import assert from 'node:assert/strict';
import { createDecipheriv, createHash, randomUUID } from 'node:crypto';

const fixtureKey = 'bandwidth-regression-test-only';
const expired = '2000-01-01T00:00:00.000Z';
const future = '2100-01-01T00:00:00.000Z';
const stamp = '2026-01-01T00:00:00.000Z';

function seed(extra = {}) {
  return {
    users: ['sender', 'receiver', 'third'].map(id => ({ id, displayName: id, nameBound: true })),
    groups: [{ id: 'group', ownerId: 'sender', name: 'Synthetic trip' }],
    groupMembers: ['sender', 'receiver', 'third'].map(userId => ({ groupId: 'group', userId, role: userId === 'sender' ? 'owner' : 'member' })),
    friendships: [{ userIds: ['sender', 'receiver'] }],
    messages: [], directMessages: [], mediaAssets: [],
    ...extra,
  };
}

function unpack(payload) {
  const input = Buffer.from(payload, 'base64');
  if (input.subarray(0, 3).toString() !== 'TB1') return JSON.parse(input.toString());
  const decipher = createDecipheriv('aes-256-gcm', createHash('sha256').update(fixtureKey).digest(), input.subarray(3, 15));
  decipher.setAuthTag(input.subarray(15, 31));
  return JSON.parse(Buffer.concat([decipher.update(input.subarray(31)), decipher.final()]).toString());
}

async function fixture(t, database = seed()) {
  const values = { TRAVEL_BILL_STATE_STORE: 'supabase', TRAVEL_BILL_MEDIA_STORE: 'supabase', SUPABASE_URL: 'https://bandwidth-fixture.invalid', SUPABASE_SERVICE_ROLE_KEY: 'test-only-not-a-credential', TRAVEL_BILL_RELAY_KEY: fixtureKey };
  const before = Object.fromEntries(Object.keys(values).map(key => [key, process.env[key]]));
  Object.assign(process.env, values);
  t.after(() => { for (const [key, value] of Object.entries(before)) value === undefined ? delete process.env[key] : process.env[key] = value; });
  let payload = Buffer.from(JSON.stringify(database)).toString('base64');
  let failNextWrite = false;
  const stats = { reads: 0, writes: 0, uploadedBytes: 0, mediaDeletes: 0, mediaReads: 0 };
  t.mock.method(globalThis, 'fetch', async (url, options = {}) => {
    const parsed = new URL(url);
    assert.equal(parsed.hostname, 'bandwidth-fixture.invalid', 'Real network is prohibited');
    if (parsed.pathname.startsWith('/storage/v1/object/remove/')) {
      assert.equal(options.method, 'POST'); stats.mediaDeletes++;
      return Response.json({});
    }
    if (parsed.pathname.startsWith('/storage/v1/object/')) {
      stats.mediaReads++;
      return new Response('synthetic-media');
    }
    assert.equal(parsed.pathname, '/rest/v1/travel_bill_state');
    if (options.method === 'POST') {
      stats.writes++; stats.uploadedBytes += Buffer.byteLength(options.body);
      if (failNextWrite) { failNextWrite = false; return Response.json({}, { status: 503 }); }
      payload = JSON.parse(options.body).payload;
      return new Response(null, { status: 201 });
    }
    stats.reads++; return Response.json([{ payload }]);
  });
  const store = await import(`../lib/account-store.mjs?bandwidth=${randomUUID()}`);
  return { store, stats, saved: () => unpack(payload), failNextSave: () => { failNextWrite = true; } };
}

test('100 idle group and direct chat reads plus parallel polls upload no snapshots', async t => {
  const f = await fixture(t);
  for (let i = 0; i < 100; i++) {
    assert.deepEqual(await f.store.listGroupMessages('sender', 'group'), []);
    assert.deepEqual(await f.store.listDirectMessages('sender', 'receiver'), []);
  }
  await Promise.all(Array.from({ length: 50 }, () => f.store.listGroupMessages('receiver', 'group')));
  assert.deepEqual(f.stats, { reads: 1, writes: 0, uploadedBytes: 0, mediaDeletes: 0, mediaReads: 0 });
});

test('missing, unauthorized and already consumed acknowledgements never upload state', async t => {
  const f = await fixture(t);
  for (let i = 0; i < 100; i++) {
    assert.equal(await f.store.acknowledgeGroupMessage('sender', 'group', 'missing'), false);
    assert.equal(await f.store.acknowledgeDirectMessage('sender', 'receiver', 'missing'), false);
    assert.equal(await f.store.acknowledgeGroupMessage('stranger', 'group', 'missing'), false);
    assert.equal(await f.store.consumePairing('missing', 'not-a-secret'), null);
  }
  assert.equal(f.stats.writes, 0);
});

test('an unauthorized read cannot trigger global expiry mutations or media deletion', async t => {
  const f = await fixture(t, seed({ messages: [{ id: 'expired', groupId: 'group', relayExpiresAt: expired, deletedAt: '' }] }));
  assert.equal(await f.store.listGroupMessages('stranger', 'group'), null);
  assert.equal(await f.store.listDirectMessages('stranger', 'receiver'), null);
  assert.equal(f.stats.writes, 0);
  assert.equal(f.stats.mediaDeletes, 0);
});

test('group delivery writes only for a new receipt and retains messages until everyone receives', async t => {
  const f = await fixture(t);
  const message = await f.store.createGroupMessage('sender', 'group', { body: 'synthetic message' });
  assert.equal(f.stats.writes, 1);
  assert.equal(await f.store.acknowledgeGroupMessage('sender', 'group', message.id), true);
  assert.equal(f.stats.writes, 1, 'Sender already acknowledges at creation');
  assert.equal(await f.store.acknowledgeGroupMessage('receiver', 'group', message.id), true);
  assert.equal(f.stats.writes, 2);
  const receivedAt = f.saved().messages[0].updatedAt;
  await Promise.all(Array.from({ length: 50 }, () => f.store.acknowledgeGroupMessage('receiver', 'group', message.id)));
  assert.equal(f.stats.writes, 2, 'Receipt replay must not update timestamps');
  assert.equal(f.saved().messages[0].updatedAt, receivedAt);
  assert.equal((await f.store.listGroupMessages('third', 'group'))[0].body, 'synthetic message');
  assert.equal(await f.store.acknowledgeGroupMessage('third', 'group', message.id), true);
  assert.equal(f.stats.writes, 3);
  assert.deepEqual(await f.store.listGroupMessages('sender', 'group'), []);
  assert.equal(await f.store.acknowledgeGroupMessage('third', 'group', message.id), false);
  assert.equal(f.stats.writes, 3);
  assert.ok(f.saved().messages[0].deletedAt);
});

test('direct delivery and simultaneous duplicate receipts persist exactly once', async t => {
  const f = await fixture(t);
  const message = await f.store.createDirectMessage('sender', 'receiver', { body: 'synthetic direct message' });
  for (let i = 0; i < 20; i++) assert.equal(await f.store.acknowledgeDirectMessage('sender', 'receiver', message.id), true);
  assert.equal(f.stats.writes, 1);
  assert.equal((await f.store.listDirectMessages('receiver', 'sender'))[0].id, message.id);
  const results = await Promise.all(Array.from({ length: 50 }, () => f.store.acknowledgeDirectMessage('receiver', 'sender', message.id)));
  assert.equal(results.filter(Boolean).length, 1);
  assert.equal(f.stats.writes, 2);
  assert.deepEqual(await f.store.listDirectMessages('sender', 'receiver'), []);
});

test('parallel expiry cleanup saves one snapshot and clears expired orphan relay media', async t => {
  const expiredMessage = { id: 'expired-message', groupId: 'group', senderId: 'sender', body: 'expired', createdAt: stamp, updatedAt: stamp, relayExpiresAt: expired, mediaId: 'linked-media', deletedAt: '' };
  const liveMessage = { ...expiredMessage, id: 'live-message', body: 'live', relayExpiresAt: future, mediaId: '' };
  const media = id => ({ id, relayOnly: true, relayExpiresAt: expired, storagePath: `supabase://media/${id}`, deletedAt: '' });
  const f = await fixture(t, seed({ messages: [expiredMessage, liveMessage], mediaAssets: [media('linked-media'), media('orphan-media'), { ...media('avatar'), relayOnly: false }] }));
  const results = await Promise.all(Array.from({ length: 50 }, () => f.store.listGroupMessages('receiver', 'group')));
  for (const rows of results) assert.deepEqual(rows.map(row => row.id), ['live-message']);
  assert.equal(f.stats.writes, 1);
  assert.equal(f.stats.mediaDeletes, 2);
  assert.ok(f.saved().mediaAssets.find(row => row.id === 'orphan-media').deletedAt);
  assert.equal(f.saved().mediaAssets.find(row => row.id === 'avatar').deletedAt, '');
  await f.store.listGroupMessages('sender', 'group');
  assert.equal(f.stats.writes, 1);
});

test('expired relay media is inaccessible even before a chat triggers cleanup', async t => {
  const f = await fixture(t, seed({ mediaAssets: [{ id: 'expired-media', createdBy: 'sender', relayOnly: true, relayExpiresAt: expired, storagePath: 'supabase://media/expired-media', deletedAt: '' }] }));
  assert.equal(await f.store.getMediaFile('sender', 'expired-media'), null);
  assert.equal(f.stats.writes, 0);
  assert.equal(f.stats.mediaReads, 0);
});

test('idle polling and a real concurrent expense save cannot lose or duplicate that expense', async t => {
  const f = await fixture(t);
  const [expense] = await Promise.all([
    f.store.createExpense('sender', 'group', { date: '2026-10-07', item: 'synthetic expense', amountCents: 123, splitMode: 'none' }),
    ...Array.from({ length: 100 }, () => f.store.listGroupMessages('receiver', 'group')),
  ]);
  assert.equal(f.stats.writes, 1);
  assert.equal(f.saved().expenses.length, 1);
  assert.equal(f.saved().expenses[0].id, expense.id);
  assert.equal(f.saved().expenses[0].amountCents, 123);
});

test('unchanged rejected operations and pairing cooldown do not rewrite the snapshot', async t => {
  const f = await fixture(t);
  assert.equal(await f.store.archiveGroup('stranger', 'group'), false);
  assert.equal(await f.store.deleteExpense('sender', 'group', 'missing'), false);
  assert.deepEqual(await f.store.claimPairing('sender', '', 'bad'), { ok: false, reason: 'format' });
  assert.equal(f.stats.writes, 0);
  await f.store.createPairing({ deviceId: 'synthetic-mac' });
  assert.equal(f.stats.writes, 1);
  assert.equal((await f.store.createPairing({ deviceId: 'synthetic-mac' })).reason, 'cooldown');
  assert.equal(f.stats.writes, 1);
});

test('failed expiry save is not published and later polling retries from freshly read state', async t => {
  const f = await fixture(t, seed({ messages: [{ id: 'expired', groupId: 'group', senderId: 'sender', relayExpiresAt: expired, deletedAt: '' }] }));
  f.failNextSave();
  const first = await Promise.allSettled(Array.from({ length: 10 }, () => f.store.listGroupMessages('receiver', 'group')));
  assert.equal(first.filter(result => result.status === 'rejected').length, 10);
  assert.equal(f.stats.writes, 1, 'Concurrent readers share the failed operation instead of retrying it');
  assert.equal(f.saved().messages[0].deletedAt, '');
  assert.deepEqual(await f.store.listGroupMessages('receiver', 'group'), []);
  assert.equal(f.stats.reads, 2);
  assert.equal(f.stats.writes, 2);
  assert.ok(f.saved().messages[0].deletedAt);
});

test('a concurrent new message survives expiry cleanup and real changes each persist once', async t => {
  const f = await fixture(t, seed({ messages: [{ id: 'expired', groupId: 'group', senderId: 'sender', relayExpiresAt: expired, deletedAt: '' }] }));
  const results = await Promise.all([
    ...Array.from({ length: 30 }, () => f.store.listGroupMessages('receiver', 'group')),
    f.store.createGroupMessage('sender', 'group', { body: 'new synthetic message' }),
  ]);
  const sent = results.at(-1);
  assert.equal(f.stats.writes, 2);
  assert.ok(f.saved().messages.find(message => message.id === 'expired').deletedAt);
  assert.equal(f.saved().messages.find(message => message.id === sent.id).deletedAt, '');
  assert.equal((await f.store.listGroupMessages('receiver', 'group'))[0].body, 'new synthetic message');
  assert.equal(f.stats.writes, 2);
});
