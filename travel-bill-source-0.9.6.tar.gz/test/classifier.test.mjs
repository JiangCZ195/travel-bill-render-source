import assert from "node:assert/strict";
import test from "node:test";
import { classifyItem } from "../lib/classifier.mjs";
import { deduplicateOcrResults, parseExpenseText, parseFuelText } from "../lib/ocr.mjs";
import { buildTripFilename, inferTrip } from "../lib/trip.mjs";
import { classifyItemWithWeb } from "../lib/web-classifier.mjs";
import { formatTransportItem, inferAirports } from "../lib/transport-details.mjs";
import { splitIssue, splitLines, splitSuggestion } from "../lib/split-details.mjs";

test("高铁和飞机项目会整理成车站/机场路线并汇总机场", () => {
  assert.equal(formatTransportItem("12306 金华→贵阳火车票（2人）"), "金华站→贵阳北站（2人）");
  assert.equal(formatTransportItem("飞机票 杭州→贵阳"), "杭州萧山HGH→贵阳龙洞堡KWE");
  assert.deepEqual(inferAirports([{ item: "飞机票 杭州→贵阳" }]).map((airport) => airport.code), ["HGH", "KWE"]);
  assert.equal(formatTransportItem("贵阳→铜仁 68.00"), "贵阳→铜仁 68.00");
});

test("分账会区分共同消费与个人消费，未填姓名时按个人账处理", () => {
  assert.equal(splitSuggestion("火锅晚餐", "吃喝").mode, "all");
  assert.equal(splitSuggestion("地铁", "交通").mode, "none");
  assert.deepEqual(splitLines({ amount: 101, splitMode: "all" }, []), []);
  assert.equal(splitIssue({ amount: 101, splitMode: "all" }, []), "请先填写同行人姓名");
  assert.deepEqual(splitLines({ amount: 100, splitMode: "selected", splitParticipants: ["甲", "丙"] }, ["甲", "乙", "丙"]), [{ name: "甲", amount: 50 }, { name: "丙", amount: 50 }]);
  assert.equal(splitIssue({ amount: 100, splitMode: "custom", splitAmounts: { 甲: 40 } }, ["甲", "乙"]), "分账金额合计应为100.00元");
});

test("箭头和常见项目能落入吉隆坡五类", () => {
  assert.equal(classifyItem("贵阳→凯里包车").category, "交通");
  assert.equal(classifyItem("贵阳酒店").category, "玩住");
  assert.equal(classifyItem("丝恋丝娃娃晚饭").category, "吃喝");
  assert.equal(classifyItem("文创冰箱贴").category, "购物");
  assert.equal(classifyItem("旅行药品").category, "用品");
});

test("中文 OCR 字间空格不会影响交通识别", () => {
  assert.equal(classifyItem("金 华 地 铁").category, "交通");
});

test("热门奶茶、咖啡和餐饮品牌会识别为吃喝", () => {
  ["喜茶", "茶百道", "古茗", "霸王茶姬", "奈雪的茶", "库迪咖啡", "塔斯汀", "袁记云饺"].forEach((item) => {
    assert.equal(classifyItem(item).category, "吃喝", item);
  });
  assert.equal(classifyItem("酒店早餐").category, "吃喝");
  assert.equal(classifyItem("景区买杯奶茶").category, "吃喝");
  assert.equal(classifyItem("丝恋丝娃娃").category, "吃喝");
  assert.match(classifyItem("丝恋丝娃娃").reason, /餐饮品牌/);
});

test("服饰和演出项目必须根据明确证据分类", () => {
  assert.equal(classifyItem("袜子").category, "购物");
  assert.match(classifyItem("袜子").reason, /服饰|商品/);
  assert.equal(classifyItem("演唱会").category, "玩住");
  assert.match(classifyItem("演唱会").reason, /演出|活动/);
});

test("五类常见项目都返回对应的分类依据", () => {
  const cases = [
    ["酒店", "玩住", /住宿/],
    ["高铁票", "交通", /车票|机票/],
    ["早餐", "吃喝", /用餐/],
    ["袜子", "购物", /服饰|商品/],
    ["充电宝", "用品", /用品/],
    ["水杯", "用品", /用品/],
  ];
  for (const [item, category, reason] of cases) {
    const result = classifyItem(item);
    assert.equal(result.category, category, item);
    assert.match(result.reason, reason, item);
  }
});

test("网页中的交通指南不能覆盖演唱会本身的活动证据", async () => {
  let searched = false;
  const result = await classifyItemWithWeb("演唱会", {}, async () => {
    searched = true;
    return "演唱会活动介绍，附近有交通指南和到场路线";
  });
  assert.equal(result.category, "玩住");
  assert.equal(searched, false);
});

test("未知商户可结合网页检索内容判断类别", async () => {
  const result = await classifyItemWithWeb("赤水云雾坊", {}, async () => "赤水云雾坊是贵州特色美食商户，主营现制茶饮");
  assert.equal(result.category, "吃喝");
  assert.equal(result.webLookup, true);
  assert.match(result.reason, /网页检索/);
});

test("网页结果中的无关类别词不会覆盖项目本身的餐饮证据", async () => {
  const result = await classifyItemWithWeb("赤水云雾坊", {}, async () => "赤水云雾坊是贵州特色美食，附近也有酒店住宿攻略");
  assert.equal(result.category, "吃喝");
  assert.equal(result.webLookup, true);
});

test("网页餐饮和交通证据接近时不擅自选择交通", async () => {
  const result = await classifyItemWithWeb("陌生品牌甲", {}, async () => "陌生品牌甲是餐厅乘坐地铁即可到达");
  assert.equal(result.category, "购物");
  assert.match(result.reason, /没有得到明确类别/);
});

test("网页检索没有明确证据时保留本地结果并提示确认", async () => {
  const result = await classifyItemWithWeb("陌生商户甲", {}, async () => "陌生商户甲相关网页信息有限");
  assert.equal(result.category, "购物");
  assert.equal(result.webLookup, true);
  assert.match(result.reason, /没有得到明确类别/);
});

test("交易列表逐笔提取支出并跳过退款和转账", () => {
  const raw = [
    "2026 年 7 月 支出 Y32636.15 收入 39772.90",
    "扫 二 维 码 付 款 - 给 鹿 林 村 岸 -100.00",
    "Iuckin coffee -13.90",
    "织物记服饰 - 退 款 +89.90",
    "转账 - 转 给 同行人 -258.00",
  ].join("\n");
  const result = parseExpenseText(raw);
  assert.equal(result.entries.length, 2);
  assert.deepEqual(result.entries.map((entry) => entry.amount), [100, 13.9]);
  assert.equal(result.entries[1].category, "吃喝");
});

test("账单截图按项目、金额、日期成组识别并统一日期", () => {
  const raw = [
    "7月",
    "贵阳对的佳啡咖啡有限公司 -95.00",
    "餐饮美食",
    "07-28 15:13",
    "观山湖区茉莉家餐饮厅 -350.00",
    "餐饮美食 饭",
    "07-28 14:46",
    "贵州视界商业管理有限公司 -69.00",
    "餐饮美食",
    "07-28 13:41",
    "贵州视界商业管理有限公司 -88.00",
    "餐饮美食",
    "无法辨认的时间",
    "高德打车订单 -18.25",
    "交通出行 自动扣款成功",
    "07-28 11:55 公园去阿云朵仓",
  ].join("\n");
  const result = parseExpenseText(raw, {}, { referenceYear: 2026 });
  assert.deepEqual(result.entries.map((entry) => entry.amount), [95, 350, 69, 88, 18.25]);
  assert.deepEqual(result.entries.map((entry) => entry.date), Array(5).fill("2026-07-28"));
  assert.deepEqual(result.entries.map((entry) => entry.category), ["吃喝", "吃喝", "吃喝", "吃喝", "交通"]);
});

test("金额被遮挡时保留项目和日期并明确待补充", () => {
  const result = parseExpenseText([
    "高德打车订单 反馈与投诉",
    "交通出行 自动扣款成功",
    "07-31 12:35",
    "霸王茶姬（凯里国贸店）外卖订单 -56.00",
    "餐饮美食 已完成",
    "07-30 16:01",
  ].join("\n"), {}, { referenceYear: 2026 });
  assert.equal(result.entries.length, 2);
  assert.equal(result.entries[0].item, "高德打车订单");
  assert.equal(result.entries[0].amount, null);
  assert.equal(result.entries[0].date, "2026-07-31");
  assert.deepEqual(result.entries[0].reviewFields, ["amount"]);
  assert.equal(result.entries[1].item, "霸王茶姬（凯里国贸店）外卖订单");
  assert.equal(result.entries[1].amount, 56);
});

test("项目与右侧金额分行时仍能配成同一笔", () => {
  const result = parseExpenseText([
    "扫收钱码付款-给祥汇超市",
    "-30.00",
    "日用百货",
    "07-29 09:41",
  ].join("\n"), {}, { referenceYear: 2026 });
  assert.equal(result.entries.length, 1);
  assert.equal(result.entries[0].item, "祥汇超市");
  assert.equal(result.entries[0].amount, 30);
  assert.equal(result.entries[0].date, "2026-07-29");
});

test("小数金额不会误判成日期，项目中的时间不会被截断", () => {
  const result = parseExpenseText([
    "金华地铁（金华2026-08-01 20:50:27--... -1.99",
    "交通出行",
    "08-01 21:06",
    "高德打车订单 -10.24",
    "交通出行 自动扣款成功",
    "07-31 11:00",
    "公交支撑平台-BRT5-上车08:16 -1.97",
    "交通出行",
    "07-27 08:16",
  ].join("\n"), {}, { referenceYear: 2026 });
  assert.deepEqual(result.entries.map((entry) => entry.amount), [1.99, 10.24, 1.97]);
  assert.deepEqual(result.entries.map((entry) => entry.date), ["2026-08-01", "2026-07-31", "2026-07-27"]);
  assert.deepEqual(result.entries.map((entry) => entry.item), ["金华地铁", "高德打车订单", "公交支撑平台-BRT5-上车08:16"]);
});

test("支付详情页不会把年份识别成金额", () => {
  const result = parseExpenseText([
    "账单",
    "贵州农信",
    "锦绣黔缘",
    "-60.00",
    "当前状态 支付成功",
    "支付时间 2026年7月30日 14:22:23",
    "商品 锦绣黔缘",
  ].join("\n"), {}, { referenceYear: 2026 });
  assert.equal(result.entries.length, 1);
  assert.equal(result.entries[0].item, "锦绣黔缘");
  assert.equal(result.entries[0].amount, 60);
  assert.equal(result.entries[0].date, "2026-07-30");
});

test("支付详情页会结合图片备注判断类别", () => {
  const shopping = parseExpenseText("23:47 → 62\n账单\n锦绣黔缘\n-60.00\n当前状态 支付成功\n支付时间 2026年7月30日\n商品 锦绣黔缘\n交易单号 苗寨旗袍书签", {}, { referenceYear: 2026 });
  const drink = parseExpenseText("23:47 → 62\n账单\n池榭\n-55.00\n当前状态 支付成功\n支付时间 2026年7月30日\n商品 池榭\n收单机构 苗寨咖啡处", {}, { referenceYear: 2026 });
  assert.equal(shopping.entries[0].category, "购物");
  assert.equal(drink.entries[0].category, "吃喝");
  assert.equal(shopping.entries[0].classificationSource, "image-context");
});

test("商场管理方和护手霜采用更具体的类别", () => {
  assert.equal(classifyItem("贵州视界商业管理有限公司").category, "购物");
  assert.equal(classifyItem("贵州视界商业管理有限公司护手霜").category, "用品");
});

test("昨天按图片日期换算，已全额退款的支出不计入", () => {
  const relative = parseExpenseText([
    "搜索交易记录",
    "8月 支出￥151.98",
    "高德打车订单 -39.78",
    "交通出行",
    "昨天 13:07",
  ].join("\n"), {}, { referenceYear: 2026, referenceDate: "2026-08-02" });
  assert.equal(relative.entries[0].date, "2026-08-01");

  const refunded = parseExpenseText([
    "账单",
    "2026年7月 支出￥100",
    "拼多多 -24.81",
    "7月31日 11:14 已全额退款",
    "蜜雪冰城 -10.00",
    "7月31日 10:00",
  ].join("\n"), {}, { referenceYear: 2026 });
  assert.deepEqual(refunded.entries.map((entry) => entry.item), ["蜜雪冰城"]);
});

test("行程和酒店文字截图能拆成费用", () => {
  const result = parseExpenseText([
    "金华-贵阳 729",
    "贵阳-铜仁 149",
    "铜仁-凯里 95",
    "凯里-金华 673",
    "酒店 贵阳 每晚500.22 共两晚 共1000.44",
    "凯里 前两晚共422 最后一晚378",
  ].join("\n"), {}, { referenceYear: 2026 });
  assert.deepEqual(result.entries.map((entry) => entry.amount), [729, 149, 95, 673, 1000.44, 422, 378]);
  assert.deepEqual(result.entries.slice(0, 4).map((entry) => entry.category), Array(4).fill("交通"));
  assert.deepEqual(result.entries.slice(4).map((entry) => entry.category), Array(3).fill("玩住"));
});

test("明确的餐饮品牌不会被网页结果改错", async () => {
  let searched = false;
  const result = await classifyItemWithWeb("蜜雪冰城", {}, async () => {
    searched = true;
    return "购物中心 商场";
  });
  assert.equal(result.category, "吃喝");
  assert.equal(searched, false);
});

test("重叠截图按项目、金额、日期和时间合并", () => {
  const payload = deduplicateOcrResults([
    { kind: "expense", entries: [
      { date: "2026-07-28", transactionTime: "15:13", item: "贵阳咖啡", amount: 95, category: "吃喝", reviewFields: [] },
      { date: "2026-07-29", transactionTime: "18:15", item: "抖音电商商家", amount: 5.23, category: "购物", reviewFields: [] },
    ] },
    { kind: "expense", entries: [
      { date: "2026-07-28", transactionTime: "15:13", item: "贵阳咖啡", amount: 95, category: "吃喝", reviewFields: [] },
      { date: "2026-07-29", transactionTime: "18:16", item: "抖音电商商家", amount: 5.23, category: "购物", reviewFields: [] },
    ] },
  ]);
  assert.equal(payload.duplicates, 1);
  assert.equal(payload.results[0].entries.length + payload.results[1].entries.length, 3);
});

test("下一笔退款不会误删上一笔正常消费", () => {
  const text = `luckin coffee -13.90
7月30日 10:07
织物记服饰-退款 +89.90
7月30日 02:37`;
  const parsed = parseExpenseText(text, {}, { referenceYear: 2026 });
  assert.equal(parsed.entries.length, 1);
  assert.equal(parsed.entries[0].item, "luckin coffee");
  assert.equal(parsed.entries[0].amount, 13.9);
  assert.equal(parsed.entries[0].category, "吃喝");
});

test("铁路和常见餐饮识别误差能正确分类", () => {
  assert.equal(classifyItem("中铁网络 贵阳→凯里").category, "交通");
  assert.equal(classifyItem("南明区大象不大督饮店").category, "吃喝");
  assert.equal(classifyItem("美团美团").category, "吃喝");
});

test("油耗截图文字能识别里程、油耗和油号", () => {
  const result = parseFuelText([
    "2026年7月28日",
    "贵阳→凯里",
    "本次里程 183.6 km",
    "平均油耗 7.4 L/100km",
    "95号汽油",
  ].join("\n"));
  assert.equal(result.kind, "fuel");
  assert.equal(result.fuelRows[0].distance, 183.6);
  assert.equal(result.fuelRows[0].consumption, 7.4);
  assert.equal(result.fuelRows[0].grade, "95#");
  assert.equal(result.fuelRows[0].province, "贵州");
  const withoutGrade = parseFuelText("里程 120 km\n平均油耗 7.2 L/100km");
  assert.equal(withoutGrade.fuelRows[0].grade, "95#");
});

test("日期、贵州地点、国旗和文件名从账单内容自动生成", () => {
  const trip = inferTrip([
    { date: "2026-07-27", item: "金华→贵阳火车票", category: "交通" },
    { date: "2026-07-28", item: "贵阳酒店", category: "玩住" },
    { date: "2026-07-29", item: "凯里午饭", category: "吃喝" },
    { date: "2026-08-01", item: "铜仁→贵阳", category: "交通" },
  ]);
  assert.equal(trip.startDate, "2026-07-27");
  assert.equal(trip.endDate, "2026-08-01");
  assert.equal(trip.destination, "🇨🇳贵阳、凯里、铜仁");
  assert.equal(buildTripFilename(trip), "2026.7.27-8.1🇨🇳贵阳、凯里、铜仁.xlsx");
});

test("香港和澳门归入中国，但保留地区名称", () => {
  const trip = inferTrip([
    { date: "2026-08-10", item: "香港→澳门高铁", category: "交通" },
    { date: "2026-08-11", item: "澳门大三巴", category: "玩住" },
  ]);
  assert.equal(trip.flags, "🇨🇳");
  assert.equal(trip.locations, "香港、澳门");
  assert.equal(trip.destination, "🇨🇳香港、澳门");
  assert.equal(trip.province, "香港");
});
