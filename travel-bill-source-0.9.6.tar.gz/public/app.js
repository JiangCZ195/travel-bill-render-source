import { splitIssue, splitModeLabel, splitSuggestion } from "/split-details.mjs";

const CATEGORIES = ["玩住", "交通", "吃喝", "购物", "用品"];
const COLORS = { 玩住: "#f2ba02", 交通: "#4874cb", 吃喝: "#e54c5e", 购物: "#30c0b4", 用品: "#75bd42" };
const LIGHT = { 玩住: "#fcf1cc", 交通: "#dae3f5", 吃喝: "#fadbdf", 购物: "#d6f2f0", 用品: "#e3f2d9" };
const PROVINCES = ["北京", "天津", "河北", "山西", "内蒙古", "辽宁", "吉林", "黑龙江", "上海", "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "广西", "海南", "重庆", "四川", "贵州", "云南", "西藏", "陕西", "甘肃", "青海", "宁夏", "新疆"];
const FUEL_GRADES = ["92#", "95#", "98#"];

function parseStored(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key) || "null") ?? fallback; } catch { return fallback; }
}

function localIso(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

const savedDraft = parseStored("travelBillDraftV2", {});
const storedActiveTab = localStorage.getItem("travelBillActiveTabV1") || "personal";
const state = {
  entries: Array.isArray(savedDraft.entries) ? savedDraft.entries : [],
  fuelRows: Array.isArray(savedDraft.fuelRows) ? savedDraft.fuelRows : [],
  participants: Array.isArray(savedDraft.participants) ? savedDraft.participants.filter(Boolean) : [],
  selectedDate: savedDraft.selectedDate || localIso(),
  inferredTrip: {},
  learned: parseStored("travelBillLearned", {}),
  session: localStorage.getItem("travelBillSessionV1") || "",
  user: null,
  groups: [],
  activeGroup: null,
  personalTrips: [],
  activePersonalTripId: localStorage.getItem("travelBillActivePersonalTripV1") || "",
  friendsMode: localStorage.getItem("travelBillFriendsModeV1") || "trips",
  friendList: [],
  activeChatGroupId: "",
  activeChatMode: "group",
  activeChatFriendId: "",
  activeChatFriendName: "",
  chatReturnView: "list",
  chatMessages: [],
  chatSearch: "",
  chatRecorder: null,
  chatAudioChunks: [],
  unreadByGroup: {},
  unreadByFriend: {},
  unreadTotal: 0,
  notificationGroupId: "",
  notificationFriendId: "",
  viewMode: "list",
  footprints: { countries: [], cities: [], places: [] },
  activeTab: storedActiveTab === "album" ? "footprints" : storedActiveTab,
};

const $ = (selector) => document.querySelector(selector);
const dom = {
  manualEntryForm: $("#manualEntryForm"), manualDate: $("#manualDate"), manualDatePicker: $("#manualDatePicker"),
  manualItem: $("#manualItem"), manualCategory: $("#manualCategory"), manualAmount: $("#manualAmount"),
  ledgerScope: $("#ledgerScope"), manualVisibility: $("#manualVisibility"),
  classificationHint: $("#classificationHint"), autoTripTitle: $("#autoTripTitle"), filenamePreview: $("#filenamePreview"), tripSummary: $("#tripSummary"), backToHistoryBtn: $("#backToHistoryBtn"),
  participantInput: $("#participantInput"), addParticipantBtn: $("#addParticipantBtn"), participantChips: $("#participantChips"), participantCount: $("#participantCount"), splitSetupHint: $("#splitSetupHint"),
  imageInput: $("#imageInput"), cameraInput: $("#cameraInput"), imageDropzone: $("#imageDropzone"), ocrProgress: $("#ocrProgress"),
  expenseEmpty: $("#expenseEmpty"), expenseTableWrap: $("#expenseTableWrap"), expenseSplitHead: $("#expenseSplitHead"), expenseRows: $("#expenseRows"),
  entryCount: $("#entryCount"), grandTotal: $("#grandTotal"), mobileTotal: $("#mobileTotal"), totalDetail: $("#totalDetail"), personalTotal: $("#personalTotal"),
  barChart: $("#barChart"), donutChart: $("#donutChart"), chartLegend: $("#chartLegend"),
  exportBtn: $("#exportBtn"), mobileExportBtn: $("#mobileExportBtn"), toast: $("#toast"),
  chooseExportFolderBtn: $("#chooseExportFolderBtn"), exportFolderStatus: $("#exportFolderStatus"),
  syncStatus: $("#syncStatus"), accountButton: $("#accountButton"), accountDialog: $("#accountDialog"), accountForm: $("#accountForm"),
  accountDialogTitle: $("#accountDialogTitle"), accountDialogHint: $("#accountDialogHint"), accountDialogNote: $("#accountDialogNote"),
  signedInPanel: $("#signedInPanel"), signedOutPanel: $("#signedOutPanel"), accountName: $("#accountName"), accountEmail: $("#accountEmail"),
  otpIdentifier: $("#otpIdentifier"), otpDisplayName: $("#otpDisplayName"), otpCode: $("#otpCode"), otpCodePanel: $("#otpCodePanel"), otpRequestButton: $("#otpRequestButton"), otpVerifyButton: $("#otpVerifyButton"), otpHint: $("#otpHint"),
  appleLoginButton: $("#appleLoginButton"), devDisplayName: $("#devDisplayName"), devLoginButton: $("#devLoginButton"), logoutButton: $("#logoutButton"),
  pairMacButton: $("#pairMacButton"), pairingPanel: $("#pairingPanel"), pairingCode: $("#pairingCode"), pairingHint: $("#pairingHint"),
  groupCount: $("#groupCount"), groupNameInput: $("#groupNameInput"), inviteCodeInput: $("#inviteCodeInput"), createGroupBtn: $("#createGroupBtn"), joinGroupBtn: $("#joinGroupBtn"), groupDetailName: $("#groupDetailName"), groupDetailMeta: $("#groupDetailMeta"), groupChatBtn: $("#groupChatBtn"), groupInviteBtn: $("#groupInviteBtn"),
  groupList: $("#groupList"), selectedGroupPanel: $("#selectedGroupPanel"), selectedGroupName: $("#selectedGroupName"), selectedGroupMembers: $("#selectedGroupMembers"),
  refreshGroupBtn: $("#refreshGroupBtn"), createInviteBtn: $("#createInviteBtn"), inviteCodeResult: $("#inviteCodeResult"), groupsHint: $("#groupsHint"),
  personalTripList: $("#personalTripList"), personalTripSearch: $("#personalTripSearch"), createPersonalTripBtn: $("#createPersonalTripBtn"),
  friendsTripList: $("#friendsTripList"), friendList: $("#friendList"), friendsSearch: $("#friendsSearch"), friendsPlusBtn: $("#friendsPlusBtn"),
  createTripDialog: $("#createTripDialog"), createTripForm: $("#createTripForm"), createTripCloseBtn: $("#createTripDialog .dialog-close"), createTripTitle: $("#createTripTitle"), createTripHint: $("#createTripHint"), createTripName: $("#createTripName"), confirmCreateTripBtn: $("#confirmCreateTripBtn"), createGroupFromMenuBtn: $("#createGroupFromMenuBtn"), openInviteFromMenuBtn: $("#openInviteFromMenuBtn"), addFriendFromMenuBtn: $("#addFriendFromMenuBtn"), menuInviteCode: $("#menuInviteCode"), joinFromMenuBtn: $("#joinFromMenuBtn"), friendInviteBox: $("#friendInviteBox"), friendInviteHint: $("#friendInviteHint"),
  chatCard: $("#chatCard"), chatEyebrow: $("#chatEyebrow"), chatTitle: $("#chatTitle"), chatMessages: $("#chatMessages"), chatMessageInput: $("#chatMessageInput"), chatMediaInput: $("#chatMediaInput"), chatMediaBtn: $("#chatMediaBtn"), chatRecordBtn: $("#chatRecordBtn"), sendChatBtn: $("#sendChatBtn"), closeChatBtn: $("#closeChatBtn"), chatSearchBtn: $("#chatSearchBtn"), chatSearchBox: $("#chatSearchBox"), chatSearchInput: $("#chatSearchInput"),
  friendsUnreadBadge: $("#friendsUnreadBadge"), messageNotification: $("#messageNotification"), messageNotificationBtn: $("#messageNotificationBtn"), messageNotificationClose: $("#messageNotificationClose"), messageNotificationTitle: $("#messageNotificationTitle"), messageNotificationBody: $("#messageNotificationBody"),
  footprintCount: $("#footprintCount"), footprintSummary: $("#footprintSummary"), footprintPlaces: $("#footprintPlaces"), footprintMarkers: $("#footprintMarkers"), footprintMapEmpty: $("#footprintMapEmpty"),
  profileCard: $("#profileCard"), profileState: $("#profileState"), profileAvatar: $("#profileAvatar"), avatarInput: $("#avatarInput"), profileName: $("#profileName"), profileEmail: $("#profileEmail"), profileLoginBtn: $("#profileLoginBtn"), profileAccountBtn: $("#profileAccountBtn"), profileFootprintCount: $("#profileFootprintCount"),
};

let exportDirectoryHandle = null;
let pairingPollTimer = null;
let otpChallengeId = "";
let otpCooldownTimer = null;
let otpCooldownUntil = 0;
let otpRequestInFlight = false;
let messagePollTimer = null;
let messagePollInFlight = false;
let messagePollBootstrapped = false;

async function accountRequest(url, options = {}) {
  const headers = new Headers(options.headers || {});
  headers.set("Content-Type", "application/json");
  if (state.session) headers.set("Authorization", `Bearer ${state.session}`);
  const response = await fetch(url, { ...options, headers });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error || "账号服务暂时不可用");
    error.status = response.status;
    throw error;
  }
  return payload;
}

async function mediaUploadRequest(url, formData) {
  const headers = new Headers();
  if (state.session) headers.set("Authorization", `Bearer ${state.session}`);
  const response = await fetch(url, { method: "POST", headers, body: formData });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || "相册上传失败");
  return payload;
}

function messageReadKey(groupId) { return `travelBillChatReadV1:${groupId}`; }
function directReadKey(friendId) { return `travelBillDirectReadV1:${friendId}`; }

function messageStamp(message) {
  return { createdAt: String(message?.createdAt || ""), id: String(message?.id || "") };
}

function isMessageAfter(message, marker) {
  if (!marker) return true;
  const current = messageStamp(message);
  return current.createdAt > marker.createdAt || (current.createdAt === marker.createdAt && current.id > marker.id);
}

function latestMessage(messages) {
  return [...messages].sort((left, right) => {
    const a = messageStamp(left); const b = messageStamp(right);
    return a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id);
  }).at(-1) || null;
}

const localChatDBName = "travelBillLocalChatV1";
let localChatDBPromise = null;

function chatScope(mode, id) { return `${mode}:${id}`; }

function openLocalChatDB() {
  if (!window.indexedDB) return Promise.resolve(null);
  if (localChatDBPromise) return localChatDBPromise;
  localChatDBPromise = new Promise((resolve) => {
    const request = indexedDB.open(localChatDBName, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains("messages")) database.createObjectStore("messages", { keyPath: "key" });
      if (!database.objectStoreNames.contains("media")) database.createObjectStore("media", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => resolve(null);
  });
  return localChatDBPromise;
}

async function localChatMessages(scope) {
  const database = await openLocalChatDB();
  if (!database) return [];
  return new Promise((resolve) => {
    const request = database.transaction("messages", "readonly").objectStore("messages").getAll();
    request.onsuccess = () => resolve(request.result.filter((record) => record.scope === scope).map((record) => record.message).sort((a, b) => {
      const left = messageStamp(a); const right = messageStamp(b);
      return left.createdAt.localeCompare(right.createdAt) || left.id.localeCompare(right.id);
    }));
    request.onerror = () => resolve([]);
  });
}

async function mergeLocalChat(scope, messages) {
  const database = await openLocalChatDB();
  if (!database) return messages;
  const existing = await localChatMessages(scope);
  const byID = new Map(existing.map((message) => [message.id, message]));
  messages.forEach((message) => byID.set(message.id, message));
  const merged = [...byID.values()].sort((a, b) => {
    const left = messageStamp(a); const right = messageStamp(b);
    return left.createdAt.localeCompare(right.createdAt) || left.id.localeCompare(right.id);
  });
  await new Promise((resolve) => {
    const transaction = database.transaction("messages", "readwrite");
    const store = transaction.objectStore("messages");
    merged.forEach((message) => store.put({ key: `${scope}:${message.id}`, scope, message }));
    transaction.oncomplete = resolve;
    transaction.onerror = resolve;
  });
  return merged;
}

async function localChatMedia(mediaID) {
  const database = await openLocalChatDB();
  if (!database || !mediaID) return null;
  return new Promise((resolve) => {
    const request = database.transaction("media", "readonly").objectStore("media").get(mediaID);
    request.onsuccess = () => resolve(request.result?.blob || null);
    request.onerror = () => resolve(null);
  });
}

async function saveLocalChatMedia(mediaID, blob) {
  const database = await openLocalChatDB();
  if (!database || !mediaID || !blob) return;
  await new Promise((resolve) => {
    const transaction = database.transaction("media", "readwrite");
    transaction.objectStore("media").put({ id: mediaID, blob, savedAt: Date.now() });
    transaction.oncomplete = resolve;
    transaction.onerror = resolve;
  });
}

function localChatFilter(messages, query) {
  const clean = String(query || "").trim().toLowerCase();
  return clean ? messages.filter((message) => String(message.body || "").toLowerCase().includes(clean)) : messages;
}

async function cacheAndAcknowledgeWeb(messages, mode, id) {
  for (const message of messages) {
    let ready = !message.mediaId;
    if (message.mediaId) {
      let blob = await localChatMedia(message.mediaId);
      if (!blob && state.session) {
        try {
          const response = await fetch(`/api/media/${encodeURIComponent(message.mediaId)}/file`, { headers: { Authorization: `Bearer ${state.session}` } });
          if (response.ok) {
            blob = await response.blob();
            await saveLocalChatMedia(message.mediaId, blob);
          }
        } catch {}
      }
      ready = Boolean(blob);
    }
    if (!ready) continue;
    const endpoint = mode === "direct"
      ? `/api/friends/${encodeURIComponent(id)}/messages/${encodeURIComponent(message.id)}/ack`
      : `/api/bills/${encodeURIComponent(id)}/messages/${encodeURIComponent(message.id)}/ack`;
    try { await accountRequest(endpoint, { method: "POST", body: "{}" }); } catch {}
  }
}

function unreadBadgeMarkup(groupId) {
  const count = Number(state.unreadByGroup[groupId] || 0);
  return `<span class="nav-badge ${count ? "" : "hidden"}" data-unread-key="group:${escapeHtml(groupId)}">${count > 99 ? "99+" : count}</span>`;
}

function friendUnreadBadgeMarkup(friendId) {
  const count = Number(state.unreadByFriend[friendId] || 0);
  return `<span class="nav-badge ${count ? "" : "hidden"}" data-unread-key="friend:${escapeHtml(friendId)}">${count > 99 ? "99+" : count}</span>`;
}

function renderUnreadBadges() {
  const total = Number(state.unreadTotal || 0);
  if (dom.friendsUnreadBadge) {
    dom.friendsUnreadBadge.textContent = total > 99 ? "99+" : String(total);
    dom.friendsUnreadBadge.classList.toggle("hidden", total <= 0);
  }
  document.querySelectorAll("[data-unread-key]").forEach((element) => {
    const [kind, id] = String(element.dataset.unreadKey || "").split(":");
    const count = kind === "friend" ? Number(state.unreadByFriend[id] || 0) : Number(state.unreadByGroup[id] || 0);
    element.textContent = count > 99 ? "99+" : String(count);
    element.classList.toggle("hidden", count <= 0);
  });
}

function hideMessageNotification() {
  dom.messageNotification?.classList.add("hidden");
  state.notificationGroupId = "";
  state.notificationFriendId = "";
}

function showMessageNotification(group, message) {
  if (!dom.messageNotification || !message || state.activeChatGroupId === group.id) return;
  state.notificationGroupId = group.id;
  state.notificationFriendId = "";
  dom.messageNotificationTitle.textContent = `${group.name || "好友账单"} · 新消息`;
  dom.messageNotificationBody.textContent = `${message.sender?.displayName || "旅伴"}：${message.body || (message.type === "video" ? "发来一段视频" : message.type === "audio" ? "发来一条语音" : "发来一张图片")}`;
  dom.messageNotification.classList.remove("hidden");
  clearTimeout(showMessageNotification.timer);
  showMessageNotification.timer = setTimeout(hideMessageNotification, 7000);
}

function showDirectNotification(friend, message) {
  if (!dom.messageNotification || !message || state.activeChatFriendId === friend.id) return;
  state.notificationFriendId = friend.id;
  state.notificationGroupId = "";
  dom.messageNotificationTitle.textContent = `${friend.displayName || "好友"} · 新消息`;
  dom.messageNotificationBody.textContent = `${message.sender?.displayName || friend.displayName || "好友"}：${message.body || (message.type === "video" ? "发来一段视频" : message.type === "audio" ? "发来一条语音" : "发来一张图片")}`;
  dom.messageNotification.classList.remove("hidden");
  clearTimeout(showDirectNotification.timer);
  showDirectNotification.timer = setTimeout(hideMessageNotification, 7000);
}

function markChatRead(groupId, messages = state.chatMessages) {
  const latest = latestMessage(messages);
  if (!latest) return;
  localStorage.setItem(messageReadKey(groupId), JSON.stringify(messageStamp(latest)));
  delete state.unreadByGroup[groupId];
  state.unreadTotal = Object.values(state.unreadByGroup).reduce((total, count) => total + Number(count || 0), 0);
  state.unreadTotal += Object.values(state.unreadByFriend).reduce((total, count) => total + Number(count || 0), 0);
  renderUnreadBadges();
}

function markDirectChatRead(friendId, messages = state.chatMessages) {
  const latest = latestMessage(messages);
  if (!latest) return;
  localStorage.setItem(directReadKey(friendId), JSON.stringify(messageStamp(latest)));
  delete state.unreadByFriend[friendId];
  state.unreadTotal = Object.values(state.unreadByGroup).reduce((total, count) => total + Number(count || 0), 0) + Object.values(state.unreadByFriend).reduce((total, count) => total + Number(count || 0), 0);
  renderUnreadBadges();
}

async function pollMessages(initial = false) {
  if (!state.user || !state.groups.length || messagePollInFlight) return;
  messagePollInFlight = true;
  try {
    for (const group of state.groups.slice(0, 30)) {
      let messages = [];
      try {
        const result = await accountRequest(`/api/bills/${encodeURIComponent(group.id)}/messages`, { method: "GET", headers: {} });
        messages = result.messages || [];
      } catch { continue; }
      const mergedMessages = await mergeLocalChat(chatScope("group", group.id), messages);
      await cacheAndAcknowledgeWeb(messages, "group", group.id);
      const latest = latestMessage(messages);
      const marker = parseStored(messageReadKey(group.id), null);
      if (!marker) {
        if (latest) localStorage.setItem(messageReadKey(group.id), JSON.stringify(messageStamp(latest)));
        delete state.unreadByGroup[group.id];
        continue;
      }
      const freshIncoming = messages.filter((message) => isMessageAfter(message, marker) && message.senderId !== state.user.id);
      const isOpen = state.activeTab === "friends" && state.activeChatGroupId === group.id && state.viewMode === "detail";
      if (isOpen) {
        if (!state.chatSearch) {
          state.chatMessages = mergedMessages;
          renderChat();
        }
        markChatRead(group.id, state.chatSearch ? localChatFilter(mergedMessages, state.chatSearch) : mergedMessages);
      } else {
        const previousCount = Number(state.unreadByGroup[group.id] || 0);
        if (freshIncoming.length) {
          state.unreadByGroup[group.id] = freshIncoming.length;
          if (!initial && freshIncoming.length > previousCount) showMessageNotification(group, freshIncoming.at(-1));
        }
      }
    }
    for (const friend of state.friendList.slice(0, 30)) {
      let messages = [];
      try {
        const result = await accountRequest(`/api/friends/${encodeURIComponent(friend.id)}/messages`, { method: "GET", headers: {} });
        messages = result.messages || [];
      } catch { continue; }
      const mergedMessages = await mergeLocalChat(chatScope("direct", friend.id), messages);
      await cacheAndAcknowledgeWeb(messages, "direct", friend.id);
      const latest = latestMessage(messages);
      const marker = parseStored(directReadKey(friend.id), null);
      if (!marker) {
        if (latest) localStorage.setItem(directReadKey(friend.id), JSON.stringify(messageStamp(latest)));
        delete state.unreadByFriend[friend.id];
        continue;
      }
      const freshIncoming = messages.filter((message) => isMessageAfter(message, marker) && message.senderId !== state.user.id);
      const isOpen = state.activeTab === "friends" && state.activeChatMode === "direct" && state.activeChatFriendId === friend.id && state.viewMode === "detail";
      if (isOpen) {
        if (!state.chatSearch) {
          state.chatMessages = mergedMessages;
          renderChat();
        }
        markDirectChatRead(friend.id, state.chatSearch ? localChatFilter(mergedMessages, state.chatSearch) : mergedMessages);
      } else if (freshIncoming.length) {
        const previousCount = Number(state.unreadByFriend[friend.id] || 0);
        state.unreadByFriend[friend.id] = freshIncoming.length;
        if (!initial && freshIncoming.length > previousCount) showDirectNotification(friend, freshIncoming.at(-1));
      }
    }
    state.unreadTotal = Object.values(state.unreadByGroup).reduce((total, count) => total + Number(count || 0), 0) + Object.values(state.unreadByFriend).reduce((total, count) => total + Number(count || 0), 0);
    renderUnreadBadges();
  } finally {
    messagePollInFlight = false;
    messagePollBootstrapped = true;
  }
}

function startMessagePolling() {
  clearInterval(messagePollTimer);
  messagePollBootstrapped = false;
  if (!state.user) return;
  pollMessages(true);
  messagePollTimer = setInterval(() => {
    if (!document.hidden) pollMessages(false);
  }, 3000);
}

function stopMessagePolling() {
  clearInterval(messagePollTimer);
  messagePollTimer = null;
  messagePollInFlight = false;
  messagePollBootstrapped = false;
  state.unreadByGroup = {};
  state.unreadByFriend = {};
  state.unreadTotal = 0;
  renderUnreadBadges();
  hideMessageNotification();
}

function renderFootprints() {
  const places = state.footprints?.places || [];
  const cities = state.footprints?.cities || [];
  const countries = state.footprints?.countries || [];
  const markers = places.filter((place) => Number.isFinite(Number(place.latitude)) && Number.isFinite(Number(place.longitude)));
  dom.footprintCount.textContent = `${places.length} 个地点`;
  dom.footprintSummary.textContent = places.length
    ? `已记录 ${countries.length} 个国家/地区、${cities.length} 个城市或景点；香港、澳门会归入中国并保留地区名称。`
    : "发送带定位信息的照片或视频后，这里会显示国家、地区和城市。";
  dom.footprintPlaces.innerHTML = places.slice(0, 24).map((place) => {
    const label = [place.country, place.region, place.city || place.locationName].filter(Boolean).join(" · ") || (place.latitude != null ? `${Number(place.latitude).toFixed(4)}, ${Number(place.longitude).toFixed(4)}` : "已定位地点");
    return `<span class="footprint-place">${escapeHtml(label)} · ${place.mediaCount} 个媒体</span>`;
  }).join("");
  if (dom.footprintMarkers) {
    dom.footprintMarkers.innerHTML = markers.map((place) => {
      const longitude = Math.max(-180, Math.min(180, Number(place.longitude)));
      const latitude = Math.max(-90, Math.min(90, Number(place.latitude)));
      const x = ((longitude + 180) / 360) * 1000;
      const y = ((90 - latitude) / 180) * 480;
      const label = [place.country, place.region, place.city || place.locationName].filter(Boolean).join(" · ") || "已定位地点";
      return `<circle class="map-marker" cx="${x.toFixed(2)}" cy="${y.toFixed(2)}" r="7"><title>${escapeHtml(label)}</title></circle>`;
    }).join("");
  }
  if (dom.footprintMapEmpty) dom.footprintMapEmpty.classList.toggle("hidden", markers.length > 0);
  if (dom.profileFootprintCount) dom.profileFootprintCount.textContent = `${places.length} 个地点`;
}

function localPersonalTrips() {
  const saved = parseStored("travelBillPersonalTripsV1", []);
  const trips = Array.isArray(saved) ? saved : [];
  const legacyEntries = state.entries.filter((entry) => !entry.groupId && (!entry.personalTripId || entry.personalTripId === "local-current"));
  if (legacyEntries.length && !trips.some((trip) => trip.id === "local-current")) {
    trips.unshift({ id: "local-current", name: "本机旅行记录", tripMeta: {}, local: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
  }
  return trips.map((trip) => {
    const entries = state.entries.filter((entry) => !entry.groupId && (trip.id === "local-current" ? (!entry.personalTripId || entry.personalTripId === "local-current") : entry.personalTripId === trip.id));
    return { ...trip, expenseCount: entries.length, totalCents: Math.round(entries.reduce((sum, entry) => sum + Number(entry.amount || 0), 0) * 100) };
  });
}

function tripMetaLabel(trip) {
  const meta = trip.tripMeta || {};
  const locations = meta.locations || meta.destination || meta.title || "待录入日期与地点";
  const date = meta.startDate ? `${displayDate(meta.startDate)}${meta.endDate ? `—${displayDate(meta.endDate)}` : ""}` : "尚未录入费用";
  return `${date} · ${locations}`;
}

function renderPersonalTrips() {
  if (!dom.personalTripList) return;
  const all = [...state.personalTrips, ...localPersonalTrips().filter((local) => !state.personalTrips.some((trip) => trip.id === local.id))];
  const query = String(dom.personalTripSearch?.value || "").trim().toLowerCase();
  const trips = all.filter((trip) => {
    if (!query) return true;
    const haystack = [trip.name, tripMetaLabel(trip)].join(" ").toLowerCase();
    return haystack.includes(query);
  });
  dom.personalTripList.innerHTML = trips.length ? trips.map((trip) => `
    <button class="trip-list-row" type="button" data-open-personal-trip="${escapeHtml(trip.id)}">
      <span class="trip-cover personal-cover">⌁</span>
      <span class="trip-row-copy"><strong>${escapeHtml(trip.name)}</strong><small>${escapeHtml(tripMetaLabel(trip))}</small></span>
      <span class="trip-row-total"><b>${money(Number(trip.totalCents || 0) / 100)}</b><small>${trip.expenseCount || 0} 笔 · ${trip.mediaCount || 0} 张</small></span>
      <span class="trip-chevron">›</span>
    </button>`).join("") : `<div class="history-empty"><span>⌁</span><strong>${query ? "没有找到匹配的旅行" : "还没有个人旅行"}</strong><small>点击右上角“＋”新建一份个人账单</small></div>`;
}

function renderFriendsHome() {
  if (!dom.friendsTripList || !dom.friendList) return;
  document.querySelectorAll("[data-friends-mode]").forEach((button) => button.classList.toggle("active", button.dataset.friendsMode === state.friendsMode));
  const query = String(dom.friendsSearch?.value || "").trim().toLowerCase();
  const groups = state.groups.filter((group) => !query || String(group.name || "").toLowerCase().includes(query));
  dom.friendsTripList.innerHTML = groups.length ? groups.map((group) => `
    <button class="trip-list-row" type="button" data-open-group-trip="${escapeHtml(group.id)}">
      <span class="trip-cover group-cover">♧</span>
      <span class="trip-row-copy"><strong>${escapeHtml(group.name)}</strong><small>${escapeHtml(group.updatedAt ? `最近更新 ${displayDate(String(group.updatedAt).slice(0, 10))}` : "共同旅行账单")} · ${group.memberCount || 1} 位成员</small></span>
      <span class="trip-row-total"><b>共同账单</b><small>打开查看明细</small>${unreadBadgeMarkup(group.id)}</span>
      <span class="trip-chevron">›</span>
    </button>`).join("") : `<div class="history-empty"><span>♧</span><strong>${query ? "没有找到匹配的共同旅程" : "还没有共同旅程"}</strong><small>点击右上角“＋”新建账单或加入好友</small></div>`;
  const friends = state.friendList.filter((friend) => !query || `${friend.displayName || friend.name} ${friend.lastGroupName || ""}`.toLowerCase().includes(query));
  dom.friendList.innerHTML = friends.length ? friends.map((friend) => `
    <button class="friend-list-row" type="button" data-open-friend-id="${escapeHtml(friend.id)}" data-friend-name="${escapeHtml(friend.displayName || "旅伴")}">
      <span class="friend-avatar">${escapeHtml(String(friend.displayName || "旅").slice(0, 1))}</span>
      <span class="friend-row-copy"><strong>${escapeHtml(friend.displayName || "旅伴")}</strong><small>${escapeHtml(friend.lastGroupName || "共同旅行")} · ${friend.sharedGroupCount || 1} 个共同账单</small></span>
      <span class="friend-row-action">私聊 ›${friendUnreadBadgeMarkup(friend.id)}</span>
    </button>`).join("") : `<div class="history-empty"><span>♧</span><strong>${query ? "没有找到好友" : "还没有好友"}</strong><small>可以先创建共同账单，再邀请好友加入</small></div>`;
  dom.friendsTripList.classList.toggle("hidden", state.friendsMode !== "trips");
  dom.friendList.classList.toggle("hidden", state.friendsMode !== "friends");
  renderUnreadBadges();
}

function activeEntries() {
  if (state.activeTab === "friends" && state.activeGroup) return state.entries.filter((entry) => entry.groupId === state.activeGroup.id);
  if (state.activeTab === "personal") {
    const personal = state.entries.filter((entry) => !entry.groupId);
    if (!state.activePersonalTripId || state.activePersonalTripId === "local-current") return personal.filter((entry) => !entry.personalTripId || entry.personalTripId === "local-current");
    return personal.filter((entry) => entry.personalTripId === state.activePersonalTripId);
  }
  return [];
}

function renderAppTab() {
  const tab = state.activeTab;
  const chatOpen = Boolean((state.activeChatMode === "group" && state.activeChatGroupId) || (state.activeChatMode === "direct" && state.activeChatFriendId));
  document.querySelectorAll("[data-tabs]").forEach((element) => {
    const allowed = String(element.dataset.tabs || "").split(",");
    const viewAllowed = !element.dataset.view || element.dataset.view === state.viewMode;
    const chatAllowed = element.id !== "chatCard" ? !chatOpen : Boolean(chatOpen && state.viewMode === "detail");
    element.classList.toggle("hidden", !allowed.includes(tab) || !viewAllowed || !chatAllowed);
  });
  document.querySelectorAll("[data-app-tab]").forEach((button) => {
    const selected = button.dataset.appTab === tab;
    button.classList.toggle("active", selected);
    button.setAttribute("aria-current", selected ? "page" : "false");
  });
  dom.manualVisibility.value = tab === "friends" ? "group" : "private";
  const showGroupScope = tab === "friends" && state.viewMode === "detail" && Boolean(state.activeGroup);
  dom.ledgerScope.classList.toggle("hidden", !showGroupScope);
  if (!showGroupScope) dom.manualVisibility.value = "private";
  dom.autoTripTitle.textContent = tab === "friends" ? "好友账单 · 共同记录" : tab === "footprints" ? "我的足迹 · 旅行地图" : tab === "me" ? "账号、足迹与设置" : "个人账单 · 我的旅行";
  renderPersonalTrips();
  renderFriendsHome();
  renderExpenses();
  renderCharts();
  renderChat();
  renderUnreadBadges();
}

function setAppTab(tab) {
  if (!["personal", "friends", "footprints", "me"].includes(tab)) return;
  state.activeTab = tab;
  state.viewMode = ["personal", "friends"].includes(tab) ? "list" : "detail";
  state.activeChatGroupId = "";
  state.activeChatFriendId = "";
  state.activeChatMode = "group";
  state.chatReturnView = "list";
  hideMessageNotification();
  localStorage.setItem("travelBillActiveTabV1", tab);
  renderAppTab();
}

// macOS 原生外壳通过这个稳定入口切换网页内容，避免仅模拟点击时与本地记忆页签不同步。
window.travelBillSetTab = setAppTab;

async function loadMediaPreview(mediaID, element) {
  try {
    let blob = await localChatMedia(mediaID);
    if (!blob) {
      const response = await fetch(`/api/media/${encodeURIComponent(mediaID)}/file`, { headers: { Authorization: `Bearer ${state.session}` } });
      if (!response.ok) return;
      blob = await response.blob();
      await saveLocalChatMedia(mediaID, blob);
    }
    element.src = URL.createObjectURL(blob);
    element.classList.remove("media-loading");
  } catch {}
}

async function downloadChatMedia(mediaID, filename = "聊天媒体") {
  try {
    let blob = await localChatMedia(mediaID);
    if (!blob) {
      const response = await fetch(`/api/media/${encodeURIComponent(mediaID)}/file`, { headers: { Authorization: `Bearer ${state.session}` } });
      if (!response.ok) throw new Error("原文件暂时无法读取");
      blob = await response.blob();
      await saveLocalChatMedia(mediaID, blob);
    }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (error) { toast(error.message, "error"); }
}

async function loadAvatarPreview(mediaID) {
  if (!dom.profileAvatar) return;
  dom.profileAvatar.style.backgroundImage = "";
  dom.profileAvatar.textContent = state.user ? String(state.user.displayName || "旅").slice(0, 1) : "旅";
  if (!mediaID || !state.session) return;
  try {
    const response = await fetch(`/api/media/${encodeURIComponent(mediaID)}/file`, { headers: { Authorization: `Bearer ${state.session}` } });
    if (!response.ok) return;
    const blob = await response.blob();
    dom.profileAvatar.style.backgroundImage = `url(${URL.createObjectURL(blob)})`;
    dom.profileAvatar.textContent = "";
  } catch {}
}

async function refreshFootprints() {
  if (!state.user) {
    state.footprints = { countries: [], cities: [], places: [] };
    renderFootprints();
    return;
  }
  try {
    state.footprints = await accountRequest("/api/footprints", { method: "GET", headers: {} });
  } catch {}
  renderFootprints();
}

async function uploadAvatar(file) {
  if (!file || !state.user) return;
  if (!file.type.startsWith("image/")) return toast("头像只能使用图片", "error");
  try {
    const form = new FormData();
    form.append("file", file, file.name || "avatar.jpg");
    const result = await mediaUploadRequest("/api/account/avatar", form);
    state.user = result.user || state.user;
    renderAccount();
    toast("头像已更新");
  } catch (error) { toast(`头像更新失败：${error.message}`, "error"); }
}

function renderAccount() {
  const signedIn = Boolean(state.user && state.session);
  dom.accountButton.textContent = signedIn ? `${state.user.displayName} · 已同步` : "登录同步";
  dom.syncStatus.textContent = signedIn ? "已同步" : "本机草稿";
  dom.syncStatus.closest(".local-badge")?.classList.toggle("synced", signedIn);
  dom.signedInPanel.classList.toggle("hidden", !signedIn);
  dom.signedOutPanel.classList.toggle("hidden", signedIn);
  dom.accountDialogTitle.textContent = signedIn ? "账号与同步" : "登录旅迹账单";
  dom.accountDialogHint.textContent = signedIn ? "当前设备已连接云端账号；配对成功后 Mac 会独立保存登录状态。" : "手机和 Mac 可以独立使用；Mac 可通过一次性配对码授权。";
  dom.accountName.textContent = signedIn ? state.user.displayName : "";
  dom.accountEmail.textContent = signedIn ? (state.user.email || "邮箱 / 手机号账号") : "";
  if (dom.profileState) dom.profileState.textContent = signedIn ? "已同步" : "未登录";
  if (dom.profileName) dom.profileName.textContent = signedIn ? state.user.displayName : "还没有登录";
  if (dom.profileEmail) dom.profileEmail.textContent = signedIn ? (state.user.email || "邮箱 / 手机号账号已连接") : "登录后同步 Mac 与 iPhone";
  loadAvatarPreview(signedIn ? state.user.avatarMediaId : "");
  if (dom.profileLoginBtn) dom.profileLoginBtn.textContent = signedIn ? "账号设置" : "登录同步";
}

function renderGroups() {
  const showGroupScope = state.activeTab === "friends" && state.viewMode === "detail" && Boolean(state.activeGroup);
  dom.ledgerScope.classList.toggle("hidden", !showGroupScope);
  if (showGroupScope) dom.manualVisibility.value = dom.manualVisibility.value || "group";
  if (dom.groupDetailName) dom.groupDetailName.textContent = state.activeGroup?.name || "请选择一个账单";
  if (dom.groupDetailMeta) dom.groupDetailMeta.textContent = state.activeGroup ? `${state.activeGroup.members?.length || 1} 位成员 · 公共费用与私人小项目` : "公共费用、私人小项目与同行成员";
  if (dom.groupChatBtn) dom.groupChatBtn.disabled = !state.activeGroup;
  if (dom.groupInviteBtn) dom.groupInviteBtn.disabled = !state.activeGroup;
  if (!state.user) {
    dom.groupCount.textContent = "未登录";
    dom.groupList.innerHTML = "";
    dom.selectedGroupPanel.classList.add("hidden");
    dom.groupsHint.textContent = "登录后可以创建旅行账单组，邀请朋友共同记录公共费用。";
    return;
  }
  dom.groupCount.textContent = `${state.groups.length} 组`;
  dom.groupList.innerHTML = state.groups.length
    ? state.groups.map((group) => `<button type="button" class="group-chip ${state.activeGroup?.id === group.id ? "selected" : ""}" data-select-group="${escapeHtml(group.id)}"><strong>${escapeHtml(group.name)}</strong><span>${group.memberCount || 1} 人 · ${group.role === "owner" ? "组长" : "成员"}</span></button>`).join("")
    : `<span class="participant-hint">还没有账单组，可以先创建一个旅行账单组。</span>`;
  if (state.activeGroup) {
    dom.selectedGroupPanel.classList.remove("hidden");
    dom.selectedGroupName.textContent = state.activeGroup.name;
    dom.selectedGroupMembers.textContent = `${state.activeGroup.members.length} 位成员：${state.activeGroup.members.map((member) => member.user?.displayName || "旅伴").join("、")}`;
    dom.groupsHint.textContent = "选中的账单组可用于公共账单；私人小项目只会保存在自己的账号中。";
  } else {
    dom.selectedGroupPanel.classList.add("hidden");
    dom.groupsHint.textContent = "创建或加入账单组后，可以邀请朋友共同记录公共费用。";
  }
}

async function loadGroups() {
  if (!state.user) {
    stopMessagePolling();
    renderGroups();
    await refreshFootprints();
    await loadPersonalTrips();
    renderFriendsHome();
    return;
  }
  try {
    const result = await accountRequest("/api/bills", { method: "GET", headers: {} });
    state.groups = result.groups || [];
    const savedGroupId = localStorage.getItem("travelBillActiveGroupV1");
    const nextId = state.activeGroup?.id || savedGroupId || state.groups[0]?.id;
    state.activeGroup = nextId ? await loadGroup(nextId, false) : null;
  } catch (error) { toast(error.message, "error"); }
  renderGroups();
  await refreshFootprints();
  await loadPersonalTrips();
  await loadFriends();
  startMessagePolling();
}

async function loadGroup(groupId, showError = true) {
  try {
    const result = await accountRequest(`/api/bills/${encodeURIComponent(groupId)}`, { method: "GET", headers: {} });
    localStorage.setItem("travelBillActiveGroupV1", groupId);
    state.participants = result.group.members.map((member) => member.user?.displayName || "旅伴");
    renderParticipants();
    mergeRemoteExpenses(result.group);
    return result.group;
  } catch (error) {
    if (showError) toast(error.message, "error");
    return null;
  }
}

function remoteExpenseToEntry(expense, group) {
  const namesById = Object.fromEntries(group.members.map((member) => [member.userId, member.user?.displayName || "旅伴"]));
  const splitParticipants = (expense.splitParticipants || []).map((id) => namesById[id]).filter(Boolean);
  const splitAmounts = Object.fromEntries(Object.entries(expense.splitAmounts || {}).map(([id, cents]) => [namesById[id], Number(cents || 0) / 100]).filter(([name]) => name));
  return {
    id: expense.id,
    remoteId: expense.id,
    groupId: group.id,
    visibility: expense.visibility,
    syncStatus: "synced",
    source: "manual",
    date: expense.date,
    item: expense.item,
    category: expense.category,
    amount: Number(expense.amountCents || 0) / 100,
    reason: expense.visibility === "private" ? "云端私人小项目" : "云端公共账单",
    needsReview: false,
    splitMode: expense.splitMode || "none",
    splitParticipants,
    splitAmounts,
    payerUserId: expense.payerUserId || "",
    splitParticipantIds: expense.splitParticipants || [],
    splitAmountCents: expense.splitAmounts || {},
    splitAutomatic: false,
  };
}

function mergeRemoteExpenses(group) {
  const remoteIds = new Set((group.expenses || []).map((expense) => expense.id));
  const keepLocal = state.entries.filter((entry) => !entry.groupId || (entry.groupId === group.id && !entry.remoteId));
  const remoteEntries = (group.expenses || []).map((expense) => remoteExpenseToEntry(expense, group));
  state.entries = [...keepLocal.filter((entry) => !entry.remoteId || remoteIds.has(entry.remoteId)), ...remoteEntries];
  renderExpenses();
  renderCharts();
  persist();
}

async function createBillGroup() {
  if (!state.user) return toast("请先登录账号", "error");
  const name = dom.groupNameInput.value.trim();
  if (!name) return toast("请填写账单组名称", "error");
  try {
    const result = await accountRequest("/api/bills", { method: "POST", body: JSON.stringify({ name }) });
    dom.groupNameInput.value = "";
    state.groups = [result.group, ...state.groups];
    state.activeGroup = await loadGroup(result.group.id);
    state.activeTab = "friends";
    state.viewMode = "detail";
    state.activeChatGroupId = "";
    renderGroups();
    renderAppTab();
    await loadFriends();
    toast("账单组已创建");
  } catch (error) { toast(error.message, "error"); }
}

async function joinBillGroup() {
  if (!state.user) return toast("请先登录账号", "error");
  const code = dom.inviteCodeInput.value.trim();
  if (!code) return toast("请输入邀请码", "error");
  try {
    const result = await accountRequest("/api/bills/join", { method: "POST", body: JSON.stringify({ code }) });
    dom.inviteCodeInput.value = "";
    state.groups = (await accountRequest("/api/bills", { method: "GET", headers: {} })).groups || [];
    state.activeGroup = await loadGroup(result.group.id);
    state.activeTab = "friends";
    state.viewMode = "detail";
    state.activeChatGroupId = "";
    renderGroups();
    renderAppTab();
    await loadFriends();
    toast(`已加入：${result.group.name}`);
  } catch (error) { toast(error.message, "error"); }
}

function openCreateTripDialog(kind = "personal") {
  dom.createTripDialog.classList.toggle("group-mode", kind === "group");
  dom.createTripTitle.textContent = kind === "group" ? "新建共同账单" : "新建个人账单";
  dom.createTripHint.textContent = kind === "group" ? "创建后可以生成邀请码，邀请好友共同记录费用、照片和聊天。" : "先写一个容易找到的名称，日期、地点和国旗会在录入费用后自动补全。";
  dom.createTripName.value = kind === "group" ? "" : "";
  dom.confirmCreateTripBtn.textContent = kind === "group" ? "创建共同账单" : "创建并进入";
  dom.createGroupFromMenuBtn.classList.add("hidden");
  dom.openInviteFromMenuBtn.classList.toggle("hidden", kind !== "group");
  dom.addFriendFromMenuBtn.classList.toggle("hidden", kind !== "group");
  dom.friendInviteBox.classList.add("hidden");
  dom.menuInviteCode.value = "";
  dom.createTripDialog.dataset.kind = kind;
  dom.createTripDialog.showModal();
  setTimeout(() => dom.createTripName.focus(), 50);
}

async function confirmCreatePersonalTrip() {
  const name = dom.createTripName.value.trim() || "我的旅行";
  if (dom.createTripDialog.dataset.kind === "group") {
    dom.createTripDialog.close();
    dom.groupNameInput.value = name;
    await createBillGroup();
    return;
  }
  try {
    let trip;
    if (state.user) {
      const result = await accountRequest("/api/personal/trips", { method: "POST", body: JSON.stringify({ name }) });
      trip = result.trip;
      state.personalTrips = [trip, ...state.personalTrips];
    } else {
      trip = { id: `local-${uid()}`, name, tripMeta: {}, local: true, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      const localTrips = parseStored("travelBillPersonalTripsV1", []);
      localTrips.unshift(trip);
      localStorage.setItem("travelBillPersonalTripsV1", JSON.stringify(localTrips));
    }
    dom.createTripDialog.close();
    await openPersonalTrip(trip.id);
    toast("个人账单已创建");
  } catch (error) { toast(error.message, "error"); }
}

async function loadPersonalTrips() {
  if (!state.user) {
    state.personalTrips = [];
    renderPersonalTrips();
    return;
  }
  try {
    const result = await accountRequest(`/api/personal/trips?q=${encodeURIComponent(dom.personalTripSearch?.value || "")}`, { method: "GET", headers: {} });
    state.personalTrips = result.trips || [];
  } catch (error) {
    state.personalTrips = [];
    toast(`个人旅程同步失败：${error.message}`, "error");
  }
  renderPersonalTrips();
}

async function loadFriends() {
  try {
    const result = await accountRequest("/api/friends", { method: "GET", headers: {} });
    state.friendList = result.friends || [];
  } catch (error) {
    state.friendList = [];
    if (state.user) toast(`好友列表同步失败：${error.message}`, "error");
  }
  renderFriendsHome();
}

async function selectBillGroup(groupId) {
  state.activeGroup = await loadGroup(groupId);
  renderGroups();
  await refreshFootprints();
}

function personalTripToEntry(expense, tripId) {
  return {
    id: expense.id,
    remoteId: expense.id,
    personalTripId: tripId,
    groupId: null,
    visibility: "private",
    syncStatus: "synced",
    source: expense.source || "manual",
    date: expense.date,
    item: expense.item,
    category: expense.category,
    amount: Number(expense.amountCents || 0) / 100,
    reason: "云端个人账单",
    needsReview: false,
    splitMode: "none",
    splitParticipants: [],
    splitAmounts: {},
    splitAutomatic: false,
  };
}

async function openPersonalTrip(tripId) {
  state.activeTab = "personal";
  state.viewMode = "detail";
  state.activeChatGroupId = "";
  state.activeChatFriendId = "";
  state.chatReturnView = "list";
  state.activePersonalTripId = tripId;
  localStorage.setItem("travelBillActiveTabV1", "personal");
  localStorage.setItem("travelBillActivePersonalTripV1", tripId);
  if (state.user && !String(tripId).startsWith("local-")) {
    try {
      const result = await accountRequest(`/api/personal/trips/${encodeURIComponent(tripId)}`, { method: "GET", headers: {} });
      const keep = state.entries.filter((entry) => entry.groupId || entry.personalTripId !== tripId);
      state.entries = [...keep, ...(result.trip.expenses || []).map((expense) => personalTripToEntry(expense, tripId))];
      state.personalTrips = state.personalTrips.map((trip) => trip.id === tripId ? { ...trip, ...result.trip } : trip);
    } catch (error) { toast(error.message, "error"); }
  }
  renderAppTab();
  render();
  await refreshFootprints();
}

async function openGroupTrip(groupId) {
  state.activeTab = "friends";
  state.viewMode = "detail";
  state.activeChatGroupId = "";
  state.activeChatFriendId = "";
  state.activeChatMode = "group";
  state.chatReturnView = "list";
  state.activePersonalTripId = "";
  localStorage.setItem("travelBillActiveTabV1", "friends");
  state.activeGroup = await loadGroup(groupId);
  renderGroups();
  renderAppTab();
  await refreshFootprints();
}

async function openGroupChat(groupId, name) {
  const previousView = state.viewMode;
  state.activeTab = "friends";
  state.viewMode = "detail";
  state.activeChatMode = "group";
  state.chatReturnView = previousView === "detail" ? "detail" : "list";
  state.activeChatGroupId = groupId;
  state.activeChatFriendId = "";
  state.activeChatFriendName = name || "好友聊天";
  state.activeGroup = await loadGroup(groupId);
  await loadChatMessages();
  markChatRead(groupId);
  hideMessageNotification();
  renderAppTab();
}

async function openFriendChat(friendId, name) {
  state.activeTab = "friends";
  state.viewMode = "detail";
  state.activeChatMode = "direct";
  state.chatReturnView = "list";
  state.activeChatGroupId = "";
  state.activeChatFriendId = friendId;
  state.activeChatFriendName = name || "好友私聊";
  state.chatSearch = "";
  state.chatMessages = [];
  await loadChatMessages();
  hideMessageNotification();
  renderAppTab();
}

async function loadChatMessages() {
  const conversationKey = state.activeChatMode === "direct" ? state.activeChatFriendId : state.activeChatGroupId;
  if (!conversationKey || !state.user) return;
  const mode = state.activeChatMode === "direct" ? "direct" : "group";
  const scope = chatScope(mode, conversationKey);
  state.chatMessages = localChatFilter(await localChatMessages(scope), state.chatSearch);
  renderChat();
  try {
    const query = state.chatSearch ? `?q=${encodeURIComponent(state.chatSearch)}` : "";
    const endpoint = state.activeChatMode === "direct" ? `/api/friends/${encodeURIComponent(state.activeChatFriendId)}/messages${query}` : `/api/bills/${encodeURIComponent(state.activeChatGroupId)}/messages${query}`;
    const result = await accountRequest(endpoint, { method: "GET", headers: {} });
    const merged = await mergeLocalChat(scope, result.messages || []);
    await cacheAndAcknowledgeWeb(result.messages || [], mode, conversationKey);
    state.chatMessages = localChatFilter(merged, state.chatSearch);
    if (state.activeChatMode === "group") markChatRead(state.activeChatGroupId, state.chatMessages);
    else markDirectChatRead(state.activeChatFriendId, state.chatMessages);
  } catch (error) { toast(`聊天记录加载失败：${error.message}`, "error"); }
  renderChat();
}

function renderChat() {
  const chatOpen = state.activeChatMode === "direct" ? Boolean(state.activeChatFriendId) : Boolean(state.activeChatGroupId);
  if (!dom.chatCard || !chatOpen) return;
  dom.closeChatBtn.textContent = state.activeChatMode === "group" && state.chatReturnView === "detail" ? "‹ 账单" : "‹ 好友";
  dom.chatEyebrow.textContent = state.activeChatMode === "direct" ? "好友私聊" : "账单组群聊";
  dom.chatTitle.textContent = state.activeChatMode === "direct" ? (state.activeChatFriendName || "好友私聊") : (state.activeGroup?.name ? `${state.activeGroup.name} · 群聊` : (state.activeChatFriendName || "好友群聊"));
  const messages = state.chatMessages || [];
  dom.chatMessages.innerHTML = messages.length ? messages.map((message) => {
    const mine = message.senderId === state.user?.id;
    const media = message.mediaId ? (message.type === "livePhoto"
      ? `<button class="chat-media-download" type="button" data-chat-download="${escapeHtml(message.mediaId)}" data-chat-filename="${escapeHtml(message.body || "实况照片.zip")}">▣ 保存实况照片原文件</button>`
      : message.type === "video" ? `<video class="chat-media" controls playsinline data-chat-media-id="${escapeHtml(message.mediaId)}"></video>` : message.type === "audio" ? `<audio class="chat-audio" controls data-chat-media-id="${escapeHtml(message.mediaId)}"></audio>` : `<img class="chat-media" data-chat-media-id="${escapeHtml(message.mediaId)}" alt="聊天原图" />`) : "";
    return `<article class="chat-message ${mine ? "mine" : "other"}"><span class="chat-sender">${escapeHtml(message.sender?.displayName || (mine ? "我" : "旅伴"))}</span>${media}${message.body ? `<p>${escapeHtml(message.body)}</p>` : ""}<time>${escapeHtml(displayDate(String(message.createdAt || "").slice(0, 10)))}</time></article>`;
  }).join("") : `<div class="media-empty">${state.chatSearch ? "没有找到匹配的聊天记录" : "还没有聊天记录，发一条消息开始吧"}</div>`;
  dom.chatMessages.querySelectorAll("[data-chat-media-id]").forEach((element) => loadMediaPreview(element.dataset.chatMediaId, element));
}

async function sendChatMessage() {
  const conversationKey = state.activeChatMode === "direct" ? state.activeChatFriendId : state.activeChatGroupId;
  if (!conversationKey) return toast("请先选择聊天对象", "error");
  const body = dom.chatMessageInput.value.trim();
  if (!body) return toast("请输入消息", "error");
  try {
    const endpoint = state.activeChatMode === "direct" ? `/api/friends/${encodeURIComponent(state.activeChatFriendId)}/messages` : `/api/bills/${encodeURIComponent(state.activeChatGroupId)}/messages`;
    await accountRequest(endpoint, { method: "POST", body: JSON.stringify({ type: "text", body }) });
    dom.chatMessageInput.value = "";
    await loadChatMessages();
  } catch (error) { toast(error.message, "error"); }
}

async function uploadChatMedia(file, typeOverride = "") {
  const conversationKey = state.activeChatMode === "direct" ? state.activeChatFriendId : state.activeChatGroupId;
  if (!file || !conversationKey || !state.user) return;
  try {
    const form = new FormData();
    form.append("file", file, file.name);
    form.append("tripKey", conversationKey);
    form.append("visibility", state.activeChatMode === "direct" ? "private" : "group");
    const mediaEndpoint = state.activeChatMode === "direct" ? `/api/friends/${encodeURIComponent(state.activeChatFriendId)}/media` : `/api/bills/${encodeURIComponent(state.activeChatGroupId)}/media`;
    const uploadResult = await mediaUploadRequest(mediaEndpoint, form);
    await saveLocalChatMedia(uploadResult.media.id, file);
    const messageEndpoint = state.activeChatMode === "direct" ? `/api/friends/${encodeURIComponent(state.activeChatFriendId)}/messages` : `/api/bills/${encodeURIComponent(state.activeChatGroupId)}/messages`;
    await accountRequest(messageEndpoint, { method: "POST", body: JSON.stringify({ type: typeOverride || uploadResult.media.mediaType, mediaId: uploadResult.media.id }) });
    await loadChatMessages();
    toast("原图已发送");
  } catch (error) { toast(error.message, "error"); }
}

async function toggleVoiceRecording() {
  if (state.chatRecorder) {
    state.chatRecorder.stop();
    return;
  }
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) return toast("当前浏览器不支持语音录制", "error");
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    state.chatAudioChunks = [];
    state.chatRecorder = recorder;
    recorder.ondataavailable = (event) => { if (event.data.size) state.chatAudioChunks.push(event.data); };
    recorder.onstop = async () => {
      stream.getTracks().forEach((track) => track.stop());
      state.chatRecorder = null;
      dom.chatRecordBtn.textContent = "🎙";
      const blob = new Blob(state.chatAudioChunks, { type: recorder.mimeType || "audio/webm" });
      const extension = (recorder.mimeType || "").includes("mp4") ? "m4a" : "webm";
      await uploadChatMedia(new File([blob], `语音消息.${extension}`, { type: blob.type }), "audio");
    };
    recorder.start();
    dom.chatRecordBtn.textContent = "■";
    toast("正在录制语音，再点一次结束");
  } catch (error) { toast(`无法使用麦克风：${error.message}`, "error"); }
}

async function createGroupInvite() {
  if (!state.activeGroup) return;
  try {
    const result = await accountRequest(`/api/bills/${encodeURIComponent(state.activeGroup.id)}/invites`, { method: "POST", body: "{}" });
    dom.inviteCodeResult.textContent = `邀请码：${result.invite.code}`;
    toast(`邀请码：${result.invite.code}`);
  } catch (error) { toast(error.message, "error"); }
}

async function refreshActiveGroup() {
  if (!state.activeGroup) return;
  state.activeGroup = await loadGroup(state.activeGroup.id);
  renderGroups();
  await refreshFootprints();
  toast("账单已刷新");
}

function groupMemberIdByName(name) {
  return state.activeGroup?.members.find((member) => (member.user?.displayName || "旅伴") === name)?.userId || "";
}

function groupExpensePayload(entry) {
  const members = state.activeGroup?.members.map((member) => member.userId) || [];
  const selectedNames = entry.splitMode === "selected" ? entry.splitParticipants : state.participants;
  const splitParticipants = entry.visibility === "private" ? [] : selectedNames.map(groupMemberIdByName).filter(Boolean);
  const splitAmounts = Object.fromEntries(Object.entries(entry.splitAmounts || {}).map(([name, amount]) => [groupMemberIdByName(name), Math.round(Number(amount || 0) * 100)]).filter(([id]) => id));
  entry.payerUserId = state.user?.id || entry.payerUserId || "";
  entry.splitParticipantIds = entry.splitMode === "all" ? members : splitParticipants;
  entry.splitAmountCents = splitAmounts;
  return {
    date: entry.date,
    item: entry.item,
    category: entry.category,
    amountCents: Math.round(Number(entry.amount || 0) * 100),
    visibility: entry.visibility === "private" ? "private" : "group",
    payerUserId: state.user?.id,
    splitMode: entry.visibility === "private" ? "none" : (entry.splitMode || "none"),
    splitParticipants: entry.splitMode === "all" ? members : splitParticipants,
    splitAmounts,
  };
}

async function syncEntryToGroup(entry) {
  if (!state.user || !state.activeGroup || entry.groupId !== state.activeGroup.id || entry.remoteId) return;
  try {
    const result = await accountRequest(`/api/bills/${encodeURIComponent(state.activeGroup.id)}/expenses`, { method: "POST", body: JSON.stringify(groupExpensePayload(entry)) });
    entry.remoteId = result.expense.id;
    entry.syncStatus = "synced";
    persist();
  } catch (error) {
    entry.syncStatus = "pending";
    toast(`本机已保存，云端暂未同步：${error.message}`, "error");
    persist();
  }
}

async function syncPersonalEntry(entry) {
  if (!state.user || !entry.personalTripId || String(entry.personalTripId).startsWith("local-") || entry.personalTripId === "local-current" || entry.remoteId) return;
  try {
    const result = await accountRequest(`/api/personal/trips/${encodeURIComponent(entry.personalTripId)}/expenses`, { method: "POST", body: JSON.stringify({ date: entry.date, item: entry.item, category: entry.category, amountCents: Math.round(Number(entry.amount || 0) * 100), source: entry.source }) });
    entry.remoteId = result.expense.id;
    entry.syncStatus = "synced";
    persist();
    await loadPersonalTrips();
  } catch (error) {
    entry.syncStatus = "pending";
    toast(`个人账单已保存，云端暂未同步：${error.message}`, "error");
    persist();
  }
}

async function syncUpdatedEntry(entry) {
  if (state.user && !entry.groupId && entry.personalTripId && !String(entry.personalTripId).startsWith("local-") && entry.personalTripId !== "local-current" && entry.remoteId) {
    try {
      await accountRequest(`/api/personal/trips/${encodeURIComponent(entry.personalTripId)}/expenses/${encodeURIComponent(entry.remoteId)}`, { method: "PUT", body: JSON.stringify({ date: entry.date, item: entry.item, category: entry.category, amountCents: Math.round(Number(entry.amount || 0) * 100) }) });
      entry.syncStatus = "synced";
      persist();
    } catch (error) { toast(`个人账单修改未同步：${error.message}`, "error"); }
    return;
  }
  if (!state.user || !state.activeGroup || entry.groupId !== state.activeGroup.id || !entry.remoteId) return;
  try {
    await accountRequest(`/api/bills/${encodeURIComponent(state.activeGroup.id)}/expenses/${encodeURIComponent(entry.remoteId)}`, { method: "PUT", body: JSON.stringify(groupExpensePayload(entry)) });
    entry.syncStatus = "synced";
    persist();
  } catch (error) {
    entry.syncStatus = "pending";
    toast(`本机修改已保存，云端暂未同步：${error.message}`, "error");
    persist();
  }
}

async function loadAccount() {
  if (!state.session) {
    renderAccount();
    renderGroups();
    return refreshFootprints();
  }
  try {
    const result = await accountRequest("/api/auth/me", { method: "GET", headers: {} });
    state.user = result.user;
  } catch {
    state.session = "";
    state.user = null;
    localStorage.removeItem("travelBillSessionV1");
  }
  renderAccount();
  await loadGroups();
}

async function loginDevelopment() {
  const displayName = dom.devDisplayName.value.trim();
  if (!displayName) return toast("请先填写显示姓名", "error");
  try {
    const result = await accountRequest("/api/auth/dev-login", { method: "POST", body: JSON.stringify({ displayName }) });
    state.session = result.session;
    state.user = result.user;
    localStorage.setItem("travelBillSessionV1", state.session);
    renderAccount();
    await loadGroups();
    dom.accountDialog.close();
    toast(`已登录：${state.user.displayName}`);
  } catch (error) { toast(error.message, "error"); }
}

async function requestOtpCode() {
  const identifier = dom.otpIdentifier.value.trim();
  if (!identifier) return toast("请先填写邮箱", "error");
  const remainingBeforeRequest = otpCooldownRemaining();
  if (otpRequestInFlight) {
    dom.otpHint.textContent = "正在发送验证码，请稍候…";
    return;
  }
  if (remainingBeforeRequest > 0) {
    dom.otpHint.textContent = `验证码已发送，请等待 ${remainingBeforeRequest} 秒后再获取。`;
    return;
  }
  otpRequestInFlight = true;
  dom.otpRequestButton.disabled = true;
  dom.otpRequestButton.textContent = "发送中…";
  try {
    const result = await accountRequest("/api/auth/request-code", { method: "POST", body: JSON.stringify({ identifier }) });
    otpChallengeId = result.challengeId || "";
    dom.otpCodePanel.classList.remove("hidden");
    dom.otpHint.textContent = result.code
      ? `验证码已生成（本地开发）：${result.code}（5 分钟内有效）`
      : `验证码已发送至 ${result.destination || identifier}，请查收邮件；验证码 5 分钟内有效。`;
    dom.otpCode.focus();
    startOtpCooldown(Math.max(60, Number(result.resendAfter) || 60));
    toast("验证码已发送，请查收邮件");
  } catch (error) {
    dom.otpRequestButton.disabled = false;
    dom.otpRequestButton.textContent = "获取验证码";
    dom.otpHint.textContent = friendlyOtpMessage(error);
    toast(dom.otpHint.textContent, "error");
  } finally {
    otpRequestInFlight = false;
  }
}

function otpCooldownRemaining() {
  return Math.max(0, Math.ceil((otpCooldownUntil - Date.now()) / 1000));
}

function startOtpCooldown(seconds) {
  clearInterval(otpCooldownTimer);
  otpCooldownUntil = Date.now() + Math.max(60, seconds) * 1000;
  const update = () => {
    const remaining = otpCooldownRemaining();
    dom.otpRequestButton.textContent = remaining > 0 ? `重新获取（${remaining}秒）` : "重新获取验证码";
    dom.otpRequestButton.disabled = remaining > 0 || otpRequestInFlight;
    if (remaining <= 0) {
      clearInterval(otpCooldownTimer);
      otpCooldownTimer = null;
    }
  };
  update();
  otpCooldownTimer = setInterval(update, 250);
}

function friendlyOtpMessage(error) {
  const raw = String(error?.message || "").trim();
  const lower = raw.toLowerCase();
  if (error?.status === 429 || raw.includes("频繁") || raw.includes("过多") || lower.includes("rate limit") || lower.includes("too many") || lower.includes("security purposes")) {
    return "验证码请求过于频繁，请等待倒计时结束后再获取";
  }
  if (lower.includes("network") || lower.includes("could not connect") || lower.includes("not connected") || lower.includes("timed out") || raw.includes("无法连接")) {
    return "暂时无法连接账号服务，请检查网络后重试";
  }
  if (lower.includes("expired") || lower.includes("invalid otp") || lower.includes("invalid token")) {
    return "验证码不正确或已过期，请重新获取";
  }
  return raw || "账号服务暂时不可用，请稍后重试";
}

async function verifyOtpCode() {
  const identifier = dom.otpIdentifier.value.trim();
  const code = dom.otpCode.value.trim();
  if (!otpChallengeId) return toast("请先获取验证码", "error");
  if (!/^\d{6}$/.test(code)) return toast("请输入 6 位验证码", "error");
  try {
    const result = await accountRequest("/api/auth/verify-code", { method: "POST", body: JSON.stringify({ challengeId: otpChallengeId, identifier, code, displayName: dom.otpDisplayName.value.trim() }) });
    state.session = result.session;
    state.user = result.user;
    localStorage.setItem("travelBillSessionV1", state.session);
    clearInterval(otpCooldownTimer);
    otpCooldownTimer = null;
    otpCooldownUntil = 0;
    renderAccount();
    await loadGroups();
    dom.accountDialog.close();
    toast(`已登录：${state.user.displayName}`);
  } catch (error) { toast(error.message, "error"); }
}

async function loginAppleFromMac() {
  try {
    const config = await accountRequest("/api/auth/config", { method: "GET", headers: {} });
    if (!config.appleWebConfigured) return toast("Mac 网页端 Apple 登录还需要配置 Services ID 和正式域名", "error");
    if (!window.AppleID) {
      await new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid/1/en_US/appleid.auth.js";
        script.onload = resolve;
        script.onerror = () => reject(new Error("Apple 登录组件加载失败"));
        document.head.appendChild(script);
      });
    }
    window.AppleID.auth.init({ clientId: config.appleWebClientId, scope: "name email", redirectURI: config.appleWebRedirectURI, usePopup: true });
    const result = await window.AppleID.auth.signIn();
    const displayName = [result.user?.name?.firstName, result.user?.name?.lastName].filter(Boolean).join("");
    const login = await accountRequest("/api/auth/apple", { method: "POST", body: JSON.stringify({ identityToken: result.authorization?.id_token || "", displayName }) });
    state.session = login.session;
    state.user = login.user;
    localStorage.setItem("travelBillSessionV1", state.session);
    renderAccount();
    await loadGroups();
    dom.accountDialog.close();
    toast(`已登录：${state.user.displayName}`);
  } catch (error) { toast(error.message, "error"); }
}

async function createMacPairing() {
  try {
    const result = await accountRequest("/api/pairing/create", { method: "POST", body: JSON.stringify({ deviceName: "Mac" }) });
    dom.pairingPanel.classList.remove("hidden");
    dom.pairingCode.textContent = result.displayCode || result.code;
    const expiresAt = Date.parse(result.expiresAt || "");
    dom.pairingHint.textContent = "5 分钟内有效，仅可使用一次；请不要把配对码告诉其他人";
    clearInterval(pairingPollTimer);
    const poll = async () => {
      if (Number.isFinite(expiresAt) && Date.now() >= expiresAt) {
        clearInterval(pairingPollTimer);
        pairingPollTimer = null;
        dom.pairingHint.textContent = "配对码已过期，请重新生成";
        return;
      }
      try {
        const status = await fetch(`/api/pairing/status?id=${encodeURIComponent(result.id)}&token=${encodeURIComponent(result.token)}`).then((response) => response.json());
        if (status.status !== "claimed") return;
        clearInterval(pairingPollTimer);
        pairingPollTimer = null;
        if (!status.user || !status.session) return toast("绑定账号记录已失效，请在 iPhone 退出后重新登录，再生成新的绑定码", "error");
        state.session = status.session;
        state.user = status.user;
        localStorage.setItem("travelBillSessionV1", state.session);
        renderAccount();
        await loadGroups();
        dom.pairingPanel.classList.add("hidden");
        dom.accountDialog.close();
        toast(`Mac 已绑定：${state.user.displayName}`);
      } catch {}
    };
    pairingPollTimer = setInterval(poll, 1500);
    await poll();
  } catch (error) { toast(error.message, "error"); }
}

function logoutAccount() {
  clearInterval(pairingPollTimer);
  stopMessagePolling();
  state.session = "";
  state.user = null;
  state.groups = [];
  state.activeGroup = null;
  state.participants = [];
  state.footprints = { countries: [], cities: [], places: [] };
  localStorage.removeItem("travelBillSessionV1");
  localStorage.removeItem("travelBillActiveGroupV1");
  renderAccount();
  renderGroups();
  renderParticipants();
  renderExpenses();
  renderFootprints();
  dom.accountDialog.close();
  toast("已退出登录");
}

function openHandleDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("travelBillHandles", 1);
    request.onupgradeneeded = () => request.result.createObjectStore("handles");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function storeExportDirectory(handle) {
  const database = await openHandleDatabase();
  await new Promise((resolve, reject) => {
    const transaction = database.transaction("handles", "readwrite");
    transaction.objectStore("handles").put(handle, "exportDirectory");
    transaction.oncomplete = resolve;
    transaction.onerror = () => reject(transaction.error);
  });
  database.close();
}

async function restoreExportDirectory() {
  try {
    const database = await openHandleDatabase();
    exportDirectoryHandle = await new Promise((resolve, reject) => {
      const transaction = database.transaction("handles", "readonly");
      const request = transaction.objectStore("handles").get("exportDirectory");
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
    database.close();
    if (exportDirectoryHandle) {
      dom.exportFolderStatus.textContent = `保存到：${exportDirectoryHandle.name}（导出时确认权限）`;
    }
  } catch {}
}

async function chooseExportFolder() {
  if (!("showDirectoryPicker" in window)) {
    dom.exportFolderStatus.textContent = "当前浏览器不支持固定文件夹，导出时会打开系统保存窗口";
    return toast("请使用 Chrome 或 Edge 设置固定保存文件夹", "error");
  }
  try {
    const handle = await window.showDirectoryPicker({ id: "travel-bill-export", mode: "readwrite" });
    exportDirectoryHandle = handle;
    await storeExportDirectory(handle);
    dom.exportFolderStatus.classList.remove("verified");
    dom.exportFolderStatus.textContent = `保存到：${handle.name}`;
    toast("保存文件夹已设置");
  } catch (error) {
    if (error?.name !== "AbortError") toast("保存文件夹设置失败", "error");
  }
}

async function ensureDirectoryPermission(handle) {
  if (!handle) return false;
  const options = { mode: "readwrite" };
  if ((await handle.queryPermission(options)) === "granted") return true;
  return (await handle.requestPermission(options)) === "granted";
}

async function saveBlobToSelectedDirectory(blob, filename) {
  if (!exportDirectoryHandle || !(await ensureDirectoryPermission(exportDirectoryHandle))) return false;
  const fileHandle = await exportDirectoryHandle.getFileHandle(filename, { create: true });
  const writable = await fileHandle.createWritable();
  await writable.write(blob);
  await writable.close();
  const savedFile = await fileHandle.getFile();
  if (savedFile.size !== blob.size || savedFile.size <= 0) throw new Error("文件已写入，但保存核对未通过");
  dom.exportFolderStatus.classList.add("verified");
  dom.exportFolderStatus.textContent = `已保存并核对：${exportDirectoryHandle.name}/${filename}`;
  return true;
}

function uid() { return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`; }
function money(value) { return `¥${Number(value || 0).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; }
function escapeHtml(value) { return String(value ?? "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]); }

function normalizedExpenseItem(value) {
  return String(value || "").normalize("NFKC").toLowerCase().replace(/[^\u4e00-\u9fffA-Za-z0-9]/g, "");
}

function updateReviewState(entry) {
  if (entry.source !== "image") return;
  const missing = [!entry.date && "日期", !(Number(entry.amount) > 0) && "金额", entry.categoryNeedsReview && "分类"].filter(Boolean);
  entry.needsReview = missing.length > 0;
  if (missing.length) entry.reason = `${missing.join("、")}未识别，请补充`;
  else if (/未识别，请补充/.test(entry.reason || "")) entry.reason = "图片识别后已人工补充";
}

function mergeImageExpense(next) {
  const nextItem = normalizedExpenseItem(next.item);
  if (!nextItem) return false;
  const duplicate = state.entries.find((entry) => {
    if (entry.source !== "image" || normalizedExpenseItem(entry.item) !== nextItem) return false;
    if (entry.date && next.date && entry.date !== next.date) return false;
    if (entry.transactionTime && next.transactionTime && entry.transactionTime !== next.transactionTime) return false;
    const left = Number(entry.amount) || 0;
    const right = Number(next.amount) || 0;
    if (left > 0 && right > 0) return Math.abs(left - right) < 0.005;
    return Boolean(entry.transactionTime && next.transactionTime && entry.transactionTime === next.transactionTime);
  });
  if (!duplicate) return false;
  if (!duplicate.date && next.date) duplicate.date = next.date;
  if (!duplicate.transactionTime && next.transactionTime) duplicate.transactionTime = next.transactionTime;
  if (!(Number(duplicate.amount) > 0) && Number(next.amount) > 0) duplicate.amount = Number(next.amount);
  if ((duplicate.reason || "").includes("未识别") && next.reason) duplicate.reason = next.reason;
  updateReviewState(duplicate);
  return true;
}

function toast(message, type = "ok") {
  dom.toast.textContent = message;
  dom.toast.className = `toast show ${type === "error" ? "error" : ""}`;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { dom.toast.className = "toast"; }, 3200);
}

function persist() {
  const entries = state.entries.map(({ rawText, ...entry }) => entry);
  localStorage.setItem("travelBillDraftV2", JSON.stringify({ entries, fuelRows: state.fuelRows, participants: state.participants, selectedDate: state.selectedDate }));
}

function dateParts(value) {
  const text = String(value || "").trim();
  const full = text.match(/(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})/);
  if (full) return { year: Number(full[1]), month: Number(full[2]), day: Number(full[3]) };
  const short = text.match(/(\d{1,2})[-/.月](\d{1,2})日?/);
  return short ? { year: new Date().getFullYear(), month: Number(short[1]), day: Number(short[2]) } : null;
}

function displayDate(value) {
  const parts = dateParts(value);
  return parts ? `${parts.month}月${parts.day}日` : String(value || "选择日期");
}

function dateOrder(value) {
  const parts = dateParts(value);
  return parts ? parts.year * 10000 + parts.month * 100 + parts.day : Number.MAX_SAFE_INTEGER;
}

function knownDates(extra = "") {
  return [...new Set([state.selectedDate, extra, ...state.entries.map((entry) => entry.date), ...state.fuelRows.map((row) => row.date)].filter(Boolean))]
    .sort((a, b) => dateOrder(a) - dateOrder(b));
}

function dateOptions(selected = "", includeNew = false) {
  const values = knownDates(selected);
  const options = [`<option value="">选择日期</option>`, ...values.map((date) => `<option value="${escapeHtml(date)}" ${date === selected ? "selected" : ""}>${escapeHtml(displayDate(date))}</option>`)];
  if (includeNew) options.push(`<option value="__new__">＋ 添加日期</option>`);
  return options.join("");
}

function categoryOptions(selected) {
  return CATEGORIES.map((category) => `<option value="${category}" ${category === selected ? "selected" : ""}>${category}</option>`).join("");
}

function splitModeOptions(selected) {
  return ["none", "all", "selected", "custom"].map((mode) => `<option value="${mode}" ${mode === selected ? "selected" : ""}>${splitModeLabel(mode)}</option>`).join("");
}

function splitSuggestionText(entry) {
  if (!state.participants.length) return "当前按个人账，不分账";
  const suggestion = splitSuggestion(entry.item, entry.category);
  return entry.splitAutomatic && entry.splitMode === suggestion.mode ? `自动建议：${suggestion.reason}` : `系统建议：${suggestion.reason}`;
}

function ensureEntrySplit(entry, automatic = false) {
  if (!entry.splitMode) {
    const suggestion = automatic ? splitSuggestion(entry.item, entry.category) : { mode: "none" };
    entry.splitMode = suggestion.mode;
    entry.splitAutomatic = Boolean(automatic);
  }
  if (!Array.isArray(entry.splitParticipants)) entry.splitParticipants = [];
  if (!entry.splitAmounts || typeof entry.splitAmounts !== "object") entry.splitAmounts = {};
}

function renderParticipants() {
  dom.participantCount.textContent = `${state.participants.length} 人`;
  dom.participantChips.innerHTML = state.participants.map((name) => `<button type="button" class="participant-chip" data-remove-participant="${escapeHtml(name)}"><span>${escapeHtml(name)}</span><b>×</b></button>`).join("");
  dom.splitSetupHint.textContent = state.participants.length
    ? `已加入 ${state.participants.length} 人。每笔费用可选择 AA、指定人员平摊、按人填写金额，个人消费可选不分账。`
    : "未填写姓名时按个人账处理，只保留每笔总金额；填写姓名后才启用分账。";
}

function addParticipant() {
  const name = dom.participantInput.value.trim();
  if (!name) return toast("请输入姓名", "error");
  if (state.participants.includes(name)) return toast("这个姓名已经加入", "error");
  state.participants.push(name);
  dom.participantInput.value = "";
  state.entries.forEach((entry) => {
    ensureEntrySplit(entry);
    if (entry.splitAutomatic) entry.splitMode = splitSuggestion(entry.item, entry.category).mode;
  });
  render();
  dom.participantInput.focus();
}

function splitPeopleEditor(entry) {
  if (entry.splitMode === "selected") {
    return `<div class="split-people">${state.participants.map((name) => `<button type="button" class="split-person ${entry.splitParticipants.includes(name) ? "selected" : ""}" data-split-person="${escapeHtml(name)}">${escapeHtml(name)}</button>`).join("")}</div>`;
  }
  if (entry.splitMode === "custom") {
    return `<div class="split-amounts">${state.participants.map((name) => `<label><span>${escapeHtml(name)}</span><input type="number" min="0" step="0.01" data-split-amount="${escapeHtml(name)}" value="${entry.splitAmounts[name] ?? ""}" placeholder="0.00" /></label>`).join("")}</div>`;
  }
  if (entry.splitMode === "all") return `<span class="split-result">${state.participants.length ? `每人 ${money((Number(entry.amount) || 0) / state.participants.length)}（${state.participants.length}人）` : "请先填写姓名"}</span>`;
  return "";
}

function splitCell(entry) {
  ensureEntrySplit(entry);
  const issue = splitIssue(entry, state.participants);
  return `<td data-label="分账" class="split-cell"><div class="split-line"><div class="table-select select-shell"><select data-field="splitMode">${splitModeOptions(entry.splitMode)}</select></div><span class="split-suggestion">${escapeHtml(splitSuggestionText(entry))}</span></div>${splitPeopleEditor(entry)}${issue ? `<small class="split-issue">${escapeHtml(issue)}</small>` : ""}</td>`;
}

function renderManualControls() {
  dom.manualDate.innerHTML = dateOptions(state.selectedDate, true);
  dom.manualDate.value = state.selectedDate || "";
  if (!dom.manualCategory.options.length) dom.manualCategory.innerHTML = categoryOptions("购物");
  const color = LIGHT[dom.manualCategory.value] || LIGHT.购物;
  dom.manualCategory.closest(".select-shell").style.setProperty("--category-color", color);
}

async function classify(items) {
  const response = await fetch("/api/classify", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ items, learned: state.learned, web: true }),
  });
  if (!response.ok) throw new Error("分类服务暂时不可用");
  return (await response.json()).results;
}

function saveCorrection(item, category) {
  const key = String(item || "").trim().replace(/\s+/g, " ").toLowerCase();
  if (!key) return;
  state.learned[key] = category;
  localStorage.setItem("travelBillLearned", JSON.stringify(state.learned));
}

let classifyTimer;
let classifySequence = 0;
function scheduleManualClassification() {
  clearTimeout(classifyTimer);
  const item = dom.manualItem.value.trim();
  if (!item) {
    dom.classificationHint.textContent = "";
    return;
  }
  const sequence = ++classifySequence;
  dom.classificationHint.textContent = "正在网页检索…";
  classifyTimer = setTimeout(async () => {
    try {
      const [result] = await classify([item]);
      if (sequence !== classifySequence || dom.manualItem.value.trim() !== item) return;
      if (!dom.manualCategory.dataset.changed) dom.manualCategory.value = result.category;
      dom.classificationHint.textContent = `${result.category} · ${result.reason}`;
      renderManualControls();
    } catch (error) {
      dom.classificationHint.textContent = error.message;
    }
  }, 650);
}

async function addManualExpense(event) {
  event.preventDefault();
  const date = state.selectedDate || dom.manualDate.value;
  const item = dom.manualItem.value.trim();
  const amount = Number(dom.manualAmount.value);
  if (!date) return toast("请选择日期", "error");
  if (!item) return toast("请填写项目", "error");
  if (!Number.isFinite(amount) || amount <= 0) return toast("请填写正确金额", "error");
  let category = dom.manualCategory.value;
  let reason = "由你手动选择";
  try {
    const [result] = await classify([item]);
    if (!dom.manualCategory.dataset.changed) {
      category = result.category;
      reason = result.reason;
    }
  } catch {}
  const suggestion = splitSuggestion(item, category);
  const inFriendsBill = state.activeTab === "friends" && state.activeGroup;
  const visibility = inFriendsBill ? dom.manualVisibility.value : "private";
  const entry = { id: uid(), date, item, category, amount, reason, source: "manual", visibility, groupId: inFriendsBill ? state.activeGroup.id : null, personalTripId: !inFriendsBill && state.activeTab === "personal" ? (state.activePersonalTripId || "local-current") : "", splitMode: visibility === "private" ? "none" : (state.participants.length ? suggestion.mode : "none"), splitAutomatic: true, splitParticipants: [], splitAmounts: {}, syncStatus: inFriendsBill ? "pending" : "local" };
  state.entries.push(entry);
  dom.manualItem.value = "";
  dom.manualAmount.value = "";
  dom.manualCategory.dataset.changed = "";
  dom.manualCategory.value = "购物";
  dom.classificationHint.textContent = "";
  render();
  if (entry.groupId) await syncEntryToGroup(entry);
  else await syncPersonalEntry(entry);
  toast("已加入 1 笔费用");
  dom.manualItem.focus();
}

function fuelCost(row) {
  return Number(row.distance || 0) * Number(row.consumption || 0) / 100 * Number(row.price || 0);
}

function fuelInline(entry) {
  if (!entry.fuelId) return "";
  const row = state.fuelRows.find((item) => item.id === entry.fuelId);
  if (!row) return "";
  const priceLabel = row.price ? `${money(row.price)}/L${row.priceDate ? ` · ${displayDate(row.priceDate)}` : ""}` : "正在获取油价";
  return `<div class="fuel-inline">
    <div class="mini-select select-shell"><select data-fuel-field="province" aria-label="油价省份">${PROVINCES.map((province) => `<option ${province === row.province ? "selected" : ""}>${province}</option>`).join("")}</select></div>
    <div class="mini-select grade-select select-shell"><select data-fuel-field="grade" aria-label="汽油标号">${FUEL_GRADES.map((grade) => `<option ${grade === row.grade ? "selected" : ""}>${grade}</option>`).join("")}</select></div>
    <span>${escapeHtml(priceLabel)}</span>
  </div>`;
}

function renderExpenses() {
  const entries = activeEntries();
  const hasRows = entries.length > 0;
  dom.expenseEmpty.classList.toggle("hidden", hasRows);
  dom.expenseTableWrap.classList.toggle("hidden", !hasRows);
  dom.expenseSplitHead.classList.toggle("hidden", !state.participants.length);
  dom.entryCount.textContent = `${entries.length} 笔`;
  dom.expenseRows.innerHTML = entries.map((entry) => {
    ensureEntrySplit(entry);
    return `
    <tr data-id="${entry.id}" class="${entry.needsReview ? "needs-review" : ""}" style="--row-color:${LIGHT[entry.category] || LIGHT.购物}">
      <td data-label="日期"><div class="table-select select-shell"><select data-field="date">${dateOptions(entry.date)}</select></div></td>
      <td data-label="项目"><input data-field="item" value="${escapeHtml(entry.item)}" aria-label="项目" />${fuelInline(entry)}</td>
      <td data-label="分类" class="category-cell"><div class="table-select select-shell"><select data-field="category">${categoryOptions(entry.category)}</select></div><span class="confidence" title="${escapeHtml(entry.reason)}">${escapeHtml(entry.reason || "手动设置")}</span></td>
      <td data-label="金额"><input data-field="amount" class="money-input" type="number" min="0" step="0.01" value="${entry.needsReview && !(Number(entry.amount) > 0) ? "" : Number(entry.amount || 0).toFixed(2)}" placeholder="待补充" aria-label="金额" /></td>
      ${state.participants.length ? splitCell(entry) : ""}
      <td class="delete-cell"><button class="delete-row" data-action="delete" type="button" title="删除">×</button></td>
    </tr>`;
  }).join("");
}

function categoryTotals() {
  const totals = Object.fromEntries(CATEGORIES.map((category) => [category, 0]));
  activeEntries().forEach((entry) => { totals[entry.category] = (totals[entry.category] || 0) + Number(entry.amount || 0); });
  return totals;
}

function renderCharts() {
  const totals = categoryTotals();
  const total = Object.values(totals).reduce((sum, value) => sum + value, 0);
  const max = Math.max(...Object.values(totals), 1);
  dom.grandTotal.textContent = money(total);
  dom.mobileTotal.textContent = money(total);
  dom.totalDetail.textContent = `共 ${activeEntries().length} 笔费用`;
  const personal = personalTotal();
  dom.personalTotal.classList.toggle("hidden", !(state.user && state.activeGroup));
  dom.personalTotal.textContent = `我的承担：${money(personal)}`;
  dom.barChart.innerHTML = CATEGORIES.map((category) => `
    <div class="bar-row"><span>${category}</span><div class="bar-track"><div class="bar-fill" style="width:${(totals[category] / max) * 100}%;background:${COLORS[category]}"></div></div><span class="bar-value">${money(totals[category])}</span></div>`).join("");
  let cursor = 0;
  const gradients = CATEGORIES.map((category) => {
    const start = cursor;
    cursor += total ? totals[category] / total * 100 : 0;
    return `${COLORS[category]} ${start}% ${cursor}%`;
  });
  dom.donutChart.style.background = total ? `conic-gradient(${gradients.join(",")})` : "#e9e7e0";
  dom.donutChart.querySelector("strong").textContent = `¥${Math.round(total).toLocaleString("zh-CN")}`;
  dom.chartLegend.innerHTML = CATEGORIES.map((category) => `<div class="legend-row"><span class="legend-dot" style="background:${COLORS[category]}"></span><span>${category}</span><b>${total ? Math.round(totals[category] / total * 100) : 0}%</b></div>`).join("");
}

function personalShare(entry) {
  const amount = Number(entry.amount || 0);
  if (!state.user || !state.activeGroup || entry.groupId !== state.activeGroup.id) return amount;
  if (entry.visibility === "private") return amount;
  const mode = entry.splitMode || "none";
  const ids = Array.isArray(entry.splitParticipantIds) && entry.splitParticipantIds.length ? entry.splitParticipantIds : (entry.splitParticipants || []).map(groupMemberIdByName).filter(Boolean);
  if (mode === "custom") {
    const cents = Number(entry.splitAmountCents?.[state.user.id]);
    return Number.isFinite(cents) ? cents / 100 : Number(entry.splitAmounts?.[state.user.displayName] || 0);
  }
  if (mode === "all" || mode === "selected") {
    const names = ids.length ? ids : (entry.splitParticipants || []);
    const index = ids.length ? ids.indexOf(state.user.id) : names.indexOf(state.user.displayName);
    if (index < 0 || !names.length) return 0;
    const average = Math.round((amount / names.length) * 100) / 100;
    return index === names.length - 1 ? Math.round((amount - average * (names.length - 1)) * 100) / 100 : average;
  }
  return entry.payerUserId === state.user.id || entry.payerUserId === state.user.displayName ? amount : 0;
}

function personalTotal() {
  return state.entries.reduce((sum, entry) => sum + personalShare(entry), 0);
}

function syncFuelExpense(row) {
  let entry = state.entries.find((item) => item.fuelId === row.id);
  if (!entry) {
    const inFriendsBill = state.activeTab === "friends" && state.activeGroup;
    entry = { id: uid(), fuelId: row.id, source: "fuel", date: row.date || state.selectedDate, item: "自驾油费", amount: 0, category: "交通", reason: "由里程、油耗和当日油价自动计算", splitMode: inFriendsBill && state.participants.length ? "all" : "none", splitAutomatic: true, splitParticipants: [], splitAmounts: {}, visibility: inFriendsBill ? "group" : "private", groupId: inFriendsBill ? state.activeGroup.id : null, personalTripId: !inFriendsBill && state.activeTab === "personal" ? (state.activePersonalTripId || "local-current") : "", syncStatus: inFriendsBill ? "pending" : "local" };
    state.entries.push(entry);
  }
  entry.date = row.date || entry.date || state.selectedDate;
  entry.item = `自驾油费${row.route ? `（${row.route}）` : ""} · ${row.grade}`;
  entry.amount = fuelCost(row);
  entry.category = "交通";
  if (entry.splitAutomatic) entry.splitMode = state.participants.length ? "all" : "none";
  entry.reason = row.price ? "由里程、油耗和当日油价自动计算" : "正在获取当日油价";
}

async function addFuelRow(seed = {}, silent = false) {
  const row = {
    id: uid(),
    date: seed.date || state.selectedDate || localIso(),
    route: seed.route || "自驾行程",
    distance: Number(seed.distance) || 0,
    consumption: Number(seed.consumption) || 0,
    province: seed.province || state.inferredTrip.province || "浙江",
    grade: FUEL_GRADES.includes(seed.grade) ? seed.grade : "95#",
    price: Number(seed.price) || 0,
    priceDate: seed.priceDate || "",
    priceSource: seed.priceSource || "",
    autoProvince: !seed.province,
  };
  state.fuelRows.push(row);
  syncFuelExpense(row);
  render();
  if (!row.price) await lookupPrice(row, silent);
  const entry = state.entries.find((item) => item.fuelId === row.id);
  if (entry) {
    if (entry.groupId) await syncEntryToGroup(entry);
    else await syncPersonalEntry(entry);
  }
  return row;
}

async function lookupPrice(row, silent = false) {
  const entry = state.entries.find((item) => item.fuelId === row.id);
  if (entry) entry.reason = "正在获取当日油价";
  renderExpenses();
  try {
    const response = await fetch("/api/oil-price", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ province: row.province }),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "油价查询失败");
    row.price = Number(payload.prices?.[row.grade.replace("#", "")]) || 0;
    row.priceDate = payload.date || "";
    row.priceSource = payload.source || "";
    syncFuelExpense(row);
    render();
    if (entry) {
      if (entry.groupId) await syncEntryToGroup(entry);
      else await syncPersonalEntry(entry);
    }
    if (!silent) toast(`已按${row.province}${row.grade}参考价重新计算`);
  } catch (error) {
    if (entry) entry.reason = "油价获取失败，请手动填写金额";
    render();
    toast(error.message, "error");
  }
}

let tripTimer;
let tripSequence = 0;
function scheduleTripInference() {
  clearTimeout(tripTimer);
  const sequence = ++tripSequence;
  tripTimer = setTimeout(async () => {
    try {
      const response = await fetch("/api/infer-trip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ entries: activeEntries(), fuelRows: state.fuelRows }),
      });
      if (!response.ok) return;
      const trip = await response.json();
      if (sequence !== tripSequence) return;
      state.inferredTrip = trip;
      dom.autoTripTitle.textContent = trip.title || "录入费用后自动识别";
      dom.tripSummary.textContent = trip.title || "等待录入费用";
      dom.filenamePreview.textContent = trip.startDate ? buildFilename(trip) : "日期、地点、国旗和文件名会自动生成";
      const rows = state.fuelRows.filter((row) => row.autoProvince && trip.province && row.province !== trip.province);
      rows.forEach((row) => { row.province = trip.province; });
      rows.forEach((row) => lookupPrice(row, true));
    } catch {}
  }, 160);
}

function buildFilename(trip) {
  const destination = trip.destination || trip.locations || "旅行";
  if (!trip.startDate) return `日期未识别${destination}.xlsx`;
  const start = trip.startDate.split("-").map(Number);
  const end = (trip.endDate || trip.startDate).split("-").map(Number);
  const endLabel = start[0] === end[0] ? `${end[1]}.${end[2]}` : `${end[0]}.${end[1]}.${end[2]}`;
  return `${start[0]}.${start[1]}.${start[2]}-${endLabel}${destination}.xlsx`;
}

function render() {
  renderManualControls();
  renderParticipants();
  renderExpenses();
  renderCharts();
  scheduleTripInference();
  persist();
}

async function recognizeImages(files) {
  if (!files.length) return { expenses: 0, fuel: 0 };
  const data = new FormData();
  files.forEach((file) => data.append("images", file));
  data.append("learned", JSON.stringify(state.learned));
  const response = await fetch("/api/ocr", { method: "POST", body: data });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "图片识别失败");
  let expenses = 0;
  let fuel = 0;
  let duplicates = Number(payload.duplicates) || 0;
  for (const result of payload.results) {
    if (result.kind === "fuel" || result.fuelRows?.length) {
      for (const row of result.fuelRows || []) {
        await addFuelRow(row, true);
        fuel += 1;
      }
      continue;
    }
    for (const entry of result.entries || []) {
      const missing = [!entry.date && "日期", !(Number(entry.amount) > 0) && "金额"].filter(Boolean);
      const categoryNeedsReview = Number(entry.confidence) < 0.7 || /请确认/.test(entry.reason || "");
      if (categoryNeedsReview) missing.push("分类");
      const inFriendsBill = state.activeTab === "friends" && state.activeGroup;
      const next = {
        id: uid(),
        date: entry.date || "",
        transactionTime: entry.transactionTime || "",
        item: entry.item,
        amount: Number(entry.amount) || 0,
        category: entry.category,
        reason: missing.length ? `${missing.join("、")}待确认` : entry.reason,
        source: "image",
        needsReview: missing.length > 0,
        categoryNeedsReview,
        splitMode: (!inFriendsBill || dom.manualVisibility.value === "private") ? "none" : (state.participants.length ? splitSuggestion(entry.item, entry.category).mode : "none"),
        splitAutomatic: true,
        splitParticipants: [],
        splitAmounts: {},
        visibility: inFriendsBill ? dom.manualVisibility.value : "private",
        groupId: inFriendsBill ? state.activeGroup.id : null,
        personalTripId: !inFriendsBill && state.activeTab === "personal" ? (state.activePersonalTripId || "local-current") : "",
        syncStatus: inFriendsBill ? "pending" : "local",
      };
      if (mergeImageExpense(next)) {
        duplicates += 1;
        continue;
      }
      state.entries.push(next);
      expenses += 1;
      if (next.groupId) await syncEntryToGroup(next);
      else await syncPersonalEntry(next);
    }
  }
  render();
  return { expenses, fuel, duplicates, review: state.entries.filter((entry) => entry.source === "image" && entry.needsReview).length };
}

async function importFuelFile(file) {
  const data = new FormData();
  data.append("file", file);
  const response = await fetch("/api/fuel-import", { method: "POST", body: data });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "油耗表导入失败");
  for (const row of payload.rows) await addFuelRow(row, true);
  return payload.rows.length;
}

async function handleSelectedFiles(fileList) {
  const files = [...(fileList || [])];
  if (!files.length) return;
  const tables = files.filter((file) => /\.(xlsx|csv)$/i.test(file.name));
  const images = files.filter((file) => !/\.(xlsx|csv)$/i.test(file.name));
  dom.ocrProgress.classList.remove("hidden");
  try {
    let importedFuel = 0;
    for (const file of tables) importedFuel += await importFuelFile(file);
    const recognized = await recognizeImages(images);
    const totalExpenses = recognized.expenses + recognized.fuel + importedFuel;
    const details = [
      recognized.fuel + importedFuel ? `${recognized.fuel + importedFuel} 笔油费` : "",
      recognized.duplicates ? `合并 ${recognized.duplicates} 笔重复记录` : "",
      recognized.review ? `${recognized.review} 笔待补充` : "",
    ].filter(Boolean);
    toast(`已加入 ${totalExpenses} 笔费用${details.length ? `，${details.join("，")}` : ""}`);
  } catch (error) {
    toast(error.message, "error");
  } finally {
    dom.ocrProgress.classList.add("hidden");
    dom.imageInput.value = "";
    dom.cameraInput.value = "";
  }
}

async function exportWorkbook() {
  const entries = activeEntries();
  if (!entries.length) return toast("请先加入至少一笔费用", "error");
  const reviewCount = entries.filter((entry) => entry.needsReview).length;
  if (reviewCount) return toast(`还有 ${reviewCount} 笔待确认，请检查后再导出`, "error");
  const splitCount = entries.filter((entry) => splitIssue(entry, state.participants)).length;
  if (splitCount) return toast(`还有 ${splitCount} 笔分账未完成，请检查同行人或金额`, "error");
  const buttons = [dom.exportBtn, dom.mobileExportBtn];
  buttons.forEach((button) => { button.disabled = true; });
  dom.exportBtn.querySelector("span").textContent = "正在生成…";
  dom.mobileExportBtn.textContent = "生成中…";
  try {
    if (exportDirectoryHandle && !(await ensureDirectoryPermission(exportDirectoryHandle))) {
      throw new Error("没有保存文件夹权限，请重新设置保存文件夹");
    }
    const response = await fetch("/api/export", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ entries, fuelRows: state.fuelRows, participants: state.participants, personalUserId: state.activeTab === "friends" ? (state.user?.id || "") : "", personalName: state.user?.displayName || "" }),
    });
    if (!response.ok) {
      const payload = await response.json();
      throw new Error(payload.error || "Excel 生成失败");
    }
    const blob = await response.blob();
    const disposition = response.headers.get("content-disposition") || "";
    const nameMatch = disposition.match(/filename\*=UTF-8''([^;]+)/i);
    const filename = nameMatch ? decodeURIComponent(nameMatch[1]) : buildFilename(state.inferredTrip);
    const serverVerified = response.headers.get("x-travel-bill-verified") === "ok";
    if (!serverVerified) throw new Error("Excel 已生成，但内部核对未通过");
    const saved = await saveBlobToSelectedDirectory(blob, filename);
    if (!saved) {
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = filename;
      link.click();
      setTimeout(() => URL.revokeObjectURL(link.href), 1200);
      dom.exportFolderStatus.classList.remove("verified");
      dom.exportFolderStatus.textContent = "工作簿内部核对成功；请在浏览器下载窗口确认保存位置";
    }
    toast(saved ? "Excel 已保存并核对成功" : "Excel 已核对并生成");
  } catch (error) {
    toast(error.message, "error");
  } finally {
    buttons.forEach((button) => { button.disabled = false; });
    dom.exportBtn.querySelector("span").textContent = "生成 Excel 账单";
    dom.mobileExportBtn.textContent = "生成 Excel";
  }
}

dom.manualEntryForm.addEventListener("submit", addManualExpense);
dom.manualItem.addEventListener("input", () => {
  dom.manualCategory.dataset.changed = "";
  scheduleManualClassification();
});
dom.manualCategory.addEventListener("change", () => {
  dom.manualCategory.dataset.changed = "1";
  renderManualControls();
});
dom.manualDate.addEventListener("change", () => {
  if (dom.manualDate.value === "__new__") {
    dom.manualDatePicker.classList.remove("hidden");
    dom.manualDatePicker.focus();
    dom.manualDatePicker.showPicker?.();
    return;
  }
  state.selectedDate = dom.manualDate.value;
  dom.manualDatePicker.classList.add("hidden");
  persist();
});
dom.manualDatePicker.addEventListener("change", () => {
  if (!dom.manualDatePicker.value) return;
  state.selectedDate = dom.manualDatePicker.value;
  dom.manualDatePicker.classList.add("hidden");
  renderManualControls();
  persist();
});

dom.addParticipantBtn.addEventListener("click", addParticipant);
dom.participantInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") { event.preventDefault(); addParticipant(); }
});

dom.accountButton.addEventListener("click", () => dom.accountDialog.showModal());
document.querySelectorAll("[data-app-tab]").forEach((button) => button.addEventListener("click", () => setAppTab(button.dataset.appTab)));
dom.createPersonalTripBtn?.addEventListener("click", () => openCreateTripDialog("personal"));
dom.friendsPlusBtn?.addEventListener("click", () => openCreateTripDialog("group"));
dom.createTripCloseBtn?.addEventListener("click", (event) => {
  event.preventDefault();
  dom.createTripDialog.close();
});
dom.confirmCreateTripBtn?.addEventListener("click", confirmCreatePersonalTrip);
dom.openInviteFromMenuBtn?.addEventListener("click", () => {
  dom.friendInviteBox.classList.remove("hidden");
  dom.friendInviteHint.textContent = "输入共同账单邀请码后，可一起记录费用、照片和聊天。";
  dom.menuInviteCode.focus();
});
dom.addFriendFromMenuBtn?.addEventListener("click", () => {
  if (!state.activeGroup) {
    toast("请先创建共同账单，再生成邀请码添加好友", "error");
    return;
  }
  dom.createTripDialog.close();
  createGroupInvite();
});
dom.createGroupFromMenuBtn?.addEventListener("click", () => {
  openCreateTripDialog("group");
});
dom.joinFromMenuBtn?.addEventListener("click", async () => {
  dom.inviteCodeInput.value = dom.menuInviteCode.value.trim();
  dom.createTripDialog.close();
  await joinBillGroup();
});
dom.personalTripSearch?.addEventListener("input", renderPersonalTrips);
dom.friendsSearch?.addEventListener("input", renderFriendsHome);
document.querySelectorAll("[data-friends-mode]").forEach((button) => button.addEventListener("click", () => {
  state.friendsMode = button.dataset.friendsMode;
  localStorage.setItem("travelBillFriendsModeV1", state.friendsMode);
  renderFriendsHome();
}));
dom.personalTripList?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-open-personal-trip]");
  if (button) openPersonalTrip(button.dataset.openPersonalTrip);
});
dom.friendsTripList?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-open-group-trip]");
  if (button) openGroupTrip(button.dataset.openGroupTrip);
});
dom.friendList?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-open-friend-id]");
  if (button) openFriendChat(button.dataset.openFriendId, button.dataset.friendName);
});
dom.groupChatBtn?.addEventListener("click", () => {
  if (state.activeGroup) openGroupChat(state.activeGroup.id, state.activeGroup.name);
});
dom.groupInviteBtn?.addEventListener("click", createGroupInvite);
dom.backToHistoryBtn?.addEventListener("click", () => {
  state.viewMode = "list";
  state.activeChatGroupId = "";
  state.activeChatFriendId = "";
  state.chatReturnView = "list";
  renderAppTab();
});
dom.closeChatBtn?.addEventListener("click", () => {
  const returnToDetail = state.activeChatMode === "group" && state.chatReturnView === "detail";
  state.viewMode = returnToDetail ? "detail" : "list";
  state.activeChatGroupId = "";
  state.activeChatFriendId = "";
  state.chatReturnView = "list";
  renderAppTab();
});
dom.messageNotificationBtn?.addEventListener("click", async () => {
  const groupId = state.notificationGroupId;
  const friendId = state.notificationFriendId;
  hideMessageNotification();
  if (friendId) {
    const friend = state.friendList.find((item) => item.id === friendId);
    return openFriendChat(friendId, friend?.displayName || "好友私聊");
  }
  if (groupId) await openGroupChat(groupId, "好友账单群聊");
});
dom.messageNotificationClose?.addEventListener("click", hideMessageNotification);
dom.chatSearchBtn?.addEventListener("click", () => {
  dom.chatSearchBox.classList.toggle("hidden");
  if (!dom.chatSearchBox.classList.contains("hidden")) dom.chatSearchInput.focus();
});
dom.chatSearchInput?.addEventListener("input", async () => {
  state.chatSearch = dom.chatSearchInput.value.trim();
  await loadChatMessages();
});
dom.sendChatBtn?.addEventListener("click", sendChatMessage);
dom.chatMessageInput?.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); sendChatMessage(); } });
dom.chatMediaBtn?.addEventListener("click", () => dom.chatMediaInput.click());
dom.chatRecordBtn?.addEventListener("click", toggleVoiceRecording);
dom.chatMediaInput?.addEventListener("change", () => {
  const file = dom.chatMediaInput.files?.[0];
  dom.chatMediaInput.value = "";
  uploadChatMedia(file);
});
dom.chatMessages?.addEventListener("click", (event) => {
  const button = event.target.closest("[data-chat-download]");
  if (button) downloadChatMedia(button.dataset.chatDownload, button.dataset.chatFilename || "聊天媒体");
});
dom.profileLoginBtn?.addEventListener("click", () => dom.accountDialog.showModal());
dom.profileAccountBtn?.addEventListener("click", () => dom.accountDialog.showModal());
dom.profileAvatar?.addEventListener("click", () => state.user ? dom.avatarInput?.click() : dom.accountDialog.showModal());
dom.avatarInput?.addEventListener("change", () => {
  const file = dom.avatarInput.files?.[0];
  dom.avatarInput.value = "";
  uploadAvatar(file);
});
dom.otpRequestButton.addEventListener("click", requestOtpCode);
dom.otpVerifyButton.addEventListener("click", verifyOtpCode);
dom.otpCode.addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); verifyOtpCode(); } });
if (dom.devLoginButton) dom.devLoginButton.addEventListener("click", loginDevelopment);
if (dom.appleLoginButton) dom.appleLoginButton.addEventListener("click", loginAppleFromMac);
dom.pairMacButton.addEventListener("click", createMacPairing);
dom.logoutButton.addEventListener("click", logoutAccount);
dom.createGroupBtn.addEventListener("click", createBillGroup);
dom.joinGroupBtn.addEventListener("click", joinBillGroup);
dom.refreshGroupBtn.addEventListener("click", refreshActiveGroup);
dom.createInviteBtn.addEventListener("click", createGroupInvite);
dom.groupList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-select-group]");
  if (button) selectBillGroup(button.dataset.selectGroup);
});
dom.participantChips.addEventListener("click", (event) => {
  const button = event.target.closest("[data-remove-participant]");
  if (!button) return;
  const name = button.dataset.removeParticipant;
  state.participants = state.participants.filter((participant) => participant !== name);
  state.entries.forEach((entry) => {
    ensureEntrySplit(entry);
    if (!state.participants.length && entry.splitAutomatic) entry.splitMode = "none";
    entry.splitParticipants = entry.splitParticipants.filter((participant) => participant !== name);
    delete entry.splitAmounts[name];
  });
  render();
});

$("#takePhotoBtn").addEventListener("click", () => dom.cameraInput.click());
$("#chooseImagesBtn").addEventListener("click", () => dom.imageInput.click());
dom.imageInput.addEventListener("change", () => handleSelectedFiles(dom.imageInput.files));
dom.cameraInput.addEventListener("change", () => handleSelectedFiles(dom.cameraInput.files));
dom.imageDropzone.addEventListener("dragover", (event) => { event.preventDefault(); dom.imageDropzone.classList.add("dragover"); });
dom.imageDropzone.addEventListener("dragleave", () => dom.imageDropzone.classList.remove("dragover"));
dom.imageDropzone.addEventListener("drop", (event) => {
  event.preventDefault();
  dom.imageDropzone.classList.remove("dragover");
  handleSelectedFiles(event.dataTransfer.files);
});

$("#clearEntriesBtn").addEventListener("click", () => {
  if (state.activeTab === "friends" && state.activeGroup) state.entries = state.entries.filter((entry) => entry.groupId !== state.activeGroup.id);
  else state.entries = state.entries.filter((entry) => entry.groupId);
  state.fuelRows = state.fuelRows.filter((row) => state.entries.some((entry) => entry.fuelId === row.id));
  if (state.activeTab === "friends") state.participants = [];
  state.selectedDate = localIso();
  state.inferredTrip = {};
  render();
});
dom.exportBtn.addEventListener("click", exportWorkbook);
dom.mobileExportBtn.addEventListener("click", exportWorkbook);
dom.chooseExportFolderBtn.addEventListener("click", chooseExportFolder);

dom.expenseRows.addEventListener("input", (event) => {
  if (event.target.dataset.fuelField) return;
  const rowElement = event.target.closest("tr");
  const entry = state.entries.find((item) => item.id === rowElement?.dataset.id);
  const splitPerson = event.target.dataset.splitAmount;
  if (entry && splitPerson) {
    ensureEntrySplit(entry);
    entry.splitAmounts[splitPerson] = Number(event.target.value) || 0;
    persist();
    return;
  }
  const field = event.target.dataset.field;
  if (!entry || !field) return;
  if (field === "category") entry.categoryNeedsReview = false;
  entry[field] = field === "amount" ? Number(event.target.value) : event.target.value;
  if (field === "category" && entry.splitAutomatic) entry.splitMode = state.participants.length ? splitSuggestion(entry.item, entry.category).mode : "none";
  updateReviewState(entry);
  if (field === "date" && entry.fuelId) {
    const fuelRow = state.fuelRows.find((item) => item.id === entry.fuelId);
    if (fuelRow) fuelRow.date = entry.date;
  }
  renderCharts();
  scheduleTripInference();
  persist();
});

dom.expenseRows.addEventListener("change", async (event) => {
  const rowElement = event.target.closest("tr");
  const entry = state.entries.find((item) => item.id === rowElement?.dataset.id);
  if (!entry) return;
  const fuelField = event.target.dataset.fuelField;
  if (fuelField && entry.fuelId) {
    const fuelRow = state.fuelRows.find((item) => item.id === entry.fuelId);
    if (!fuelRow) return;
    fuelRow[fuelField] = event.target.value;
    if (fuelField === "province") fuelRow.autoProvince = false;
    await lookupPrice(fuelRow);
    return;
  }
  const splitPerson = event.target.dataset.splitAmount;
  if (splitPerson) {
    ensureEntrySplit(entry);
    entry.splitAmounts[splitPerson] = Number(event.target.value) || 0;
    persist();
    await syncUpdatedEntry(entry);
    return;
  }
  const field = event.target.dataset.field;
  if (!field) return;
  if (field === "splitMode") {
    ensureEntrySplit(entry);
    entry.splitMode = event.target.value;
    entry.splitAutomatic = false;
    if (entry.splitMode === "selected" && !entry.splitParticipants.length) entry.splitParticipants = state.participants.slice();
    if (entry.splitMode === "custom" && !entry.splitAmounts) entry.splitAmounts = {};
    render();
    await syncUpdatedEntry(entry);
    return;
  }
  if (field === "category") entry.categoryNeedsReview = false;
  entry[field] = field === "amount" ? Number(event.target.value) : event.target.value;
  updateReviewState(entry);
  if (field === "category") {
    entry.reason = "由你手动修正";
    saveCorrection(entry.item, entry.category);
  }
  render();
  await syncUpdatedEntry(entry);
});

dom.expenseRows.addEventListener("focusout", async (event) => {
  if (event.target.dataset.field !== "item") return;
  const entry = state.entries.find((item) => item.id === event.target.closest("tr")?.dataset.id);
  if (!entry) return;
  entry.item = event.target.value.trim();
  if (entry.splitAutomatic) entry.splitMode = state.participants.length ? splitSuggestion(entry.item, entry.category).mode : "none";
  if (entry.fuelId) {
    persist();
    return;
  }
  try {
    const [result] = await classify([entry.item]);
    entry.category = result.category;
    entry.categoryNeedsReview = Number(result.confidence) < 0.7 || /请确认/.test(result.reason || "");
    entry.reason = result.reason;
    updateReviewState(entry);
    render();
    await syncUpdatedEntry(entry);
  } catch {}
});

dom.expenseRows.addEventListener("click", async (event) => {
  const personButton = event.target.closest("[data-split-person]");
  if (personButton) {
    const entry = state.entries.find((item) => item.id === event.target.closest("tr")?.dataset.id);
    if (!entry) return;
    ensureEntrySplit(entry);
    const name = personButton.dataset.splitPerson;
    entry.splitParticipants = entry.splitParticipants.includes(name)
      ? entry.splitParticipants.filter((participant) => participant !== name)
      : [...entry.splitParticipants, name];
    entry.splitAutomatic = false;
    render();
    await syncUpdatedEntry(entry);
    return;
  }
  if (event.target.dataset.action !== "delete") return;
  const id = event.target.closest("tr")?.dataset.id;
  const entry = state.entries.find((item) => item.id === id);
  if (entry?.remoteId && state.activeGroup) {
    try {
      await accountRequest(`/api/bills/${encodeURIComponent(state.activeGroup.id)}/expenses/${encodeURIComponent(entry.remoteId)}`, { method: "DELETE" });
    } catch (error) {
      return toast(error.message, "error");
    }
  }
  if (entry?.remoteId && entry.personalTripId && !String(entry.personalTripId).startsWith("local-") && entry.personalTripId !== "local-current") {
    try {
      await accountRequest(`/api/personal/trips/${encodeURIComponent(entry.personalTripId)}/expenses/${encodeURIComponent(entry.remoteId)}`, { method: "DELETE" });
    } catch (error) {
      return toast(error.message, "error");
    }
  }
  if (entry?.fuelId) state.fuelRows = state.fuelRows.filter((row) => row.id !== entry.fuelId);
  state.entries = state.entries.filter((item) => item.id !== id);
  render();
});

state.fuelRows.forEach((row) => syncFuelExpense(row));
render();
renderAccount();
renderGroups();
renderAppTab();
loadAccount();
restoreExportDirectory();

if ("serviceWorker" in navigator) navigator.serviceWorker.register("/service-worker.js").catch(() => {});
