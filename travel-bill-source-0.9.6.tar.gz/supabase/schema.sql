-- 旅迹账单云端状态：只允许 API 服务端使用 service_role 访问。
-- payload 是服务端 AES-256-GCM 加密后的完整状态快照，不向客户端暴露。
create table if not exists public.travel_bill_state (
  id text primary key,
  payload text not null,
  updated_at timestamptz not null default now()
);

alter table public.travel_bill_state enable row level security;
revoke all on table public.travel_bill_state from anon, authenticated;
grant all on table public.travel_bill_state to service_role;

insert into public.travel_bill_state (id, payload)
values ('main', '')
on conflict (id) do nothing;

-- 私有桶：服务端先加密媒体，再上传；送达确认或过期后由服务端删除对象。
insert into storage.buckets (id, name, public)
values ('travel-bill-relay', 'travel-bill-relay', false)
on conflict (id) do update set public = false;
