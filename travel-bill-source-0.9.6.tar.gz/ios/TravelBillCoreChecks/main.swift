import Foundation
import TravelBillCore
import ZIPFoundation

enum CheckError: Error, CustomStringConvertible {
    case failed(String)
    var description: String {
        switch self { case let .failed(message): message }
    }
}

func require(_ condition: @autoclosure () -> Bool, _ message: String) throws {
    if !condition() { throw CheckError.failed(message) }
}

do {
    let route = OCRParser.parse(lines: ["贵阳→铜仁 68.00"], referenceDate: "2026-08-17")
    guard case let .expenses(routeEntries) = route else { throw CheckError.failed("路线费用被错误识别成油耗") }
    try require(routeEntries.count == 1, "路线费用数量错误")
    try require(routeEntries[0].category == .transport, "路线费用没有归为交通")

    let incompleteFuel = OCRParser.parse(lines: ["贵阳→铜仁", "里程 320 km"], referenceDate: "2026-08-17")
    if case .fuel = incompleteFuel { throw CheckError.failed("缺少百公里油耗却生成了油费") }
    let completeFuel = OCRParser.parse(lines: ["路线：贵阳→凯里", "里程 180 km", "百公里油耗 7.2 L/100km"], referenceDate: "2026-08-17")
    guard case let .fuel(candidate) = completeFuel else { throw CheckError.failed("完整油耗记录无法识别") }
    try require(candidate.distance == 180 && candidate.consumption == 7.2, "油耗数值识别错误")

    try require(CategoryClassifier.classifyLocal("霸王茶姬").category == .food, "热门茶饮品牌分类错误")
    try require(CategoryClassifier.classifyLocal("贵阳→铜仁高铁").category == .transport, "箭头行程分类错误")
    try require(TransportDetails.format("12306 金华→贵阳火车票（2人）") == "金华站→贵阳北站（2人）", "高铁项目没有整理成车站到车站")
    let airports = TransportDetails.inferAirports(entries: [ExpenseEntry(date: "2026-07-27", item: "飞机票 杭州→贵阳", category: .transport, amount: 800)])
    try require(airports.map(\.code) == ["HGH", "KWE"], "机场名称或三字码推断错误")
    let fuelCSV = "日期,行程,里程(km),百公里油耗(L),省份,油号\n2026-08-17,测试自驾,100,7.2,贵州,95#\n"
    let importedFuel = try FuelTableImporter.read(data: Data(fuelCSV.utf8), filename: "油耗.csv")
    try require(importedFuel.count == 1 && importedFuel[0].grade == "95#" && importedFuel[0].distance == 100, "油耗表导入错误")

    let rows = [
        ExpenseEntry(date: "2026-07-27", item: "金华→贵阳火车票（2人）", category: .transport, amount: 1458),
        ExpenseEntry(date: "2026-07-28", item: "贵阳酒店", category: .stayPlay, amount: 1000.44),
        ExpenseEntry(date: "2026-07-29", item: "凯里晚饭", category: .food, amount: 163),
        ExpenseEntry(date: "2026-07-30", item: "贵州文创", category: .shopping, amount: 45),
        ExpenseEntry(date: "2026-08-01", item: "铜仁旅行用品", category: .supplies, amount: 187),
    ]
    let noFuel = try XLSXExporter.makeWorkbook(entries: rows)
    try XLSXExporter.verify(noFuel.data, expectsFuel: false)
    try require(noFuel.filename == "2026.7.27-8.1🇨🇳贵阳、凯里、铜仁.xlsx", "文件名推断错误")
    let noFuelArchive = try Archive(data: noFuel.data, accessMode: .read, pathEncoding: nil)
    try require(noFuelArchive["xl/worksheets/sheet2.xml"] == nil, "无油耗记录时仍生成了油耗工作表")

    let fuel = FuelRecord(date: "2026-08-17", route: "测试自驾行程", distance: 100, consumption: 7, province: "贵州", grade: "95#", price: 8.24, priceDate: "2026-08-17")
    let withFuel = try XLSXExporter.makeWorkbook(entries: [ExpenseEntry(date: "2026-08-17", item: "飞机票 杭州→贵阳", category: .transport, amount: 800, splitMode: .all, splitAutomatic: true)], fuelRecords: [fuel], participants: ["甲", "乙"])
    try XLSXExporter.verify(withFuel.data, expectsFuel: true, expectsSplit: true)
    let fuelArchive = try Archive(data: withFuel.data, accessMode: .read, pathEncoding: nil)
    try require(fuelArchive["xl/worksheets/sheet2.xml"] != nil, "明确导入油耗后没有生成油耗工作表")
    try require(fuelArchive["xl/worksheets/sheet3.xml"] != nil, "填写同行人并选择分账后没有生成分账工作表")

    let groupID = "group-personal-check"
    let personalRows = [
        ExpenseEntry(date: "2026-08-17", item: "四人晚饭", category: .food, amount: 400, splitMode: .all, splitParticipants: ["甲", "乙", "丙", "丁"], groupID: groupID, visibility: .group, payerUserID: "u1", splitParticipantIDs: ["u1", "u2", "u3", "u4"]),
        ExpenseEntry(date: "2026-08-17", item: "乙的私人小吃", category: .food, amount: 23, groupID: groupID, visibility: .private, payerUserID: "u2"),
    ]
    let personal = try XLSXExporter.makeWorkbook(entries: personalRows, participants: ["甲", "乙", "丙", "丁"], personalUserID: "u2", personalName: "乙")
    try XLSXExporter.verify(personal.data, expectsFuel: false, expectsSplit: true, expectsPersonal: true)
    let personalArchive = try Archive(data: personal.data, accessMode: .read, pathEncoding: nil)
    try require(personalArchive["xl/worksheets/sheet4.xml"] != nil, "登录用户导出时没有生成个人账单工作表")

    let output = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("native-validation.xlsx")
    try noFuel.data.write(to: output, options: .atomic)
    print("原生核心检查通过：路线不会生成油耗；无油耗 Excel 仅含 Sheet1；输出 \(output.path)")
} catch {
    fputs("原生核心检查失败：\(error)\n", stderr)
    exit(1)
}
