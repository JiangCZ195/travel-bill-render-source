import Foundation

public enum CategoryClassifier {
    private struct Rule {
        let category: ExpenseCategory
        let score: Double
        let reason: String
        let pattern: String
    }

    private static let rules: [Rule] = [
        Rule(category: .transport, score: 20, reason: "识别到行程箭头", pattern: "→|↔|➡|➜|⇢"),
        Rule(category: .transport, score: 13, reason: "识别到出行平台", pattern: "滴滴|高德打车|曹操出行|t3出行|首汽约车|神州租车|一嗨租车|uber|grab"),
        Rule(category: .transport, score: 11, reason: "识别到车票或机票", pattern: "火车票|高铁票|动车票|机票|航班|航空|船票|轮渡票|客运票|车票"),
        Rule(category: .transport, score: 9, reason: "识别到交通方式", pattern: "打车|出租车|网约车|火车|高铁|动车|机场|地铁|公交|brt|轻轨|租车|包车|轮渡|摆渡车|接送机"),
        Rule(category: .transport, score: 8, reason: "识别到自驾费用", pattern: "停车|停车费|过路费|高速费|通行费|油费|加油|汽油|充电桩|服务区"),

        Rule(category: .food, score: 16, reason: "识别到常见餐饮品牌", pattern: "喜茶|奈雪(?:的茶)?|茶百道|古茗|霸王茶姬|茶颜悦色|喜小茶|沪上阿姨|书亦烧仙草|一点点|益禾堂|蜜雪冰城|蜜雪|甜啦啦|coco都可|都可茶饮|贡茶|乐乐茶|茉莉奶白|爷爷不泡茶|茶话弄|阿嬷手作|瑞幸|luckin|iuckin|库迪|星巴克|starbucks|manner|tims|幸运咖|麦当劳|mcdonald|肯德基|kfc|必胜客|汉堡王|塔斯汀|德克士|华莱士|海底捞|呷哺呷哺|太二酸菜鱼|太二|西贝|外婆家|探鱼|木屋烧烤|杨国福|张亮麻辣烫|袁记云饺|正新鸡排|紫燕百味鸡|绝味鸭脖|周黑鸭|鲍师傅|泸溪河|稻香村|好利来|dq冰淇淋|窑鸡王|费大厨|老乡鸡|乡村基|真功夫|丝恋丝娃娃|丝娃娃"),
        Rule(category: .food, score: 13, reason: "识别到用餐项目", pattern: "早餐|早饭|午餐|午饭|中饭|晚餐|晚饭|夜宵|宵夜|点餐|堂食|餐饮|餐厅|饭店|饭馆|菜馆|酒楼|食堂|外卖"),
        Rule(category: .food, score: 15, reason: "识别到食品或饮品", pattern: "奶茶|茶饮|咖啡|coffee|果汁|饮料|矿泉水|甜品|糖水|冰淇淋|雪糕|面包|烘焙|糕点|蛋糕|零食|水果|泡面"),
        Rule(category: .food, score: 10, reason: "识别到餐食品类", pattern: "火锅|烧烤|烤肉|烤鸭|烧鹅|叉烧|串串|麻辣烫|冒菜|米线|螺蛳粉|酸辣粉|牛肉粉|花溪粉|羊肉粉|酸汤鱼|黔菜|面馆|面条|拉面|粥|饺子|馄饨|包子|馒头|小吃|快餐|汉堡|披萨|鸡排|鸭脖|豆花|凉粉|寿司|刺身|日料|韩餐|肠粉|煎饼"),
        Rule(category: .food, score: 9, reason: "识别到外卖平台", pattern: "美团外卖|饿了么|外卖订单"),
        Rule(category: .food, score: 7, reason: "识别到吃喝相关字样", pattern: "吃|喝|餐|饭|菜|酒吧|啤酒|奶昔"),

        Rule(category: .stayPlay, score: 13, reason: "识别到住宿项目", pattern: "酒店|宾馆|民宿|住宿|青旅|客栈|旅馆|度假村|房费|钟点房"),
        Rule(category: .stayPlay, score: 17, reason: "识别到演出或活动项目", pattern: "演唱会|音乐会|音乐节|演出|演出票|话剧|歌剧|舞台剧|展览|展会|灯光秀|表演|赛事|球赛|体育比赛|活动票|活动门票"),
        Rule(category: .stayPlay, score: 12, reason: "识别到景点门票", pattern: "门票|景区|乐园|博物馆|美术馆|纪念馆|动物园|植物园|海洋馆|索道|缆车"),
        Rule(category: .stayPlay, score: 9, reason: "识别到游玩服务", pattern: "旅行订单|旅行社|导游|旅拍|漂流|温泉|游船|观光车|剧场|演出|电影|ktv|保险|签证"),

        Rule(category: .supplies, score: 12, reason: "识别到药品或医疗用品", pattern: "药店|医药|药品|医院|诊所|创可贴|退烧药|感冒药|晕车药|口罩"),
        Rule(category: .supplies, score: 14, reason: "识别到护肤用品", pattern: "护手霜|防晒霜|润肤乳"),
        Rule(category: .supplies, score: 12, reason: "识别到生活或旅行用品", pattern: "雨伞|纸巾|湿巾|卫生纸|洗护|洗漱|牙刷|牙膏|洗发水|沐浴露|毛巾|拖鞋|水杯|保温杯|水壶|水瓶|随行杯|马克杯|日用品|旅行用品|充电器|充电宝|数据线|防晒|驱蚊|行李箱|收纳袋"),
        Rule(category: .supplies, score: 8, reason: "识别到行李服务", pattern: "行李寄存|寄存柜|行李托运"),

        Rule(category: .shopping, score: 11, reason: "识别到购物平台或商场", pattern: "淘宝|天猫|京东|拼多多|抖音商城|小红书店铺|商场|购物中心|商业管理有限公司|奥特莱斯|旗舰店|专卖店|免税店|超市|便利店|kkv|wow colour"),
        Rule(category: .shopping, score: 10, reason: "识别到纪念品或特产", pattern: "纪念品|冰箱贴|书签|明信片|伴手礼|特产|文创|礼物"),
        Rule(category: .shopping, score: 14, reason: "识别到服饰或个人商品", pattern: "袜子|丝袜|棉袜|内衣|内裤|衣服|服饰|旗袍|裤子|裙子|外套|羽绒服|t恤|衬衫|鞋|帽|包|首饰"),
        Rule(category: .shopping, score: 9, reason: "识别到商品", pattern: "玩具|数码|耳机|杯垫|杯子|摆件|挂件|商家|电商|商品"),
    ]

    public static func normalize(_ value: String) -> String {
        value.normalizedExpenseText
            .replacingOccurrences(of: "[·•\\s]", with: "", options: .regularExpression)
    }

    public static func classifyLocal(_ item: String, learned: [String: ExpenseCategory] = [:]) -> Classification {
        let normalized = normalize(item)
        if let remembered = rememberedCategory(for: normalized, learned: learned) {
            return Classification(category: remembered, confidence: 1, reason: "采用你上次的修正")
        }

        var scores: [ExpenseCategory: (score: Double, reason: String, strongest: Double)] = [:]
        for rule in rules where normalized.range(of: rule.pattern, options: .regularExpression) != nil {
            var current = scores[rule.category] ?? (0, "", 0)
            current.score += rule.score
            if rule.score > current.strongest {
                current.strongest = rule.score
                current.reason = rule.reason
            }
            scores[rule.category] = current
        }

        guard let best = scores.max(by: { $0.value.score < $1.value.score }) else {
            return Classification(category: .shopping, confidence: 0.42, reason: "未发现明确特征，请确认")
        }
        return Classification(
            category: best.key,
            confidence: min(0.99, 0.62 + best.value.score * 0.018),
            reason: best.value.reason
        )
    }

    public static func classifySmart(_ item: String, learned: [String: ExpenseCategory] = [:]) async -> Classification {
        let local = classifyLocal(item, learned: learned)
        if local.confidence >= 0.78 || item.contains("→") { return local }
        guard let context = await searchContext(for: item), !context.isEmpty else { return local }
        let contextual = classifyWebContext(item: item, context: context)
        guard let contextual, contextual.confidence > local.confidence || local.confidence < 0.6 else { return local }
        return Classification(
            category: contextual.category,
            confidence: min(0.96, contextual.confidence),
            reason: "网页信息显示为\(contextual.category.rawValue)相关",
            usedWeb: true
        )
    }

    private static func rememberedCategory(for normalized: String, learned: [String: ExpenseCategory]) -> ExpenseCategory? {
        if let exact = learned[normalized] { return exact }
        for (known, category) in learned {
            let candidate = normalize(known)
            guard candidate.count >= 3 else { continue }
            if normalized.contains(candidate) || candidate.contains(normalized) { return category }
        }
        return nil
    }

    private static func searchContext(for item: String) async -> String? {
        guard let query = "\(item) 是什么 商户 品牌".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://cn.bing.com/search?q=\(query)&setlang=zh-hans") else { return nil }
        var request = URLRequest(url: url, cachePolicy: .returnCacheDataElseLoad, timeoutInterval: 7)
        request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15", forHTTPHeaderField: "User-Agent")
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200,
                  let html = String(data: data, encoding: .utf8) else { return nil }
            return html
                .replacingOccurrences(of: "<script[\\s\\S]*?</script>", with: " ", options: [.regularExpression, .caseInsensitive])
                .replacingOccurrences(of: "<style[\\s\\S]*?</style>", with: " ", options: [.regularExpression, .caseInsensitive])
                .replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
                .replacingOccurrences(of: "&[a-zA-Z#0-9]+;", with: " ", options: .regularExpression)
                .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                .prefix(5_000)
                .description
        } catch {
            return nil
        }
    }

    private static func classifyWebContext(item: String, context: String) -> Classification? {
        struct WebSignal {
            let category: ExpenseCategory
            let score: Double
            let reason: String
            let strongPattern: String
            let supportPattern: String
        }
        let signals = [
            WebSignal(category: .transport, score: 16, reason: "网页信息显示为交通或票务相关", strongPattern: "12306|中国铁路|火车票|高铁票|动车票|机票|航班|机场|地铁|公交|打车|网约车|租车|铁路|航空|车站", supportPattern: "出行|交通|车票|客运|站点|接送机"),
            WebSignal(category: .food, score: 16, reason: "网页信息显示为餐饮或食品相关", strongPattern: "奶茶|茶饮|咖啡|餐饮|餐厅|饭店|饭馆|美食|饮品|小吃|烤鸭|牛肉粉|酸汤鱼|火锅|烧烤|甜品|烘焙|食品", supportPattern: "菜单|堂食|外卖|餐馆|吃喝|菜品|食客|口味"),
            WebSignal(category: .stayPlay, score: 16, reason: "网页信息显示为住宿或游玩相关", strongPattern: "酒店|宾馆|民宿|客栈|住宿|房费|景区|景点|门票|博物馆|乐园|演唱会|音乐会|音乐节|演出|话剧|展览|展会|索道|漂流|温泉", supportPattern: "旅行|旅游|游玩|攻略|度假|观光"),
            WebSignal(category: .shopping, score: 16, reason: "网页信息显示为商场或商品相关", strongPattern: "商城|商场|购物|超市|便利店|旗舰店|专卖店|免税店|商品|电商|纪念品|特产|文创|袜子|丝袜|服饰|衣服|鞋|帽|包", supportPattern: "品牌|零售|店铺|售价|购买|伴手礼"),
            WebSignal(category: .supplies, score: 16, reason: "网页信息显示为生活用品或医疗相关", strongPattern: "药店|药品|医院|诊所|护肤|防晒|纸巾|湿巾|充电器|充电宝|行李|日用品|旅行用品|牙刷|牙膏|洗发水|沐浴露|毛巾|拖鞋", supportPattern: "用品|护理|医疗|健康|使用方法"),
        ]
        let normalizedItem = normalize(item)
        let lines = context.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        let clauses = lines.flatMap { $0.components(separatedBy: ["，", ",", "。", "！", "？", "；", ";", "|"]) }
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        let relatedLines = clauses.filter { normalize($0).contains(normalizedItem) }
        guard !relatedLines.isEmpty else { return nil }
        let text = relatedLines.prefix(8).joined(separator: " ")
        let ranked = signals.compactMap { signal -> (ExpenseCategory, Double, String)? in
            guard text.range(of: signal.strongPattern, options: .regularExpression) != nil else { return nil }
            let support = text.range(of: signal.supportPattern, options: .regularExpression) != nil ? 4.0 : 0
            return (signal.category, signal.score + support, signal.reason)
        }.sorted { $0.1 > $1.1 }
        guard let best = ranked.first else { return nil }
        if let second = ranked.dropFirst().first, best.1 - second.1 < 3 { return nil }
        return Classification(category: best.0, confidence: min(0.94, 0.72 + best.1 * 0.012), reason: best.2, usedWeb: true)
    }
}
