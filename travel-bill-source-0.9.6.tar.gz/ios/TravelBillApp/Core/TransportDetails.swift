import Foundation

public struct AirportInfo: Equatable, Sendable {
    public let city: String
    public let name: String
    public let short: String
    public let code: String

    public init(city: String, name: String, short: String, code: String) {
        self.city = city
        self.name = name
        self.short = short
        self.code = code
    }
}

public enum TransportDetails {
    private static let airports: [AirportInfo] = [
        AirportInfo(city: "杭州", name: "杭州萧山国际机场", short: "杭州萧山", code: "HGH"),
        AirportInfo(city: "重庆", name: "重庆江北国际机场", short: "重庆江北", code: "CKG"),
        AirportInfo(city: "北京", name: "北京大兴国际机场", short: "北京大兴", code: "PKX"),
        AirportInfo(city: "北京", name: "北京首都国际机场", short: "北京首都", code: "PEK"),
        AirportInfo(city: "贵阳", name: "贵阳龙洞堡国际机场", short: "贵阳龙洞堡", code: "KWE"),
        AirportInfo(city: "铜仁", name: "铜仁凤凰机场", short: "铜仁凤凰", code: "TEN"),
        AirportInfo(city: "凯里", name: "凯里黄平机场", short: "凯里黄平", code: "KJH"),
        AirportInfo(city: "长沙", name: "长沙黄花国际机场", short: "长沙黄花", code: "CSX"),
        AirportInfo(city: "上海", name: "上海虹桥国际机场", short: "上海虹桥", code: "SHA"),
        AirportInfo(city: "上海", name: "上海浦东国际机场", short: "上海浦东", code: "PVG"),
        AirportInfo(city: "广州", name: "广州白云国际机场", short: "广州白云", code: "CAN"),
        AirportInfo(city: "深圳", name: "深圳宝安国际机场", short: "深圳宝安", code: "SZX"),
        AirportInfo(city: "成都", name: "成都双流国际机场", short: "成都双流", code: "CTU"),
        AirportInfo(city: "成都", name: "成都天府国际机场", short: "成都天府", code: "TFU"),
        AirportInfo(city: "昆明", name: "昆明长水国际机场", short: "昆明长水", code: "KMG"),
        AirportInfo(city: "西安", name: "西安咸阳国际机场", short: "西安咸阳", code: "XIY"),
        AirportInfo(city: "南京", name: "南京禄口国际机场", short: "南京禄口", code: "NKG"),
        AirportInfo(city: "厦门", name: "厦门高崎国际机场", short: "厦门高崎", code: "XMN"),
        AirportInfo(city: "福州", name: "福州长乐国际机场", short: "福州长乐", code: "FOC"),
        AirportInfo(city: "三亚", name: "三亚凤凰国际机场", short: "三亚凤凰", code: "SYX"),
        AirportInfo(city: "海口", name: "海口美兰国际机场", short: "海口美兰", code: "HAK"),
        AirportInfo(city: "青岛", name: "青岛胶东国际机场", short: "青岛胶东", code: "TAO"),
        AirportInfo(city: "大连", name: "大连周水子国际机场", short: "大连周水子", code: "DLC"),
        AirportInfo(city: "吉隆坡", name: "吉隆坡国际机场", short: "吉隆坡国际", code: "KUL"),
        AirportInfo(city: "新加坡", name: "新加坡樟宜机场", short: "新加坡樟宜", code: "SIN"),
        AirportInfo(city: "曼谷", name: "曼谷素万那普机场", short: "曼谷素万那普", code: "BKK"),
        AirportInfo(city: "普吉", name: "普吉国际机场", short: "普吉国际", code: "HKT"),
    ]

    private static let stations: [(String, String)] = [
        ("杭州", "杭州东站"), ("重庆", "重庆北站"), ("贵阳", "贵阳北站"),
        ("凯里", "凯里南站"), ("铜仁", "铜仁站"), ("金华", "金华站"),
        ("长沙", "长沙南站"), ("广州", "广州南站"), ("深圳", "深圳北站"),
        ("北京", "北京西站"), ("上海", "上海虹桥站"), ("南京", "南京南站"),
        ("成都", "成都东站"), ("昆明", "昆明南站"), ("西安", "西安北站"),
        ("厦门", "厦门站"), ("福州", "福州站"), ("武汉", "武汉站"),
    ]

    private static func isFlight(_ value: String) -> Bool {
        let lower = value.lowercased()
        return ["飞机", "航班", "机票", "登机牌", "机场", "航站楼", "flight", "airline"].contains(where: lower.contains)
            || value.split(whereSeparator: { $0 == " " || $0 == "-" }).contains { $0.count == 3 && $0.allSatisfy { $0.isASCII && $0.isLetter } }
            || airports.contains { airport in value.localizedCaseInsensitiveContains(airport.code) }
    }

    private static func isTrain(_ value: String) -> Bool {
        ["12306", "中国铁路", "中铁", "高铁", "动车", "火车", "车票", "车次", "铁路订单"].contains(where: value.localizedCaseInsensitiveContains)
    }

    private static func splitRoute(_ value: String) -> [String] {
        value.replacingOccurrences(of: "➡", with: "→")
            .replacingOccurrences(of: "➜", with: "→")
            .replacingOccurrences(of: "⇢", with: "→")
            .replacingOccurrences(of: "↔", with: "→")
            .replacingOccurrences(of: "至", with: "→")
            .replacingOccurrences(of: "到", with: "→")
            .split(separator: "→")
            .map { cleanSegment(String($0)) }
            .filter { !$0.isEmpty }
    }

    private static func cleanSegment(_ value: String) -> String {
        var result = value
        ["12306", "中国铁路", "铁路", "高铁", "动车", "火车票", "车票", "车次", "飞机票", "机票", "航班", "订单", "出发", "到达", "登机牌"].forEach {
            result = result.replacingOccurrences(of: $0, with: "", options: .caseInsensitive)
        }
        result = result.replacingOccurrences(of: "（[^）]*）", with: "", options: .regularExpression)
        result = result.replacingOccurrences(of: "\\([^)]*\\)", with: "", options: .regularExpression)
        result = result.replacingOccurrences(of: "[0-9]+(?:\\.[0-9]+)?(?:元|块|km|公里)?", with: "", options: .regularExpression)
        return result.trimmingCharacters(in: .whitespacesAndNewlines.union(.punctuationCharacters))
    }

    private static func airport(for segment: String, fullText: String) -> AirportInfo? {
        if let code = fullText.uppercased().split(whereSeparator: { !$0.isASCII || !$0.isLetter }).first(where: { $0.count == 3 }),
           let found = airports.first(where: { $0.code == String(code) }) { return found }
        if let found = airports.sorted(by: { $0.name.count > $1.name.count }).first(where: { airport in
            segment.localizedCaseInsensitiveContains(airport.name) || segment.localizedCaseInsensitiveContains(airport.short) || segment.localizedCaseInsensitiveContains(airport.code)
        }) { return found }
        guard isFlight(fullText) else { return nil }
        return airports.first(where: { segment.contains($0.city) })
    }

    private static func station(for segment: String, fullText: String) -> String? {
        let cleaned = cleanSegment(segment)
        if let station = cleaned.split(whereSeparator: { $0 == " " || $0 == "," || $0 == "，" }).first(where: { $0.contains("站") }) {
            return station.hasSuffix("站") ? String(station) : "\(station)站"
        }
        guard isTrain(fullText) else { return nil }
        return stations.first(where: { cleaned.contains($0.0) })?.1
    }

    public static func format(_ value: String, category: ExpenseCategory = .transport) -> String {
        let original = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !original.isEmpty, category == .transport || isTrain(original) || isFlight(original) else { return original }
        let suffix = original.range(of: "（[^）]*(人|位|people)[^）]*）", options: .regularExpression).map { String(original[$0]).replacingOccurrences(of: " ", with: "") } ?? ""
        let segments = splitRoute(original)
        if isFlight(original) {
            let airports = segments.compactMap { airport(for: $0, fullText: original) }
            if airports.count >= 2 { return airports.map { "\($0.short)\($0.code)" }.joined(separator: "→") + suffix }
        } else if isTrain(original) {
            let stations = segments.compactMap { station(for: $0, fullText: original) }
            if stations.count >= 2 { return stations.joined(separator: "→") + suffix }
        }
        return original
    }

    public static func inferAirports(entries: [ExpenseEntry]) -> [AirportInfo] {
        var result: [AirportInfo] = []
        var seen = Set<String>()
        for entry in entries {
            guard isFlight(entry.item) else { continue }
            let segments = splitRoute(entry.item)
            let candidates = segments.count >= 2 ? segments.compactMap { airport(for: $0, fullText: entry.item) } : airports.filter { airport in
                entry.item.localizedCaseInsensitiveContains(airport.code) || entry.item.localizedCaseInsensitiveContains(airport.name) || entry.item.localizedCaseInsensitiveContains(airport.short)
            }
            for airport in candidates where seen.insert(airport.code).inserted { result.append(airport) }
        }
        return result
    }
}
