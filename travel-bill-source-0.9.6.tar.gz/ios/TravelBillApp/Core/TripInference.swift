import Foundation

public enum TripInference {
    private struct LocationRule {
        let names: [String]
        let location: String
        let province: String
        let flag: String
        let kind: Kind

        enum Kind { case city, place, province, region, country, home }
    }

    private static let rules: [LocationRule] = [
        LocationRule(names: ["吉隆坡", "kuala lumpur", " kul "], location: "吉隆坡", province: "吉隆坡", flag: "🇲🇾", kind: .city),
        LocationRule(names: ["马来西亚"], location: "马来西亚", province: "吉隆坡", flag: "🇲🇾", kind: .country),
        LocationRule(names: ["新加坡", "singapore"], location: "新加坡", province: "新加坡", flag: "🇸🇬", kind: .country),
        LocationRule(names: ["泰国", "thailand"], location: "泰国", province: "曼谷", flag: "🇹🇭", kind: .country),
        LocationRule(names: ["日本", "japan"], location: "日本", province: "东京", flag: "🇯🇵", kind: .country),
        // 香港、澳门是中国的地区/城市，不作为独立国家统计。
        LocationRule(names: ["香港", "hong kong", " hkg "], location: "香港", province: "香港", flag: "🇨🇳", kind: .region),
        LocationRule(names: ["澳门", "macao", "macau"], location: "澳门", province: "澳门", flag: "🇨🇳", kind: .region),

        LocationRule(names: ["西江千户苗寨", "千户苗寨", "西江苗寨"], location: "西江千户苗寨", province: "贵州", flag: "🇨🇳", kind: .place),
        LocationRule(names: ["梵净山"], location: "梵净山", province: "贵州", flag: "🇨🇳", kind: .place),
        LocationRule(names: ["贵阳"], location: "贵阳", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["凯里"], location: "凯里", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["铜仁"], location: "铜仁", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["安顺"], location: "安顺", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["遵义"], location: "遵义", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["毕节"], location: "毕节", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["六盘水"], location: "六盘水", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["兴义"], location: "兴义", province: "贵州", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["荔波"], location: "荔波", province: "贵州", flag: "🇨🇳", kind: .place),
        LocationRule(names: ["镇远"], location: "镇远", province: "贵州", flag: "🇨🇳", kind: .place),
        LocationRule(names: ["雷山"], location: "雷山", province: "贵州", flag: "🇨🇳", kind: .place),

        LocationRule(names: ["杭州"], location: "杭州", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["宁波"], location: "宁波", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["温州"], location: "温州", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["绍兴"], location: "绍兴", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["嘉兴"], location: "嘉兴", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["湖州"], location: "湖州", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["衢州"], location: "衢州", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["舟山"], location: "舟山", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["台州"], location: "台州", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["丽水"], location: "丽水", province: "浙江", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["金华"], location: "金华", province: "浙江", flag: "🇨🇳", kind: .home),
        LocationRule(names: ["南京"], location: "南京", province: "江苏", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["苏州"], location: "苏州", province: "江苏", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["无锡"], location: "无锡", province: "江苏", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["常州"], location: "常州", province: "江苏", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["镇江"], location: "镇江", province: "江苏", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["扬州"], location: "扬州", province: "江苏", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["上饶"], location: "上饶", province: "江西", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["婺源"], location: "婺源", province: "江西", flag: "🇨🇳", kind: .place),
        LocationRule(names: ["景德镇"], location: "景德镇", province: "江西", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["南昌"], location: "南昌", province: "江西", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["长沙"], location: "长沙", province: "湖南", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["广州"], location: "广州", province: "广东", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["深圳"], location: "深圳", province: "广东", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["上海"], location: "上海", province: "上海", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["北京"], location: "北京", province: "北京", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["重庆"], location: "重庆", province: "重庆", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["成都"], location: "成都", province: "四川", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["武汉"], location: "武汉", province: "湖北", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["西安"], location: "西安", province: "陕西", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["昆明"], location: "昆明", province: "云南", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["厦门"], location: "厦门", province: "福建", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["福州"], location: "福州", province: "福建", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["三亚"], location: "三亚", province: "海南", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["海口"], location: "海口", province: "海南", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["青岛"], location: "青岛", province: "山东", flag: "🇨🇳", kind: .city),
        LocationRule(names: ["大连"], location: "大连", province: "辽宁", flag: "🇨🇳", kind: .city),

        LocationRule(names: ["贵州"], location: "贵州", province: "贵州", flag: "🇨🇳", kind: .province),
        LocationRule(names: ["浙江"], location: "浙江", province: "浙江", flag: "🇨🇳", kind: .province),
        LocationRule(names: ["江苏"], location: "江苏", province: "江苏", flag: "🇨🇳", kind: .province),
        LocationRule(names: ["江西"], location: "江西", province: "江西", flag: "🇨🇳", kind: .province),
        LocationRule(names: ["湖南"], location: "湖南", province: "湖南", flag: "🇨🇳", kind: .province),
        LocationRule(names: ["广东"], location: "广东", province: "广东", flag: "🇨🇳", kind: .province),
        LocationRule(names: ["四川"], location: "四川", province: "四川", flag: "🇨🇳", kind: .province),
        LocationRule(names: ["云南"], location: "云南", province: "云南", flag: "🇨🇳", kind: .province),
    ]

    private struct Match {
        let rule: LocationRule
        var score: Int
        var first: Int
    }

    public static func infer(entries: [ExpenseEntry], fuelRecords: [FuelRecord]) -> TripInfo {
        let dateValues = (entries.map(\.date) + fuelRecords.map(\.date))
            .compactMap { value -> (String, Date)? in DateText.date(from: value).map { (value, $0) } }
            .sorted { $0.1 < $1.1 }
        let startDate = dateValues.first?.0 ?? ""
        let endDate = dateValues.last?.0 ?? startDate
        let dateLabel: String
        if startDate.isEmpty {
            dateLabel = ""
        } else if startDate == endDate {
            dateLabel = DateText.display(startDate)
        } else {
            dateLabel = "\(DateText.display(startDate))—\(DateText.display(endDate))"
        }

        var found: [String: Match] = [:]
        let rows: [(text: String, category: ExpenseCategory)] = entries.map { ("\($0.item)", $0.category) }
            + fuelRecords.map { ("\($0.route) \($0.province)", .transport) }
        for (rowIndex, row) in rows.enumerated() {
            let text = " \(row.text.normalizedExpenseText) "
            for (ruleIndex, rule) in rules.enumerated() {
                guard let name = rule.names.first(where: { text.contains($0.lowercased()) }) else { continue }
                var score = row.category == .transport ? 1 : 3
                if text.range(of: "[→↔—-]", options: .regularExpression) != nil { score += 1 }
                if rule.kind == .home { score -= 8 }
                let key = "\(rule.flag)|\(rule.location)"
                let position = text.distance(from: text.startIndex, to: text.range(of: name.lowercased())?.lowerBound ?? text.startIndex)
                if var current = found[key] {
                    current.score += score
                    current.first = min(current.first, rowIndex * 10_000 + position * 10 + ruleIndex)
                    found[key] = current
                } else {
                    found[key] = Match(rule: rule, score: score, first: rowIndex * 10_000 + position * 10 + ruleIndex)
                }
            }
        }

        var matches = found.values.filter { $0.score >= 2 }
        if matches.contains(where: { $0.rule.kind != .home }) {
            matches.removeAll { $0.rule.kind == .home }
        }
        let locationCandidates = matches
        matches.removeAll { candidate in
            guard candidate.rule.kind == .province || candidate.rule.kind == .country else { return false }
            return locationCandidates.contains { other in
                other.rule.location != candidate.rule.location && other.rule.flag == candidate.rule.flag &&
                    (candidate.rule.kind == .country || other.rule.province == candidate.rule.province)
            }
        }
        matches.sort { $0.first < $1.first }

        return TripInfo(
            startDate: startDate,
            endDate: endDate,
            dateLabel: dateLabel,
            locations: matches.map { $0.rule.location },
            flags: matches.map { $0.rule.flag },
            province: matches.first?.rule.province ?? ""
        )
    }

    public static func filename(for trip: TripInfo) -> String {
        let destination = trip.destinationLabel.isEmpty ? "旅行" : trip.destinationLabel
        let cleaned = destination.replacingOccurrences(of: "[\\/:*?\"<>|]", with: "、", options: .regularExpression)
        guard !trip.startDate.isEmpty else { return "日期未识别\(cleaned).xlsx" }
        let start = DateText.shortFileDate(trip.startDate, includeYear: true)
        let startYear = trip.startDate.prefix(4)
        let endYear = trip.endDate.prefix(4)
        let end = DateText.shortFileDate(trip.endDate, includeYear: startYear != endYear)
        return "\(start)-\(end)\(cleaned).xlsx"
    }
}
