import Foundation
import ZIPFoundation

public enum XLSXExporter {
    public struct Result: Sendable {
        public var data: Data
        public var filename: String
        public var trip: TripInfo

        public init(data: Data, filename: String, trip: TripInfo) {
            self.data = data
            self.filename = filename
            self.trip = trip
        }
    }

    private static let categories = ExpenseCategory.allCases
    private static let chartColors = ["F2BA02", "4874CB", "E54C5E", "30C0B4", "75BD42"]

    public static func makeWorkbook(entries: [ExpenseEntry], fuelRecords: [FuelRecord] = [], participants: [String] = [], personalUserID: String? = nil, personalName: String = "") throws -> Result {
        var rows = entries
        for fuel in fuelRecords where !rows.contains(where: { $0.fuelID == fuel.id }) {
            rows.append(ExpenseEntry(
                date: fuel.date,
                item: "自驾油费\(fuel.route.isEmpty ? "" : "（\(fuel.route)）") · \(fuel.grade)",
                category: .transport,
                amount: fuel.cost,
                source: .fuel,
                reason: "由明确导入的油耗记录计算",
                fuelID: fuel.id
            ))
        }
        rows = rows.enumerated().sorted { left, right in
            let leftDate = DateText.date(from: left.element.date) ?? .distantFuture
            let rightDate = DateText.date(from: right.element.date) ?? .distantFuture
            return leftDate == rightDate ? left.offset < right.offset : leftDate < rightDate
        }.map(\.element)

        let trip = TripInference.infer(entries: rows, fuelRecords: fuelRecords)
        let filename = TripInference.filename(for: trip)
        let airports = TransportDetails.inferAirports(entries: rows)
        let panelEndRow = (airports.isEmpty ? 4 : airports.count + 4) + (fuelRecords.isEmpty ? 0 : 4)
        let chartStartRow = max(12, panelEndRow + 2)
        let hasSplit = !participants.isEmpty && rows.contains { $0.splitMode != .none }
        let totals = Dictionary(grouping: rows, by: \.category).mapValues { $0.reduce(0) { $0 + $1.amount } }
        let total = rows.reduce(0) { $0 + $1.amount }
        let sheet = sheetXML(rows: rows, fuelRecords: fuelRecords, airports: airports, chartStartRow: chartStartRow, trip: trip, filename: filename, totals: totals, total: total)

        let archive = try Archive(accessMode: .create)
        var files: [(String, String)] = [
            ("[Content_Types].xml", contentTypesXML(hasFuel: !fuelRecords.isEmpty, hasSplit: hasSplit, hasPersonal: personalUserID != nil)),
            ("_rels/.rels", rootRelationshipsXML),
            ("docProps/app.xml", appPropertiesXML(hasFuel: !fuelRecords.isEmpty, hasSplit: hasSplit, hasPersonal: personalUserID != nil)),
            ("docProps/core.xml", corePropertiesXML),
            ("xl/workbook.xml", workbookXML(hasFuel: !fuelRecords.isEmpty, hasSplit: hasSplit, hasPersonal: personalUserID != nil)),
            ("xl/_rels/workbook.xml.rels", workbookRelationshipsXML(hasFuel: !fuelRecords.isEmpty, hasSplit: hasSplit, hasPersonal: personalUserID != nil)),
            ("xl/styles.xml", stylesXML()),
            ("xl/theme/theme1.xml", themeXML),
            ("xl/worksheets/sheet1.xml", sheet),
            ("xl/worksheets/_rels/sheet1.xml.rels", sheetRelationshipsXML),
            ("xl/drawings/drawing1.xml", drawingXML(firstRow: chartStartRow - 1)),
            ("xl/drawings/_rels/drawing1.xml.rels", drawingRelationshipsXML),
            ("xl/charts/chart1.xml", barChartXML(totals: totals)),
            ("xl/charts/chart2.xml", pieChartXML(totals: totals)),
        ]
        if !fuelRecords.isEmpty {
            files.append(("xl/worksheets/sheet2.xml", fuelSheetXML(fuelRecords)))
        }
        if hasSplit {
            files.append(("xl/worksheets/sheet3.xml", splitSheetXML(rows, participants: participants)))
        }
        if let personalUserID {
            files.append(("xl/worksheets/sheet4.xml", personalSheetXML(rows, participants: participants, personalUserID: personalUserID, personalName: personalName)))
        }
        for (path, xml) in files {
            let data = Data(xml.utf8)
            try archive.addEntry(
                with: path,
                type: .file,
                uncompressedSize: Int64(data.count),
                compressionMethod: .deflate
            ) { position, size in
                data.subdata(in: Int(position)..<Int(position) + size)
            }
        }
        guard let data = archive.data, data.count > 2_000 else { throw ExportError.incompleteWorkbook }
        return Result(data: data, filename: filename, trip: trip)
    }

    public static func verify(_ data: Data, expectsFuel: Bool, expectsSplit: Bool = false, expectsPersonal: Bool = false) throws {
        guard data.count > 2_000, let archive = try? Archive(data: data, accessMode: .read, pathEncoding: nil) else {
            throw ExportError.incompleteWorkbook
        }
        let required = ["[Content_Types].xml", "xl/workbook.xml", "xl/styles.xml", "xl/worksheets/sheet1.xml", "xl/charts/chart1.xml", "xl/charts/chart2.xml"]
        guard required.allSatisfy({ archive[$0] != nil }) else { throw ExportError.incompleteWorkbook }
        guard (archive["xl/worksheets/sheet2.xml"] != nil) == expectsFuel else { throw ExportError.unexpectedFuelSheet }
        guard (archive["xl/worksheets/sheet3.xml"] != nil) == expectsSplit else { throw ExportError.unexpectedSplitSheet }
        guard (archive["xl/worksheets/sheet4.xml"] != nil) == expectsPersonal else { throw ExportError.unexpectedPersonalSheet }
        for path in required {
            guard let entry = archive[path] else { continue }
            var contents = Data()
            _ = try archive.extract(entry) { contents.append($0) }
            if let text = String(data: contents, encoding: .utf8), text.range(of: "#VALUE!|#REF!|#DIV/0!|#NAME\\?|#N/A", options: .regularExpression) != nil {
                throw ExportError.formulaError
            }
        }
    }

    public enum ExportError: LocalizedError {
        case incompleteWorkbook
        case unexpectedFuelSheet
        case unexpectedSplitSheet
        case unexpectedPersonalSheet
        case formulaError

        public var errorDescription: String? {
            switch self {
            case .incompleteWorkbook: "Excel 文件结构不完整"
            case .unexpectedFuelSheet: "油耗工作表与导入内容不一致"
            case .unexpectedSplitSheet: "分账工作表与同行人设置不一致"
            case .unexpectedPersonalSheet: "个人账单工作表与账号设置不一致"
            case .formulaError: "Excel 中发现公式错误"
            }
        }
    }

    private static func sheetXML(
        rows: [ExpenseEntry],
        fuelRecords: [FuelRecord],
        airports: [AirportInfo],
        chartStartRow: Int,
        trip: TripInfo,
        filename: String,
        totals: [ExpenseCategory: Double],
        total: Double
    ) -> String {
        let totalRow = max(3, rows.count + 2)
        let displayRows = max(46, chartStartRow + 27, totalRow)
        var rowXML: [String] = []
        var previousDate = ""
        for row in 1...displayRows {
            var cells: [String] = []
            if row == 1 {
                cells += [textCell("A1", "日期", 1), textCell("B1", "序号", 1), textCell("C1", "项目", 1), textCell("D1", "金额", 2)]
                cells += [textCell("F1", trip.title.isEmpty ? "自动识别行程" : trip.title, 25)]
            } else if row <= rows.count + 1 {
                let entry = rows[row - 2]
                let shownDate = entry.date == previousDate ? "" : DateText.display(entry.date)
                if !entry.date.isEmpty { previousDate = entry.date }
                let base = 3 + categoryIndex(entry.category) * 4
                cells += [
                    textCell("A\(row)", shownDate, base),
                    numberCell("B\(row)", Double(row - 1), base + 1),
                    textCell("C\(row)", TransportDetails.format(entry.item, category: entry.category).isEmpty ? "未命名项目" : TransportDetails.format(entry.item, category: entry.category), base + 2),
                    numberCell("D\(row)", entry.amount, base + 3),
                    textCell("L\(row)", entry.category.rawValue, 0),
                ]
            } else if row == totalRow {
                cells += [blankCell("A\(row)", 23), blankCell("B\(row)", 23), textCell("C\(row)", "总计", 23), formulaCell("D\(row)", "SUM(D2:D\(max(2, rows.count + 1)))", total, 24)]
            } else if row <= 46 {
                let category = categories[(row - 2) % categories.count]
                let base = 3 + categoryIndex(category) * 4
                cells += [blankCell("A\(row)", base), blankCell("B\(row)", base + 1), blankCell("C\(row)", base + 2), blankCell("D\(row)", base + 3)]
            }

            if row == 3 { cells.append(textCell("F3", filename, 26)) }
            if row == 4 {
                cells.append(textCell("F4", "账单总计", 26))
                cells.append(formulaCell("H4", "D\(totalRow)", total, 28))
            }
            if row <= categories.count {
                let category = categories[row - 1]
                let value = totals[category, default: 0]
                cells.append(textCell("I\(row)", category.rawValue, 29 + categoryIndex(category)))
                cells.append(formulaCell("J\(row)", "SUMIF($L$2:$L$\(max(2, rows.count + 1)),I\(row),$D$2:$D$\(max(2, rows.count + 1)))", value, 36))
                cells.append(textCell("K\(row)", "CNY", 27))
            }
            if row >= 5, row <= airports.count + 4 {
                let airport = airports[row - 5]
                cells.append(textCell("F\(row)", airport.name, 26))
                cells.append(textCell("H\(row)", airport.code, 26))
            }
            if !fuelRecords.isEmpty { cells += fuelSummaryCells(row: row, startRow: airports.count + 5, fuelRecords: fuelRecords) }
            if !cells.isEmpty { rowXML.append("<row r=\"\(row)\" ht=\"17.6\" customHeight=\"1\">\(cells.joined())</row>") }
        }

        let airportMerges = airports.enumerated().map { "<mergeCell ref=\"F\($0.offset + 5):G\($0.offset + 5)\"/>" }.joined()
        let durationMerge = fuelRecords.isEmpty ? "" : "<mergeCell ref=\"G\(airports.count + 7):H\(airports.count + 7)\"/>"
        let mergeCount = 4 + airports.count + (fuelRecords.isEmpty ? 0 : 1)
        return xmlHeader + """
        <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
          <sheetViews><sheetView tabSelected="1" workbookViewId="0"/></sheetViews>
          <sheetFormatPr defaultRowHeight="17.6"/>
          <cols>
            <col min="1" max="1" width="9.142857" customWidth="1"/><col min="2" max="2" width="9.142857" customWidth="1"/>
            <col min="3" max="3" width="67.553571" customWidth="1"/><col min="4" max="4" width="12.5" customWidth="1"/>
            <col min="5" max="5" width="3.2" customWidth="1"/><col min="6" max="7" width="17" customWidth="1"/>
            <col min="8" max="8" width="12" customWidth="1"/><col min="9" max="9" width="9" customWidth="1"/>
            <col min="10" max="10" width="13" customWidth="1"/><col min="11" max="11" width="8" customWidth="1"/>
            <col min="12" max="12" width="9" hidden="1" customWidth="1"/>
          </cols>
          <sheetData>\(rowXML.joined())</sheetData>
          <mergeCells count="\(mergeCount)"><mergeCell ref="F1:H1"/><mergeCell ref="F3:H3"/><mergeCell ref="F4:G4"/>\(airportMerges)\(durationMerge)<mergeCell ref="F\(chartStartRow):K\(chartStartRow + 27)"/></mergeCells>
          <pageMargins left="0.75" right="0.75" top="1" bottom="1" header="0.5" footer="0.5"/>
          <drawing r:id="rId1"/>
        </worksheet>
        """
    }

    private static func fuelSummaryCells(row: Int, startRow: Int, fuelRecords: [FuelRecord]) -> [String] {
        let distance = fuelRecords.reduce(0) { $0 + $1.distance }
        let liters = fuelRecords.reduce(0) { $0 + $1.liters }
        let average = distance > 0 ? liters / distance * 100 : 0
        let price = fuelRecords.first?.price ?? 0
        switch row {
        case startRow: return [textCell("F\(startRow)", "路程：", 34), numberCell("G\(startRow)", distance, 35), textCell("H\(startRow)", "km", 34)]
        case startRow + 1: return [textCell("F\(row)", "油耗：", 34), numberCell("G\(row)", average, 35), textCell("H\(row)", "l/100km", 34)]
        case startRow + 2: return [textCell("F\(row)", "时间：", 34), textCell("G\(row)", fuelRecords.compactMap(\.duration).filter { !$0.isEmpty }.joined(separator: "、"), 34)]
        case startRow + 3: return [textCell("F\(row)", "油价：", 34), numberCell("G\(row)", price, 35), textCell("H\(row)", "元/升", 34)]
        default: return []
        }
    }

    private static func fuelSheetXML(_ records: [FuelRecord]) -> String {
        let headers = ["日期", "行程/车辆", "里程(km)", "百公里油耗(L)", "省份", "油号", "当日油价(元/L)", "油价日期", "预计耗油(L)", "油费(元)"]
        var rows = ["<row r=\"1\">\(headers.enumerated().map { textCell(column($0.offset + 1) + "1", $0.element, 1) }.joined())</row>"]
        for (index, record) in records.enumerated() {
            let row = index + 2
            let cells = [
                textCell("A\(row)", DateText.display(record.date), 27), textCell("B\(row)", record.route, 27),
                numberCell("C\(row)", record.distance, 28), numberCell("D\(row)", record.consumption, 28),
                textCell("E\(row)", record.province, 27), textCell("F\(row)", record.grade, 27),
                numberCell("G\(row)", record.price, 28), textCell("H\(row)", DateText.display(record.priceDate), 27),
                formulaCell("I\(row)", "C\(row)*D\(row)/100", record.liters, 28),
                formulaCell("J\(row)", "I\(row)*G\(row)", record.cost, 28),
            ]
            rows.append("<row r=\"\(row)\">\(cells.joined())</row>")
        }
        return xmlHeader + """
        <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
          <sheetFormatPr defaultRowHeight="17.6"/>
          <cols><col min="1" max="1" width="12" customWidth="1"/><col min="2" max="2" width="26" customWidth="1"/><col min="3" max="4" width="16" customWidth="1"/><col min="5" max="6" width="12" customWidth="1"/><col min="7" max="10" width="16" customWidth="1"/></cols>
          <sheetData>\(rows.joined())</sheetData><pageMargins left="0.75" right="0.75" top="1" bottom="1" header="0.5" footer="0.5"/>
        </worksheet>
        """
    }

    private static func splitSheetXML(_ entries: [ExpenseEntry], participants: [String]) -> String {
        let headers = ["日期", "项目", "总金额", "分账方式", "参与人", "分摊金额"]
        var rows = ["<row r=\"1\">\(headers.enumerated().map { textCell(column($0.offset + 1) + "1", $0.element, 1) }.joined())</row>"]
        var row = 2
        for entry in entries {
            let lines = SplitDetails.lines(for: entry, participants: participants)
            let shownLines = lines.isEmpty ? [(name: "—", amount: entry.amount)] : lines
            for line in shownLines {
                let cells = [
                    textCell("A\(row)", DateText.display(entry.date), 27),
                    textCell("B\(row)", TransportDetails.format(entry.item, category: entry.category), 27),
                    numberCell("C\(row)", entry.amount, 28),
                    textCell("D\(row)", entry.splitMode.title, 27),
                    textCell("E\(row)", line.name, 27),
                    numberCell("F\(row)", line.amount, 28),
                ]
                rows.append("<row r=\"\(row)\">\(cells.joined())</row>")
                row += 1
            }
        }
        return xmlHeader + """
        <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
          <sheetFormatPr defaultRowHeight="17.6"/>
          <cols><col min="1" max="1" width="12" customWidth="1"/><col min="2" max="2" width="42" customWidth="1"/><col min="3" max="3" width="14" customWidth="1"/><col min="4" max="5" width="18" customWidth="1"/><col min="6" max="6" width="14" customWidth="1"/></cols>
          <sheetData>\(rows.joined())</sheetData><pageMargins left="0.75" right="0.75" top="1" bottom="1" header="0.5" footer="0.5"/>
        </worksheet>
        """
    }

    private static func personalShare(_ entry: ExpenseEntry, personalUserID: String, personalName: String, participants: [String]) -> Double {
        let amount = entry.amount
        let isGroupExpense = entry.groupID != nil || entry.visibility == .group
        if !isGroupExpense || entry.visibility == .private { return amount }
        switch entry.splitMode {
        case .custom:
            if let cents = entry.splitAmountCents[personalUserID] { return Double(cents) / 100 }
            return entry.splitAmounts[personalName] ?? 0
        case .all, .selected:
            let count = entry.splitParticipantIDs.isEmpty ? (entry.splitParticipants.isEmpty ? participants.count : entry.splitParticipants.count) : entry.splitParticipantIDs.count
            let included = entry.splitParticipantIDs.isEmpty ? (entry.splitParticipants.isEmpty ? participants.contains(personalName) : entry.splitParticipants.contains(personalName)) : entry.splitParticipantIDs.contains(personalUserID)
            return included && count > 0 ? amount / Double(count) : 0
        case .none:
            return entry.payerUserID == personalUserID || entry.payerUserID == personalName ? amount : 0
        }
    }

    private static func personalSheetXML(_ entries: [ExpenseEntry], participants: [String], personalUserID: String, personalName: String) -> String {
        let rows = entries.compactMap { entry -> (ExpenseEntry, Double)? in
            let share = personalShare(entry, personalUserID: personalUserID, personalName: personalName, participants: participants)
            return share > 0.004 ? (entry, share) : nil
        }
        let headers = ["日期", "项目", "分类", "账单总额", "我的承担", "账单类型"]
        let headerCells = headers.enumerated().map { index, value in textCell(column(index + 1) + "1", value, 1) }.joined()
        var output = ["<row r=\"1\">\(headerCells)</row>"]
        for (index, pair) in rows.enumerated() {
            let row = index + 2
            let entry = pair.0
            let share = pair.1
            let type = entry.visibility == .private ? "私人账单" : "公共分摊"
            let cells = [
                textCell("A\(row)", DateText.display(entry.date), 27),
                textCell("B\(row)", TransportDetails.format(entry.item, category: entry.category), 27),
                textCell("C\(row)", entry.category.rawValue, 27),
                numberCell("D\(row)", entry.amount, 28),
                numberCell("E\(row)", share, 28),
                textCell("F\(row)", type, 27),
            ].joined()
            output.append("<row r=\"\(row)\">\(cells)</row>")
        }
        let totalRow = max(2, rows.count + 2)
        let total = rows.reduce(0) { $0 + $1.1 }
        let totalCells = textCell("D\(totalRow)", "个人合计", 23) + formulaCell("E\(totalRow)", "SUM(E2:E\(max(2, rows.count + 1)))", total, 24)
        output.append("<row r=\"\(totalRow)\">\(totalCells)</row>")
        return xmlHeader + """
        <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
          <sheetFormatPr defaultRowHeight="17.6"/>
          <cols><col min="1" max="1" width="12" customWidth="1"/><col min="2" max="2" width="42" customWidth="1"/><col min="3" max="3" width="12" customWidth="1"/><col min="4" max="5" width="14" customWidth="1"/><col min="6" max="6" width="14" customWidth="1"/></cols>
          <sheetData>\(output.joined())</sheetData><pageMargins left="0.75" right="0.75" top="1" bottom="1" header="0.5" footer="0.5"/>
        </worksheet>
        """
    }

    private static func categoryIndex(_ category: ExpenseCategory) -> Int { categories.firstIndex(of: category) ?? 3 }
    private static func column(_ value: Int) -> String { String(UnicodeScalar(64 + value)!) }
    private static func number(_ value: Double) -> String { value.isFinite ? String(format: "%.10g", value) : "0" }
    private static func textCell(_ ref: String, _ value: String, _ style: Int) -> String { "<c r=\"\(ref)\" s=\"\(style)\" t=\"inlineStr\"><is><t xml:space=\"preserve\">\(value.xmlEscaped)</t></is></c>" }
    private static func numberCell(_ ref: String, _ value: Double, _ style: Int) -> String { "<c r=\"\(ref)\" s=\"\(style)\"><v>\(number(value))</v></c>" }
    private static func formulaCell(_ ref: String, _ formula: String, _ cached: Double, _ style: Int) -> String { "<c r=\"\(ref)\" s=\"\(style)\"><f>\(formula.xmlEscaped)</f><v>\(number(cached))</v></c>" }
    private static func blankCell(_ ref: String, _ style: Int) -> String { "<c r=\"\(ref)\" s=\"\(style)\"/>" }

    private static let xmlHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"

    private static func contentTypesXML(hasFuel: Bool, hasSplit: Bool, hasPersonal: Bool) -> String {
        xmlHeader + """
        <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
          <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>
          <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
          <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
          \(hasFuel ? "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" : "")
          \(hasSplit ? "<Override PartName=\"/xl/worksheets/sheet3.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" : "")
          \(hasPersonal ? "<Override PartName=\"/xl/worksheets/sheet4.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" : "")
          <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
          <Override PartName="/xl/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
          <Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>
          <Override PartName="/xl/charts/chart1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>
          <Override PartName="/xl/charts/chart2.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>
          <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
          <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
        </Types>
        """
    }

    private static let rootRelationshipsXML = xmlHeader + """
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
      <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
    </Relationships>
    """

    private static func workbookXML(hasFuel: Bool, hasSplit: Bool, hasPersonal: Bool) -> String {
        xmlHeader + """
        <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
          <bookViews><workbookView xWindow="0" yWindow="0" windowWidth="24000" windowHeight="15000"/></bookViews>
          <sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/>\(hasFuel ? "<sheet name=\"油耗明细\" sheetId=\"2\" r:id=\"rId4\"/>" : "")\(hasSplit ? "<sheet name=\"分账明细\" sheetId=\"3\" r:id=\"rId5\"/>" : "")\(hasPersonal ? "<sheet name=\"个人账单\" sheetId=\"4\" r:id=\"rId6\"/>" : "")</sheets>
          <calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/>
        </workbook>
        """
    }

    private static func workbookRelationshipsXML(hasFuel: Bool, hasSplit: Bool, hasPersonal: Bool) -> String {
        xmlHeader + """
        <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
          <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
          <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
          <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>
          \(hasFuel ? "<Relationship Id=\"rId4\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/>" : "")
          \(hasSplit ? "<Relationship Id=\"rId5\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet3.xml\"/>" : "")
          \(hasPersonal ? "<Relationship Id=\"rId6\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet4.xml\"/>" : "")
        </Relationships>
        """
    }

    private static func stylesXML() -> String {
        let fills = ["FCF1CC", "DAE3F5", "FADBDF", "D6F2F0", "E3F2D9"]
        let fillXML = fills.map { "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF\($0)\"/><bgColor indexed=\"64\"/></patternFill></fill>" }.joined()
        var xfs = [
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>",
            "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>",
            "<xf numFmtId=\"4\" fontId=\"3\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>",
        ]
        for fill in 2...6 {
            xfs += [
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"\(fill)\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>",
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"\(fill)\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\"/></xf>",
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"\(fill)\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"left\" vertical=\"center\"/></xf>",
                "<xf numFmtId=\"4\" fontId=\"1\" fillId=\"\(fill)\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\" vertical=\"center\"/></xf>",
            ]
        }
        xfs += [
            "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"7\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>",
            "<xf numFmtId=\"4\" fontId=\"3\" fillId=\"7\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\"/></xf>",
            "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>",
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>",
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>",
            "<xf numFmtId=\"4\" fontId=\"1\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\"/></xf>",
        ]
        for fill in 2...6 { xfs.append("<xf numFmtId=\"0\" fontId=\"4\" fillId=\"\(fill)\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>") }
        xfs += [
            "<xf numFmtId=\"0\" fontId=\"3\" fillId=\"8\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>",
            "<xf numFmtId=\"4\" fontId=\"1\" fillId=\"8\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\"/></xf>",
            "<xf numFmtId=\"4\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"right\"/></xf>",
        ]
        return xmlHeader + """
        <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
          <numFmts count="0"/><fonts count="5">
            <font><sz val="11"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font>
            <font><sz val="12"/><name val="新細明體"/></font>
            <font><b/><sz val="11"/><name val="新細明體"/></font>
            <font><b/><sz val="12"/><name val="新細明體"/></font>
            <font><color rgb="FFFFFFFF"/><sz val="12"/><name val="新細明體"/></font>
          </fonts>
          <fills count="9"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>\(fillXML)<fill><patternFill patternType="solid"><fgColor rgb="FFFFFF00"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF4C20D"/><bgColor indexed="64"/></patternFill></fill></fills>
          <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
          <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
          <cellXfs count="\(xfs.count)">\(xfs.joined())</cellXfs>
          <cellStyles count="1"><cellStyle name="常规" xfId="0" builtinId="0"/></cellStyles><dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>
        </styleSheet>
        """
    }

    private static let sheetRelationshipsXML = xmlHeader + """
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>
    """
    private static let drawingRelationshipsXML = xmlHeader + """
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart2.xml"/></Relationships>
    """
    private static func drawingXML(firstRow: Int) -> String {
        let secondRow = firstRow + 13
        return xmlHeader + """
        <xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
          <xdr:twoCellAnchor><xdr:from><xdr:col>5</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>\(firstRow)</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>12</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>\(firstRow + 14)</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="2" name="分类金额"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" r:id="rId1"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>
          <xdr:twoCellAnchor><xdr:from><xdr:col>5</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>\(secondRow)</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>12</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>\(secondRow + 17)</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="3" name="费用占比"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" r:id="rId2"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>
        </xdr:wsDr>
        """
    }

    private static func barChartXML(totals: [ExpenseCategory: Double]) -> String {
        let series = categories.enumerated().map { index, category in
            let value = totals[category, default: 0]
            return """
            <c:ser><c:idx val="\(index)"/><c:order val="\(index)"/><c:tx><c:strRef><c:f>Sheet1!$I$\(index + 1)</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>\(category.rawValue.xmlEscaped)</c:v></c:pt></c:strCache></c:strRef></c:tx><c:spPr><a:solidFill><a:srgbClr val="\(chartColors[index])"/></a:solidFill></c:spPr><c:cat><c:strRef><c:f>Sheet1!$I$\(index + 1)</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>\(category.rawValue.xmlEscaped)</c:v></c:pt></c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$J$\(index + 1)</c:f><c:numCache><c:formatCode>0.00</c:formatCode><c:ptCount val="1"/><c:pt idx="0"><c:v>\(number(value))</c:v></c:pt></c:numCache></c:numRef></c:val></c:ser>
            """
        }.joined()
        return xmlHeader + """
        <c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><c:chart><c:autoTitleDeleted val="1"/><c:plotArea><c:layout/><c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>\(series)<c:dLbls><c:showVal val="1"/><c:showLegendKey val="0"/><c:showCatName val="0"/></c:dLbls><c:axId val="18760001"/><c:axId val="18760002"/></c:barChart><c:catAx><c:axId val="18760001"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="18760002"/><c:crosses val="autoZero"/></c:catAx><c:valAx><c:axId val="18760002"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="1"/><c:axPos val="l"/><c:crossAx val="18760001"/><c:crosses val="autoZero"/></c:valAx></c:plotArea><c:plotVisOnly val="1"/></c:chart></c:chartSpace>
        """
    }

    private static func pieChartXML(totals: [ExpenseCategory: Double]) -> String {
        let stringPoints = categories.enumerated().map { "<c:pt idx=\"\($0.offset)\"><c:v>\($0.element.rawValue.xmlEscaped)</c:v></c:pt>" }.joined()
        let numberPoints = categories.enumerated().map { "<c:pt idx=\"\($0.offset)\"><c:v>\(number(totals[$0.element, default: 0]))</c:v></c:pt>" }.joined()
        let dataPoints = categories.enumerated().map { "<c:dPt><c:idx val=\"\($0.offset)\"/><c:spPr><a:solidFill><a:srgbClr val=\"\(chartColors[$0.offset])\"/></a:solidFill></c:spPr></c:dPt>" }.joined()
        return xmlHeader + """
        <c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><c:chart><c:autoTitleDeleted val="1"/><c:plotArea><c:layout/><c:pieChart><c:varyColors val="1"/><c:ser><c:idx val="0"/><c:order val="0"/>\(dataPoints)<c:cat><c:strRef><c:f>Sheet1!$I$1:$I$5</c:f><c:strCache><c:ptCount val="5"/>\(stringPoints)</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>Sheet1!$J$1:$J$5</c:f><c:numCache><c:formatCode>0.00</c:formatCode><c:ptCount val="5"/>\(numberPoints)</c:numCache></c:numRef></c:val></c:ser><c:dLbls><c:showLegendKey val="0"/><c:showVal val="0"/><c:showCatName val="1"/><c:showPercent val="1"/><c:showLeaderLines val="1"/></c:dLbls></c:pieChart></c:plotArea><c:plotVisOnly val="1"/></c:chart></c:chartSpace>
        """
    }

    private static func appPropertiesXML(hasFuel: Bool, hasSplit: Bool, hasPersonal: Bool) -> String {
        let sheetCount = 1 + (hasFuel ? 1 : 0) + (hasSplit ? 1 : 0) + (hasPersonal ? 1 : 0)
        let splitTitle = hasSplit ? "<vt:lpstr>分账明细</vt:lpstr>" : ""
        let fuelTitle = hasFuel ? "<vt:lpstr>油耗明细</vt:lpstr>" : ""
        let personalTitle = hasPersonal ? "<vt:lpstr>个人账单</vt:lpstr>" : ""
        return xmlHeader + """
        <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>旅迹账单</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>工作表</vt:lpstr></vt:variant><vt:variant><vt:i4>\(sheetCount)</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size="\(sheetCount)" baseType="lpstr"><vt:lpstr>Sheet1</vt:lpstr>\(fuelTitle)\(splitTitle)\(personalTitle)</vt:vector></TitlesOfParts><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>1.0</AppVersion></Properties>
        """
    }

    private static let corePropertiesXML = xmlHeader + """
    <cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:creator>旅迹账单</dc:creator><cp:lastModifiedBy>旅迹账单</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">2026-08-17T00:00:00Z</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">2026-08-17T00:00:00Z</dcterms:modified></cp:coreProperties>
    """

    private static let themeXML = xmlHeader + """
    <a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="旅迹账单"><a:themeElements><a:clrScheme name="旅迹"><a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1><a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="3B5264"/></a:dk2><a:lt2><a:srgbClr val="C1F2FB"/></a:lt2><a:accent1><a:srgbClr val="4874CB"/></a:accent1><a:accent2><a:srgbClr val="E54C5E"/></a:accent2><a:accent3><a:srgbClr val="75BD42"/></a:accent3><a:accent4><a:srgbClr val="30C0B4"/></a:accent4><a:accent5><a:srgbClr val="F2BA02"/></a:accent5><a:accent6><a:srgbClr val="68AEBA"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="旅迹"><a:majorFont><a:latin typeface="Calibri"/><a:ea typeface="新細明體"/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface="新細明體"/><a:cs typeface=""/></a:minorFont></a:fontScheme><a:fmtScheme name="旅迹"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>
    """
}
