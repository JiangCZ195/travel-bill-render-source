import Foundation
import ZIPFoundation

public enum FuelTableImporter {
    public static func read(data: Data, filename: String) throws -> [FuelRecord] {
        let rows: [[String]]
        if filename.lowercased().hasSuffix(".csv") {
            guard let text = String(data: data, encoding: .utf8) else {
                throw ImportError.unreadable
            }
            rows = parseCSV(text.replacingOccurrences(of: "\u{FEFF}", with: ""))
        } else {
            rows = try parseXLSX(data)
        }
        return try normalize(rows)
    }

    public enum ImportError: LocalizedError {
        case unreadable
        case missingColumns
        case noRecords

        public var errorDescription: String? {
            switch self {
            case .unreadable: "无法读取这个油耗表"
            case .missingColumns: "油耗表至少需要“里程”和“百公里油耗”两列"
            case .noRecords: "油耗表中没有可用记录"
            }
        }
    }

    private static func normalize(_ rows: [[String]]) throws -> [FuelRecord] {
        guard let header = rows.first else { throw ImportError.noRecords }
        let headers = header.map { $0.normalizedExpenseText }
        func index(_ names: [String]) -> Int? {
            headers.firstIndex(where: { value in names.contains(where: value.contains) })
        }
        let dateIndex = index(["日期", "时间"])
        let routeIndex = index(["行程", "路段", "车辆", "项目"])
        guard let distanceIndex = index(["里程", "路程", "km"]),
              let consumptionIndex = index(["百公里油耗", "油耗", "l/100"]) else { throw ImportError.missingColumns }
        let provinceIndex = index(["省份", "地区"])
        let gradeIndex = index(["油号", "标号"])
        let priceIndex = index(["油价", "单价"])
        let priceDateIndex = index(["油价日期"])
        let durationIndex = index(["时长", "用时", "耗时"])

        let result = rows.dropFirst().compactMap { row -> FuelRecord? in
            func value(_ column: Int?) -> String {
                guard let column, row.indices.contains(column) else { return "" }
                return row[column].trimmingCharacters(in: .whitespacesAndNewlines)
            }
            guard let distance = decimal(value(distanceIndex)), let consumption = decimal(value(consumptionIndex)),
                  distance > 0, distance <= 100_000, consumption > 0, consumption <= 80 else { return nil }
            let gradeValue = value(gradeIndex)
            let grade = gradeValue.range(of: "92") != nil ? "92#" : gradeValue.range(of: "98") != nil ? "98#" : "95#"
            return FuelRecord(
                date: normalizedDate(value(dateIndex)),
                route: value(routeIndex).isEmpty ? "自驾行程" : value(routeIndex),
                distance: distance,
                consumption: consumption,
                province: value(provinceIndex).replacingOccurrences(of: "[省市]$", with: "", options: .regularExpression),
                grade: grade,
                price: decimal(value(priceIndex)) ?? 0,
                priceDate: normalizedDate(value(priceDateIndex)),
                duration: value(durationIndex)
            )
        }
        guard !result.isEmpty else { throw ImportError.noRecords }
        return result
    }

    private static func decimal(_ value: String) -> Double? {
        let cleaned = value.replacingOccurrences(of: ",", with: "").replacingOccurrences(of: "[^0-9.]", with: "", options: .regularExpression)
        return Double(cleaned)
    }

    private static func normalizedDate(_ value: String) -> String {
        if let date = DateText.date(from: value) { return DateText.isoDate(date) }
        if let serial = Double(value), serial > 1 {
            let origin = Calendar(identifier: .gregorian).date(from: DateComponents(year: 1899, month: 12, day: 30))!
            if let date = Calendar(identifier: .gregorian).date(byAdding: .day, value: Int(serial), to: origin) { return DateText.isoDate(date) }
        }
        return ""
    }

    private static func parseCSV(_ text: String) -> [[String]] {
        var rows: [[String]] = []
        var row: [String] = []
        var field = ""
        var quoted = false
        var index = text.startIndex
        while index < text.endIndex {
            let character = text[index]
            if character == "\"" {
                let next = text.index(after: index)
                if quoted, next < text.endIndex, text[next] == "\"" {
                    field.append("\"")
                    index = next
                } else { quoted.toggle() }
            } else if character == ",", !quoted {
                row.append(field); field = ""
            } else if (character == "\n" || character == "\r"), !quoted {
                if character == "\r" {
                    let next = text.index(after: index)
                    if next < text.endIndex, text[next] == "\n" { index = next }
                }
                row.append(field); field = ""
                if row.contains(where: { !$0.isEmpty }) { rows.append(row) }
                row = []
            } else { field.append(character) }
            index = text.index(after: index)
        }
        row.append(field)
        if row.contains(where: { !$0.isEmpty }) { rows.append(row) }
        return rows
    }

    private static func parseXLSX(_ data: Data) throws -> [[String]] {
        let archive = try Archive(data: data, accessMode: .read, pathEncoding: nil)
        let shared = try readEntry("xl/sharedStrings.xml", archive: archive).map(parseSharedStrings) ?? []
        guard let sheetData = try readEntry("xl/worksheets/sheet1.xml", archive: archive) else { throw ImportError.unreadable }
        let parser = XMLParser(data: sheetData)
        let delegate = SheetParser(sharedStrings: shared)
        parser.delegate = delegate
        guard parser.parse() else { throw parser.parserError ?? ImportError.unreadable }
        return delegate.rows
    }

    private static func readEntry(_ path: String, archive: Archive) throws -> Data? {
        guard let entry = archive[path] else { return nil }
        var result = Data()
        _ = try archive.extract(entry) { result.append($0) }
        return result
    }

    private static func parseSharedStrings(_ data: Data) -> [String] {
        let parser = XMLParser(data: data)
        let delegate = SharedStringsParser()
        parser.delegate = delegate
        _ = parser.parse()
        return delegate.values
    }
}

private final class SharedStringsParser: NSObject, XMLParserDelegate {
    var values: [String] = []
    private var text = ""
    private var inItem = false

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
        if elementName == "si" { inItem = true; text = "" }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) { if inItem { text += string } }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "si" { values.append(text); inItem = false }
    }
}

private final class SheetParser: NSObject, XMLParserDelegate {
    let sharedStrings: [String]
    var rows: [[String]] = []
    private var currentRow = 0
    private var currentColumn = 0
    private var currentType = ""
    private var currentValue = ""
    private var capturing = false

    init(sharedStrings: [String]) { self.sharedStrings = sharedStrings }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
        if elementName == "row" { currentRow = max(0, (Int(attributeDict["r"] ?? "1") ?? 1) - 1) }
        if elementName == "c" {
            currentColumn = Self.columnIndex(attributeDict["r"] ?? "A1")
            currentType = attributeDict["t"] ?? ""
            currentValue = ""
        }
        if elementName == "v" || elementName == "t" { capturing = true }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) { if capturing { currentValue += string } }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "v" || elementName == "t" { capturing = false }
        if elementName == "c" {
            while rows.count <= currentRow { rows.append([]) }
            while rows[currentRow].count <= currentColumn { rows[currentRow].append("") }
            if currentType == "s", let index = Int(currentValue), sharedStrings.indices.contains(index) {
                rows[currentRow][currentColumn] = sharedStrings[index]
            } else { rows[currentRow][currentColumn] = currentValue }
        }
    }

    private static func columnIndex(_ reference: String) -> Int {
        reference.prefix(while: \.isLetter).reduce(0) { $0 * 26 + Int($1.asciiValue ?? 65) - 64 } - 1
    }
}
