import Foundation

public struct RecognizedTextLine: Equatable, Sendable {
    public var text: String
    public var confidence: Float
    public var x: Double
    public var y: Double
    public var width: Double
    public var height: Double

    public init(text: String, confidence: Float, x: Double, y: Double, width: Double, height: Double) {
        self.text = text
        self.confidence = confidence
        self.x = x
        self.y = y
        self.width = width
        self.height = height
    }
}

public struct OCRExpenseCandidate: Equatable, Sendable {
    public var date: String
    public var item: String
    public var amount: Double?
    public var category: ExpenseCategory
    public var reason: String
    public var transactionTime: String
    public var reviewFields: [String]

    public init(
        date: String,
        item: String,
        amount: Double?,
        category: ExpenseCategory,
        reason: String,
        transactionTime: String = "",
        reviewFields: [String] = []
    ) {
        self.date = date
        self.item = item
        self.amount = amount
        self.category = category
        self.reason = reason
        self.transactionTime = transactionTime
        self.reviewFields = reviewFields
    }
}

public struct OCRFuelCandidate: Equatable, Sendable {
    public var date: String
    public var route: String
    public var distance: Double
    public var consumption: Double

    public init(date: String, route: String, distance: Double, consumption: Double) {
        self.date = date
        self.route = route
        self.distance = distance
        self.consumption = consumption
    }
}

public enum OCRDocument: Equatable, Sendable {
    case expenses([OCRExpenseCandidate])
    case fuel(OCRFuelCandidate)
    case empty
}

public enum OCRParser {
    public static func parse(
        observations: [RecognizedTextLine],
        learned: [String: ExpenseCategory] = [:],
        referenceDate: String = DateText.isoDate()
    ) -> OCRDocument {
        let lines = groupedRows(observations)
        return parse(lines: lines, learned: learned, referenceDate: referenceDate)
    }

    public static func parse(
        lines: [String],
        learned: [String: ExpenseCategory] = [:],
        referenceDate: String = DateText.isoDate()
    ) -> OCRDocument {
        let cleaned = lines.map(cleanLine).filter { !$0.isEmpty }
        guard !cleaned.isEmpty else { return .empty }
        if let fuel = parseFuel(cleaned, referenceDate: referenceDate) { return .fuel(fuel) }

        var entries = parseSinglePayment(cleaned, learned: learned, referenceDate: referenceDate)
        if entries.isEmpty {
            entries = parseTransactionList(cleaned, learned: learned, referenceDate: referenceDate)
        }
        entries.append(contentsOf: parseTravelNotes(cleaned, learned: learned))
        entries = fillCertainMissingDates(deduplicate(entries))
        return entries.isEmpty ? .empty : .expenses(entries)
    }

    public static func groupedRows(_ observations: [RecognizedTextLine]) -> [String] {
        struct Row {
            var centerY: Double
            var height: Double
            var items: [RecognizedTextLine]
        }
        let sorted = observations
            .filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sorted {
                let leftY = $0.y + $0.height / 2
                let rightY = $1.y + $1.height / 2
                if abs(leftY - rightY) > max($0.height, $1.height) * 0.5 { return leftY > rightY }
                return $0.x < $1.x
            }
        var rows: [Row] = []
        for observation in sorted {
            let centerY = observation.y + observation.height / 2
            if let index = rows.indices.min(by: { abs(rows[$0].centerY - centerY) < abs(rows[$1].centerY - centerY) }),
               abs(rows[index].centerY - centerY) <= max(rows[index].height, observation.height) * 0.68 {
                rows[index].items.append(observation)
                rows[index].centerY = rows[index].items.map { $0.y + $0.height / 2 }.reduce(0, +) / Double(rows[index].items.count)
                rows[index].height = max(rows[index].height, observation.height)
            } else {
                rows.append(Row(centerY: centerY, height: observation.height, items: [observation]))
            }
        }
        return rows.sorted { $0.centerY > $1.centerY }.map { row in
            row.items.sorted { $0.x < $1.x }.map(\.text).joined(separator: " ")
        }
    }

    private static func parseSinglePayment(
        _ lines: [String],
        learned: [String: ExpenseCategory],
        referenceDate: String
    ) -> [OCRExpenseCandidate] {
        let joined = lines.joined(separator: "\n")
        guard joined.range(of: "支付成功|交易成功|当前状态|付款成功|收款方|商户全称", options: .regularExpression) != nil else { return [] }

        var amount: Double?
        for (index, line) in lines.enumerated() where line.range(of: "支出|金额|付款|支付", options: .regularExpression) != nil {
            let nearby = ([line] + Array(lines.dropFirst(index + 1).prefix(2))).joined(separator: " ")
            if let value = firstNumber(in: nearby, patterns: [#"[¥￥]\s*([0-9]{1,7}(?:[.,][0-9]{1,2})?)"#, #"(?:支出|金额|付款|支付)[^0-9]{0,12}([0-9]{1,7}(?:[.,][0-9]{1,2})?)"#]) {
                amount = value
                break
            }
        }
        if amount == nil {
            amount = firstNumber(in: joined, patterns: [#"[¥￥]\s*([0-9]{1,7}(?:[.,][0-9]{1,2})?)"#])
        }

        let labels = ["付款给", "收款方", "商户全称", "交易对象", "商家名称"]
        var merchant = ""
        for (index, line) in lines.enumerated() {
            guard let label = labels.first(where: { line.contains($0) }) else { continue }
            let tail = line.components(separatedBy: label).dropFirst().joined().trimmingCharacters(in: CharacterSet(charactersIn: "：: "))
            merchant = cleanMerchant(tail)
            if merchant.count < 2, lines.indices.contains(index + 1) { merchant = cleanMerchant(lines[index + 1]) }
            if merchant.count >= 2 { break }
        }
        if merchant.count < 2 {
            merchant = lines.first(where: { looksLikeItem($0) }).map(cleanMerchant) ?? "图片识别项目"
        }

        let date = parseDate(joined, referenceDate: referenceDate)
        let classification = CategoryClassifier.classifyLocal(merchant, learned: learned)
        let missing = [date.isEmpty ? "日期" : "", amount == nil ? "金额" : ""].filter { !$0.isEmpty }
        return [OCRExpenseCandidate(
            date: date,
            item: merchant,
            amount: amount,
            category: classification.category,
            reason: missing.isEmpty ? classification.reason : "\(missing.joined(separator: "、"))未识别，请补充",
            transactionTime: parseTime(joined),
            reviewFields: missing
        )]
    }

    private static func parseTransactionList(
        _ lines: [String],
        learned: [String: ExpenseCategory],
        referenceDate: String
    ) -> [OCRExpenseCandidate] {
        let excluded = "退款|收入|来自|转账|余额宝|理财|月账单|总支出|全部支出|本月支出|优惠|节省|合计"
        var entries: [OCRExpenseCandidate] = []
        for index in lines.indices {
            let source = lines[index]
            if source.range(of: excluded, options: .regularExpression) != nil { continue }

            var amountMatch = trailingAmount(source)
            var itemLine = source
            var lookahead = index + 1
            if amountMatch == nil, looksLikeItem(source), lines.indices.contains(index + 1), let separate = wholeLineAmount(lines[index + 1]) {
                amountMatch = (separate, source.count)
                lookahead = index + 2
            }
            guard let amountMatch else { continue }
            if amountMatch.0 <= 0 || amountMatch.0 > 1_000_000 { continue }
            if amountMatch.1 < itemLine.count {
                itemLine = String(itemLine.prefix(amountMatch.1))
            }
            let item = cleanMerchant(itemLine)
            guard looksLikeItem(item) else { continue }

            let nearby = Array(lines.dropFirst(lookahead).prefix(6))
            if nearby.prefix(3).joined(separator: " ").range(of: "退款|已退回|全额退", options: .regularExpression) != nil { continue }
            let dateText = ([source] + nearby).joined(separator: " ")
            let date = parseDate(dateText, referenceDate: referenceDate)
            let classification = directCategory(nearby.first ?? "") ?? CategoryClassifier.classifyLocal(item, learned: learned)
            let missing = date.isEmpty ? ["日期"] : []
            entries.append(OCRExpenseCandidate(
                date: date,
                item: item,
                amount: amountMatch.0,
                category: classification.category,
                reason: missing.isEmpty ? classification.reason : "日期未识别，请补充",
                transactionTime: parseTime(dateText),
                reviewFields: missing
            ))
        }
        return entries
    }

    private static func parseTravelNotes(_ lines: [String], learned: [String: ExpenseCategory]) -> [OCRExpenseCandidate] {
        var entries: [OCRExpenseCandidate] = []
        for line in lines {
            if let match = captureGroups(in: line, pattern: #"^([\p{Han}]{2,12})\s*[-—–→]\s*([\p{Han}]{2,12}?)\s*([0-9]{1,6}(?:\.[0-9]{1,2})?)$"#),
               match.count >= 4, let amount = Double(match[3]) {
                entries.append(OCRExpenseCandidate(date: "", item: "\(match[1])→\(match[2])", amount: amount, category: .transport, reason: "识别到地点间行程", reviewFields: ["日期"]))
                continue
            }
            guard line.range(of: "酒店|住宿|宾馆|民宿", options: .regularExpression) != nil,
                  let amount = firstNumber(in: line, patterns: [#"([0-9]{1,6}(?:\.[0-9]{1,2})?)\s*$"#]) else { continue }
            let item = cleanMerchant(line.replacingOccurrences(of: #"[0-9]{1,6}(?:\.[0-9]{1,2})?\s*$"#, with: "", options: .regularExpression))
            let classification = CategoryClassifier.classifyLocal(item, learned: learned)
            entries.append(OCRExpenseCandidate(date: "", item: item, amount: amount, category: classification.category, reason: "识别到住宿费用", reviewFields: ["日期"]))
        }
        return entries
    }

    private static func parseFuel(_ lines: [String], referenceDate: String) -> OCRFuelCandidate? {
        let text = lines.joined(separator: "\n")
        let consumption = firstNumber(in: text, patterns: [
            #"(?:百公里(?:平均)?油耗|平均油耗|油耗)[^0-9]{0,20}([0-9]+(?:\.[0-9]+)?)\s*(?:L\s*/\s*100\s*km|升\s*/\s*百公里)?"#,
            #"([0-9]+(?:\.[0-9]+)?)\s*(?:L\s*/\s*100\s*km|升\s*/\s*百公里)"#,
        ])
        let distance = firstNumber(in: text, patterns: [
            #"(?:本次里程|行驶里程|总里程|路程|里程|行驶)[^0-9]{0,20}([0-9]+(?:\.[0-9]+)?)\s*(?:km|公里)"#,
            #"([0-9]+(?:\.[0-9]+)?)\s*(?:km|公里)"#,
        ])
        guard let consumption, let distance, consumption > 0, consumption <= 80, distance > 0, distance <= 100_000 else { return nil }
        var route = "自驾行程"
        if let labeled = lines.first(where: { $0.range(of: "(?:行程|路线|路段)[:：]", options: .regularExpression) != nil }) {
            route = labeled.replacingOccurrences(of: #"^.*?(?:行程|路线|路段)[:：]\s*"#, with: "", options: .regularExpression)
        } else if let arrow = lines.first(where: { $0.range(of: "[→↔]", options: .regularExpression) != nil }) {
            route = arrow
        }
        return OCRFuelCandidate(date: parseDate(text, referenceDate: referenceDate), route: route, distance: distance, consumption: consumption)
    }

    private static func parseDate(_ text: String, referenceDate: String) -> String {
        if let groups = captureGroups(in: text, pattern: #"(20[0-9]{2})[年./-]([0-9]{1,2})[月./-]([0-9]{1,2})日?"#), groups.count >= 4,
           let year = Int(groups[1]), let month = Int(groups[2]), let day = Int(groups[3]), validDate(year, month, day) {
            return String(format: "%04d-%02d-%02d", year, month, day)
        }
        let referenceYear = Int(referenceDate.prefix(4)) ?? Calendar.current.component(.year, from: Date())
        if let groups = captureGroups(in: text, pattern: #"(?:^|[^0-9])([0-9]{1,2})[月./-]([0-9]{1,2})日?(?:[^0-9]|$)"#), groups.count >= 3,
           let month = Int(groups[1]), let day = Int(groups[2]), validDate(referenceYear, month, day) {
            return String(format: "%04d-%02d-%02d", referenceYear, month, day)
        }
        if text.contains("昨天"), let reference = DateText.date(from: referenceDate), let date = Calendar.current.date(byAdding: .day, value: -1, to: reference) {
            return DateText.isoDate(date)
        }
        if text.contains("今天") { return referenceDate }
        return ""
    }

    private static func validDate(_ year: Int, _ month: Int, _ day: Int) -> Bool {
        guard (2000...2100).contains(year), (1...12).contains(month), (1...31).contains(day) else { return false }
        return Calendar(identifier: .gregorian).date(from: DateComponents(year: year, month: month, day: day)) != nil
    }

    private static func trailingAmount(_ line: String) -> (Double, Int)? {
        let pattern = #"(?:[-−－—–]\s*)?[¥￥]?\s*([0-9]{1,7}(?:[.,][0-9]{1,2})?)\s*$"#
        guard let groups = captureGroupsWithRange(in: line, pattern: pattern), groups.values.count >= 2,
              let amount = Double(groups.values[1].replacingOccurrences(of: ",", with: ".")) else { return nil }
        let token = String(line[line.index(line.startIndex, offsetBy: groups.range.lowerBound)..<line.index(line.startIndex, offsetBy: groups.range.upperBound)])
        guard token.range(of: "[-−－—–¥￥.]", options: .regularExpression) != nil else { return nil }
        return (amount, groups.range.lowerBound)
    }

    private static func wholeLineAmount(_ line: String) -> Double? {
        let compact = line.replacingOccurrences(of: " ", with: "")
        guard compact.range(of: #"^[-−－—–¥￥]*[0-9]{1,7}(?:[.,][0-9]{1,2})$"#, options: .regularExpression) != nil else { return nil }
        return firstNumber(in: compact, patterns: [#"([0-9]{1,7}(?:[.,][0-9]{1,2})?)$"#])
    }

    private static func looksLikeItem(_ line: String) -> Bool {
        let value = cleanMerchant(line)
        guard value.count >= 2, value.range(of: #"[\p{Han}A-Za-z]"#, options: .regularExpression) != nil else { return false }
        return value.range(of: "交易成功|支付成功|当前状态|交易时间|支付方式|订单号|账单|全部交易|搜索|筛选|日期|分类|金额|备注|查看更多", options: .regularExpression) == nil
    }

    private static func directCategory(_ value: String) -> Classification? {
        for category in ExpenseCategory.allCases where value.contains(category.rawValue) {
            return Classification(category: category, confidence: 0.99, reason: "图片账单标注为\(category.rawValue)")
        }
        return nil
    }

    private static func cleanMerchant(_ value: String) -> String {
        value
            .replacingOccurrences(of: "扫\\s*二\\s*维\\s*码\\s*付\\s*款", with: "", options: .regularExpression)
            .replacingOccurrences(of: "二维码付款|付款给|收款方|商户全称|交易对象|商家名称", with: "", options: .regularExpression)
            .replacingOccurrences(of: "^[：:·•\\s]+|[—–-]+$", with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func cleanLine(_ value: String) -> String {
        value.applyingTransform(.fullwidthToHalfwidth, reverse: false)?
            .replacingOccurrences(of: "￫", with: "→")
            .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? value
    }

    private static func parseTime(_ text: String) -> String {
        guard let groups = captureGroups(in: text, pattern: #"(?:^|\s)([0-9]{1,2})[:：]([0-9]{2})(?:[^0-9]|$)"#), groups.count >= 3,
              let hour = Int(groups[1]), let minute = Int(groups[2]), hour < 24, minute < 60 else { return "" }
        return String(format: "%02d:%02d", hour, minute)
    }

    private static func firstNumber(in text: String, patterns: [String]) -> Double? {
        for pattern in patterns {
            guard let groups = captureGroups(in: text, pattern: pattern), groups.count >= 2 else { continue }
            let value = Double(groups[1].replacingOccurrences(of: ",", with: "."))
            if let value, value > 0 { return value }
        }
        return nil
    }

    private static func captureGroups(in text: String, pattern: String) -> [String]? {
        captureGroupsWithRange(in: text, pattern: pattern)?.values
    }

    private static func captureGroupsWithRange(in text: String, pattern: String) -> (values: [String], range: Range<Int>)? {
        guard let expression = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = expression.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              let fullRange = Range(match.range(at: 0), in: text) else { return nil }
        var values: [String] = []
        for index in 0..<match.numberOfRanges {
            if let range = Range(match.range(at: index), in: text) { values.append(String(text[range])) }
            else { values.append("") }
        }
        return (values, text.distance(from: text.startIndex, to: fullRange.lowerBound)..<text.distance(from: text.startIndex, to: fullRange.upperBound))
    }

    private static func deduplicate(_ entries: [OCRExpenseCandidate]) -> [OCRExpenseCandidate] {
        var output: [OCRExpenseCandidate] = []
        for entry in entries {
            let key = CategoryClassifier.normalize(entry.item)
            let duplicate = output.contains {
                CategoryClassifier.normalize($0.item) == key &&
                    ($0.date.isEmpty || entry.date.isEmpty || $0.date == entry.date) &&
                    (($0.amount == nil && entry.amount == nil) || abs(($0.amount ?? 0) - (entry.amount ?? 0)) < 0.005)
            }
            if !duplicate { output.append(entry) }
        }
        return output
    }

    private static func fillCertainMissingDates(_ entries: [OCRExpenseCandidate]) -> [OCRExpenseCandidate] {
        guard entries.count >= 3 else { return entries }
        var result = entries
        for index in 1..<(result.count - 1) where result[index].date.isEmpty {
            if !result[index - 1].date.isEmpty, result[index - 1].date == result[index + 1].date {
                result[index].date = result[index - 1].date
                result[index].reviewFields.removeAll { $0 == "日期" }
                result[index].reason = "日期根据相邻交易补全"
            }
        }
        return result
    }
}
