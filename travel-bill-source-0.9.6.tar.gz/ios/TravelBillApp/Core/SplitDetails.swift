import Foundation

public struct SplitSuggestion: Equatable, Sendable {
    public let mode: SplitMode
    public let reason: String

    public init(mode: SplitMode, reason: String) {
        self.mode = mode
        self.reason = reason
    }
}

public enum SplitDetails {
    public static func suggest(item: String, category: ExpenseCategory) -> SplitSuggestion {
        let value = item.lowercased()
        let personal = ["地铁", "公交", "巴士", "轻轨", "个人", "自己", "自用", "单独", "小吃", "零食", "奶茶", "咖啡", "饮料", "纪念品", "冰箱贴", "伴手礼", "卫生巾", "药品", "自购"].contains { value.contains($0) }
        if personal || category == .shopping || category == .supplies { return SplitSuggestion(mode: .none, reason: "更像个人消费，默认不分账") }
        let shared = ["吃饭", "餐厅", "餐馆", "饭店", "火锅", "烧烤", "烤肉", "自助", "聚餐", "打车", "出租", "网约车", "滴滴", "高德打车", "包车", "停车", "12306", "高铁", "动车", "火车", "车票", "飞机", "航班", "机票", "门票", "景区", "演唱会", "活动", "酒店", "住宿", "自驾", "油费"].contains { value.contains($0) }
        if shared || category == .food { return SplitSuggestion(mode: .all, reason: "更像共同消费，建议全部同行人 AA") }
        return SplitSuggestion(mode: .none, reason: "暂未判断为共同消费")
    }

    public static func issue(for entry: ExpenseEntry, participants: [String]) -> String? {
        switch entry.splitMode {
        case .none: return nil
        case .all: return participants.isEmpty ? "请先填写同行人姓名" : nil
        case .selected:
            return participants.isEmpty ? "请先填写同行人姓名" : (entry.splitParticipants.isEmpty ? "请选择分账人员" : nil)
        case .custom:
            guard !participants.isEmpty else { return "请先填写同行人姓名" }
            let sum = participants.reduce(0) { $0 + (entry.splitAmounts[$1] ?? 0) }
            return abs(sum - entry.amount) > 0.01 ? String(format: "分账金额合计应为%.2f元", entry.amount) : nil
        }
    }

    public static func lines(for entry: ExpenseEntry, participants: [String]) -> [(name: String, amount: Double)] {
        guard entry.splitMode != .none else { return [] }
        if participants.isEmpty { return [] }
        switch entry.splitMode {
        case .selected:
            return equalLines(total: entry.amount, names: entry.splitParticipants)
        case .custom:
            return participants.map { ($0, entry.splitAmounts[$0] ?? 0) }
        case .all:
            return equalLines(total: entry.amount, names: participants)
        case .none:
            return []
        }
    }

    private static func equalLines(total: Double, names: [String]) -> [(name: String, amount: Double)] {
        guard !names.isEmpty else { return [] }
        let average = (total / Double(names.count) * 100).rounded() / 100
        return names.enumerated().map { index, name in
            let amount = index == names.count - 1 ? ((total - average * Double(names.count - 1)) * 100).rounded() / 100 : average
            return (name, amount)
        }
    }
}
