import Foundation
import ImageIO
import UIKit
@preconcurrency import Vision

enum VisionOCRService {
    static func recognize(_ image: UIImage) async throws -> [RecognizedTextLine] {
        guard let cgImage = image.cgImage else { throw OCRError.invalidImage }
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNRecognizeTextRequest { request, error in
                if let error { continuation.resume(throwing: error); return }
                let observations = (request.results as? [VNRecognizedTextObservation]) ?? []
                let lines = observations.compactMap { observation -> RecognizedTextLine? in
                    guard let candidate = observation.topCandidates(3).max(by: { $0.confidence < $1.confidence }) else { return nil }
                    let box = observation.boundingBox
                    return RecognizedTextLine(
                        text: candidate.string,
                        confidence: candidate.confidence,
                        x: box.minX,
                        y: box.minY,
                        width: box.width,
                        height: box.height
                    )
                }
                continuation.resume(returning: lines)
            }
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true
            request.recognitionLanguages = ["zh-Hans", "zh-Hant", "en-US"]
            request.minimumTextHeight = 0.006
            let handler = VNImageRequestHandler(cgImage: cgImage, orientation: image.cgOrientation)
            DispatchQueue.global(qos: .userInitiated).async {
                do { try handler.perform([request]) }
                catch { continuation.resume(throwing: error) }
            }
        }
    }

    enum OCRError: LocalizedError {
        case invalidImage
        var errorDescription: String? { "无法读取这张图片" }
    }
}

private extension UIImage {
    var cgOrientation: CGImagePropertyOrientation {
        switch imageOrientation {
        case .up: .up
        case .upMirrored: .upMirrored
        case .down: .down
        case .downMirrored: .downMirrored
        case .left: .left
        case .leftMirrored: .leftMirrored
        case .right: .right
        case .rightMirrored: .rightMirrored
        @unknown default: .up
        }
    }
}
