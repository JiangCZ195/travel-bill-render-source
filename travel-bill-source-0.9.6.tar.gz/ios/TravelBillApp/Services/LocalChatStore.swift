import Foundation

/// 本机长期保存聊天记录和原始媒体。
/// 云端只负责短期中转；即使云端消息过期，本地副本仍然保留。
enum LocalChatStore {
    private struct Envelope: Codable {
        var messages: [CloudMessage]
        var updatedAt: String
    }

    private static let fileManager = FileManager.default
    private static let rootDirectoryName = "TravelBillChat"
    private static let messagesDirectoryName = "Threads"
    private static let mediaDirectoryName = "Media"

    private static var rootURL: URL {
        let applicationSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return applicationSupport.appendingPathComponent(rootDirectoryName, isDirectory: true)
    }

    private static var messagesURL: URL { rootURL.appendingPathComponent(messagesDirectoryName, isDirectory: true) }
    private static var mediaURL: URL { rootURL.appendingPathComponent(mediaDirectoryName, isDirectory: true) }

    static func groupScope(_ groupID: String) -> String { "group_\(safeComponent(groupID))" }
    static func directScope(_ friendID: String) -> String { "direct_\(safeComponent(friendID))" }

    static func messages(scope: String, query: String = "") -> [CloudMessage] {
        guard let data = try? Data(contentsOf: fileURL(scope: scope)),
              let envelope = try? JSONDecoder().decode(Envelope.self, from: data) else { return [] }
        return filter(envelope.messages, query: query)
    }

    static func merge(_ remote: [CloudMessage], into scope: String, query: String = "") -> [CloudMessage] {
        var byID = Dictionary(uniqueKeysWithValues: messages(scope: scope).map { ($0.id, $0) })
        for message in remote { byID[message.id] = message }
        let merged = byID.values.sorted { stamp($0) < stamp($1) }
        save(merged, scope: scope)
        return filter(merged, query: query)
    }

    static func append(_ message: CloudMessage, scope: String) {
        _ = merge([message], into: scope)
    }

    static func remove(messageID: String, scope: String) {
        let retained = messages(scope: scope).filter { $0.id != messageID }
        save(retained, scope: scope)
    }

    static func saveMedia(_ data: Data, mediaID: String) {
        guard !mediaID.isEmpty else { return }
        do {
            try ensureDirectories()
            let url = mediaURL.appendingPathComponent(safeComponent(mediaID) + ".bin")
            try data.write(to: url, options: .atomic)
            try fileManager.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: url.path)
        } catch {
            // 本地缓存失败不阻止聊天发送；照片保存仍可走云端回源。
        }
    }

    static func mediaData(mediaID: String) -> Data? {
        guard !mediaID.isEmpty else { return nil }
        return try? Data(contentsOf: mediaURL.appendingPathComponent(safeComponent(mediaID) + ".bin"))
    }

    private static func save(_ messages: [CloudMessage], scope: String) {
        do {
            try ensureDirectories()
            let envelope = Envelope(messages: messages, updatedAt: ISO8601DateFormatter().string(from: Date()))
            let data = try JSONEncoder().encode(envelope)
            let url = fileURL(scope: scope)
            try data.write(to: url, options: .atomic)
            try fileManager.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: url.path)
        } catch {
            // 本地缓存失败不影响远端账单服务。
        }
    }

    private static func ensureDirectories() throws {
        try fileManager.createDirectory(at: messagesURL, withIntermediateDirectories: true)
        try fileManager.createDirectory(at: mediaURL, withIntermediateDirectories: true)
    }

    private static func fileURL(scope: String) -> URL {
        messagesURL.appendingPathComponent(safeComponent(scope) + ".json")
    }

    private static func filter(_ messages: [CloudMessage], query: String) -> [CloudMessage] {
        let cleanQuery = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !cleanQuery.isEmpty else { return messages.sorted { stamp($0) < stamp($1) } }
        return messages.filter { $0.body.lowercased().contains(cleanQuery) }.sorted { stamp($0) < stamp($1) }
    }

    private static func stamp(_ message: CloudMessage) -> String { "\(message.createdAt)|\(message.id)" }

    private static func safeComponent(_ value: String) -> String {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_."))
        let result = value.unicodeScalars.map { allowed.contains($0) ? String($0) : "_" }.joined()
        return result.isEmpty ? "default" : result
    }
}
