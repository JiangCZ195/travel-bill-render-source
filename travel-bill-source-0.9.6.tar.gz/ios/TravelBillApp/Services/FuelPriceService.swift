import Foundation

struct FuelPriceQuote: Sendable {
    var province: String
    var grade: String
    var price: Double
    var date: String
    var source: String
}

enum FuelPriceService {
    static func quote(province rawProvince: String, grade: String = "95#") async throws -> FuelPriceQuote {
        let province = rawProvince.replacingOccurrences(of: "[省市]$", with: "", options: .regularExpression)
        guard !province.isEmpty else { throw PriceError.missingProvince }
        let gradeKey = grade.replacingOccurrences(of: "#", with: "")
        do {
            let (data, response) = try await URLSession.shared.data(from: URL(string: "https://v1.apizero.cn/api/oil-price-forecast?action=price-all")!)
            guard (response as? HTTPURLResponse)?.statusCode == 200,
                  let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  (root["code"] as? NSNumber)?.intValue == 0,
                  let payload = root["data"] as? [String: Any],
                  let table = payload["prices"] as? [String: Any],
                  let row = table[province] as? [String: Any],
                  let price = number(row[gradeKey]) else { throw PriceError.notFound }
            return FuelPriceQuote(province: province, grade: grade, price: price, date: DateText.isoDate(), source: "全国油价参考")
        } catch {
            let (data, response) = try await URLSession.shared.data(from: URL(string: "https://v2.xxapi.cn/api/oilPrice")!)
            guard (response as? HTTPURLResponse)?.statusCode == 200,
                  let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let list = root["data"] as? [[String: Any]],
                  let row = list.first(where: { String(describing: $0["province"] ?? "").replacingOccurrences(of: "[省市]$", with: "", options: .regularExpression) == province }),
                  let price = number(row["n\(gradeKey)"]) else { throw PriceError.notFound }
            let date = String(describing: root["date"] ?? DateText.isoDate())
            return FuelPriceQuote(province: province, grade: grade, price: price, date: DateText.date(from: date).map(DateText.isoDate) ?? DateText.isoDate(), source: "全国油价参考")
        }
    }

    enum PriceError: LocalizedError {
        case missingProvince
        case notFound
        var errorDescription: String? {
            switch self {
            case .missingProvince: "未识别到油耗记录所在省份，请先选择省份"
            case .notFound: "暂未取得当前油价，请稍后重试"
            }
        }
    }

    private static func number(_ value: Any?) -> Double? {
        if let number = value as? NSNumber { return number.doubleValue }
        if let string = value as? String { return Double(string) }
        return nil
    }
}
