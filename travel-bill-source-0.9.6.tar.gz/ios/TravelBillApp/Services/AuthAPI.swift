import Foundation

struct AuthAPIResponse: Codable, Sendable {
    let session: String
    let user: AccountUser
}

struct OTPChallengeResponse: Codable, Sendable {
    let challengeId: String
    let expiresIn: Int
    let resendAfter: Int
    let delivery: String
    let destination: String
    let code: String?
}

struct MediaUploadMetadata: Sendable {
    var filename: String
    var mimeType: String
    var capturedAt: String
    var latitude: Double?
    var longitude: Double?
    var locationName: String
    var country: String
    var region: String
    var city: String
    var locationSource: String
}

enum AuthAPIError: LocalizedError {
    case missingIdentityToken
    case invalidResponse

    var errorDescription: String? {
        switch self {
        case .missingIdentityToken: "Apple 没有返回身份令牌"
        case .invalidResponse: "账号服务返回内容无法读取"
        }
    }
}

enum AuthAPI {
    static var configuredURLString: String {
        return (Bundle.main.object(forInfoDictionaryKey: "TravelBillAPIURL") as? String) ?? "http://127.0.0.1:4174"
    }

    static var baseURL: URL { URL(string: configuredURLString) ?? URL(string: "http://127.0.0.1:4174")! }

    static func signInWithApple(identityToken: Data, displayName: String, appleSubject: String? = nil) async throws -> AuthAPIResponse {
        guard let token = String(data: identityToken, encoding: .utf8), !token.isEmpty else { throw AuthAPIError.missingIdentityToken }
        var body = ["identityToken": token, "displayName": displayName]
        if let appleSubject, !appleSubject.isEmpty { body["appleSubject"] = appleSubject }
        return try await post(path: "/api/auth/apple", body: body)
    }

    static func signInDevelopment(displayName: String) async throws -> AuthAPIResponse {
        try await post(path: "/api/auth/dev-login", body: ["displayName": displayName])
    }

    static func requestLoginCode(identifier: String) async throws -> OTPChallengeResponse {
        try await postDecoded(path: "/api/auth/request-code", body: ["identifier": identifier])
    }

    static func verifyLoginCode(challengeID: String, identifier: String, code: String, displayName: String) async throws -> AuthAPIResponse {
        try await postDecoded(path: "/api/auth/verify-code", body: [
            "challengeId": challengeID,
            "identifier": identifier,
            "code": code,
            "displayName": displayName,
        ])
    }

    static func currentUser(session: String) async throws -> AccountUser {
        let response: CurrentUserResponse = try await request(path: "/api/auth/me", method: "GET", session: session)
        return response.user
    }

    static func claimPairing(code: String, session: String) async throws {
        var request = URLRequest(url: baseURL.appendingPathComponent("api/pairing/claim"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(session)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["code": code])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode([String: String].self, from: data)["error"]) ?? "配对码无效、已使用或已过期"
            throw NSError(domain: "TravelBillAuth", code: 401, userInfo: [NSLocalizedDescriptionKey: message])
        }
    }

    static func listGroups(session: String) async throws -> [CloudGroupSummary] {
        let response: GroupsResponse = try await request(path: "/api/bills", method: "GET", session: session)
        return response.groups
    }

    static func listFriends(session: String) async throws -> [CloudFriend] {
        let response: FriendsResponse = try await request(path: "/api/friends", method: "GET", session: session)
        return response.friends
    }

    static func getGroup(id: String, session: String) async throws -> CloudGroup {
        let response: GroupResponse = try await request(path: "/api/bills/\(id)", method: "GET", session: session)
        return response.group
    }

    static func createGroup(name: String, session: String) async throws -> CloudGroup {
        let response: GroupResponse = try await request(path: "/api/bills", method: "POST", body: ["name": name], session: session)
        return response.group
    }

    static func joinGroup(code: String, session: String) async throws -> CloudGroup {
        let response: GroupResponse = try await request(path: "/api/bills/join", method: "POST", body: ["code": code], session: session)
        return response.group
    }

    static func listPersonalTrips(query: String = "", session: String) async throws -> [PersonalTripSummary] {
        let suffix = query.isEmpty ? "" : "?q=\(query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        let response: PersonalTripsResponse = try await request(path: "/api/personal/trips\(suffix)", method: "GET", session: session)
        return response.trips
    }

    static func createPersonalTrip(name: String, session: String) async throws -> PersonalTripSummary {
        let response: PersonalTripResponse = try await request(path: "/api/personal/trips", method: "POST", body: ["name": name], session: session)
        return response.trip
    }

    static func getPersonalTrip(id: String, session: String) async throws -> PersonalTripDetail {
        let response: PersonalTripDetailResponse = try await request(path: "/api/personal/trips/\(id)", method: "GET", session: session)
        return response.trip
    }

    static func createPersonalExpense(tripID: String, body: [String: Any], session: String) async throws -> CloudPersonalExpense {
        let response: PersonalExpenseResponse = try await request(path: "/api/personal/trips/\(tripID)/expenses", method: "POST", body: body, session: session)
        return response.expense
    }

    static func updatePersonalExpense(tripID: String, expenseID: String, body: [String: Any], session: String) async throws -> CloudPersonalExpense {
        let response: PersonalExpenseResponse = try await request(path: "/api/personal/trips/\(tripID)/expenses/\(expenseID)", method: "PUT", body: body, session: session)
        return response.expense
    }

    static func deletePersonalExpense(tripID: String, expenseID: String, session: String) async throws {
        let _: EmptyResponse = try await request(path: "/api/personal/trips/\(tripID)/expenses/\(expenseID)", method: "DELETE", session: session)
    }

    static func createInvite(groupID: String, session: String) async throws -> String {
        let response: InviteResponse = try await request(path: "/api/bills/\(groupID)/invites", method: "POST", body: [:], session: session)
        return response.invite.code
    }

    static func listMessages(groupID: String, query: String = "", session: String) async throws -> [CloudMessage] {
        let suffix = query.isEmpty ? "" : "?q=\(query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        let response: MessagesResponse = try await request(path: "/api/bills/\(groupID)/messages\(suffix)", method: "GET", session: session)
        return response.messages
    }

    static func sendMessage(groupID: String, type: String = "text", body: String = "", mediaID: String = "", session: String) async throws -> CloudMessage {
        let response: MessageResponse = try await request(path: "/api/bills/\(groupID)/messages", method: "POST", body: ["type": type, "body": body, "mediaId": mediaID], session: session)
        return response.message
    }

    static func acknowledgeMessage(groupID: String, messageID: String, session: String) async throws {
        let _: EmptyResponse = try await request(path: "/api/bills/\(groupID)/messages/\(messageID)/ack", method: "POST", body: [:], session: session)
    }

    static func listDirectMessages(friendID: String, query: String = "", session: String) async throws -> [CloudMessage] {
        let suffix = query.isEmpty ? "" : "?q=\(query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
        let response: MessagesResponse = try await request(path: "/api/friends/\(friendID)/messages\(suffix)", method: "GET", session: session)
        return response.messages
    }

    static func sendDirectMessage(friendID: String, type: String = "text", body: String = "", mediaID: String = "", session: String) async throws -> CloudMessage {
        let response: MessageResponse = try await request(path: "/api/friends/\(friendID)/messages", method: "POST", body: ["type": type, "body": body, "mediaId": mediaID], session: session)
        return response.message
    }

    static func acknowledgeDirectMessage(friendID: String, messageID: String, session: String) async throws {
        let _: EmptyResponse = try await request(path: "/api/friends/\(friendID)/messages/\(messageID)/ack", method: "POST", body: [:], session: session)
    }

    static func createExpense(groupID: String, body: [String: Any], session: String) async throws -> CloudExpense {
        let response: ExpenseResponse = try await request(path: "/api/bills/\(groupID)/expenses", method: "POST", body: body, session: session)
        return response.expense
    }

    static func updateExpense(groupID: String, expenseID: String, body: [String: Any], session: String) async throws -> CloudExpense {
        let response: ExpenseResponse = try await request(path: "/api/bills/\(groupID)/expenses/\(expenseID)", method: "PUT", body: body, session: session)
        return response.expense
    }

    static func deleteExpense(groupID: String, expenseID: String, session: String) async throws {
        let _: EmptyResponse = try await request(path: "/api/bills/\(groupID)/expenses/\(expenseID)", method: "DELETE", session: session)
    }

    static func listGroupMedia(groupID: String, session: String) async throws -> [MediaAsset] {
        let response: MediaListResponse = try await request(path: "/api/bills/\(groupID)/media", method: "GET", session: session)
        return response.media
    }

    static func listFootprints(session: String) async throws -> FootprintSummary {
        try await request(path: "/api/footprints", method: "GET", session: session)
    }

    static func uploadAvatar(data: Data, filename: String, mimeType: String, session: String) async throws -> AccountUser {
        let boundary = "TravelBillAvatar-\(UUID().uuidString)"
        var request = URLRequest(url: baseURL.appendingPathComponent("api/account/avatar"))
        request.httpMethod = "POST"
        request.setValue("Bearer \(session)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        body.append(Data("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\nContent-Type: \(mimeType)\r\n\r\n".utf8))
        body.append(data)
        body.append(Data("\r\n--\(boundary)--\r\n".utf8))
        request.httpBody = body
        let (responseData, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode([String: String].self, from: responseData)["error"]) ?? "头像上传失败"
            throw NSError(domain: "TravelBillAuth", code: httpStatus(response), userInfo: [NSLocalizedDescriptionKey: message])
        }
        struct AvatarResponse: Decodable { let user: AccountUser }
        return try JSONDecoder().decode(AvatarResponse.self, from: responseData).user
    }

    static func uploadMedia(data: Data, groupID: String?, directFriendID: String? = nil, visibility: ExpenseVisibility, metadata: MediaUploadMetadata, session: String, mediaType: String? = nil) async throws -> MediaAsset {
        let boundary = "TravelBill-\(UUID().uuidString)"
        let path = directFriendID.map { "api/friends/\($0)/media" } ?? groupID.map { "api/bills/\($0)/media" } ?? "api/personal/media"
        var request = URLRequest(url: baseURL.appendingPathComponent(path))
        request.httpMethod = "POST"
        request.setValue("Bearer \(session)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        func append(_ text: String) { body.append(Data(text.utf8)) }
        func field(_ name: String, _ value: String) {
            append("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(name)\"\r\n\r\n\(value)\r\n")
        }
        field("tripKey", "current")
        field("visibility", visibility.rawValue)
        field("capturedAt", metadata.capturedAt)
        field("latitude", metadata.latitude.map { String($0) } ?? "")
        field("longitude", metadata.longitude.map { String($0) } ?? "")
        field("locationName", metadata.locationName)
        field("country", metadata.country)
        field("region", metadata.region)
        field("city", metadata.city)
        field("locationSource", metadata.locationSource)
        if let mediaType, !mediaType.isEmpty { field("mediaType", mediaType) }
        append("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"\(metadata.filename)\"\r\nContent-Type: \(metadata.mimeType)\r\n\r\n")
        body.append(data)
        append("\r\n--\(boundary)--\r\n")
        request.httpBody = body
        let (responseData, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode([String: String].self, from: responseData)["error"]) ?? "相册上传失败"
            throw NSError(domain: "TravelBillMedia", code: httpStatus(response), userInfo: [NSLocalizedDescriptionKey: message])
        }
        return try JSONDecoder().decode(MediaUploadResponse.self, from: responseData).media
    }

    static func mediaData(id: String, session: String) async throws -> (Data, String) {
        var request = URLRequest(url: baseURL.appendingPathComponent("api/media/\(id)/file"))
        request.httpMethod = "GET"
        request.setValue("Bearer \(session)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw AuthAPIError.invalidResponse }
        return (data, http.mimeType ?? "application/octet-stream")
    }

    static func deleteMedia(id: String, session: String) async throws {
        let _: EmptyResponse = try await request(path: "/api/media/\(id)", method: "DELETE", session: session)
    }

    private static func request<T: Decodable>(path: String, method: String, body: Any? = nil, session: String) async throws -> T {
        let pieces = path.trimmingCharacters(in: CharacterSet(charactersIn: "/")).split(separator: "?", maxSplits: 1, omittingEmptySubsequences: false)
        var url = baseURL.appendingPathComponent(String(pieces[0]))
        if pieces.count > 1, var components = URLComponents(url: url, resolvingAgainstBaseURL: false) { components.query = String(pieces[1]); url = components.url ?? url }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(session)", forHTTPHeaderField: "Authorization")
        if let body { request.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw AuthAPIError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode([String: String].self, from: data)["error"]) ?? "账号服务暂时不可用"
            throw NSError(domain: "TravelBillAuth", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: message])
        }
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            throw NSError(domain: "TravelBillAuth", code: 500, userInfo: [NSLocalizedDescriptionKey: "账号服务返回内容无法读取：\(error.localizedDescription)"])
        }
    }

    static func post(path: String, body: [String: String]) async throws -> AuthAPIResponse {
        try await postDecoded(path: path, body: body)
    }

    private static func postDecoded<T: Decodable>(path: String, body: [String: String]) async throws -> T {
        var request = URLRequest(url: baseURL.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch let error as URLError {
            throw NSError(
                domain: "TravelBillAuth",
                code: error.errorCode,
                userInfo: [NSLocalizedDescriptionKey: "无法连接账号服务（\(configuredURLString)）。请检查网络连接或服务器状态。"]
            )
        }
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let message = (try? JSONDecoder().decode([String: String].self, from: data)["error"]) ?? "账号服务暂时不可用"
            throw NSError(domain: "TravelBillAuth", code: httpStatus(response), userInfo: [NSLocalizedDescriptionKey: message])
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    private static func httpStatus(_ response: URLResponse) -> Int {
        (response as? HTTPURLResponse)?.statusCode ?? 0
    }
}

private struct GroupsResponse: Decodable { let groups: [CloudGroupSummary] }
private struct FriendsResponse: Decodable { let friends: [CloudFriend] }
private struct PersonalTripsResponse: Decodable { let trips: [PersonalTripSummary] }
private struct PersonalTripResponse: Decodable { let trip: PersonalTripSummary }
struct PersonalTripDetail: Codable, Sendable { let id: String; let name: String; let tripMeta: [String: String]; let expenses: [CloudPersonalExpense]; let media: [MediaAsset] }
private struct PersonalTripDetailResponse: Decodable { let trip: PersonalTripDetail }
struct CloudPersonalExpense: Codable, Sendable { let id: String; let tripId: String; let date: String; let item: String; let category: ExpenseCategory; let amountCents: Int; let source: String }
private struct PersonalExpenseResponse: Decodable { let expense: CloudPersonalExpense }
private struct MessagesResponse: Decodable { let messages: [CloudMessage] }
private struct MessageResponse: Decodable { let message: CloudMessage }
private struct MediaListResponse: Decodable { let media: [MediaAsset] }
private struct MediaUploadResponse: Decodable { let media: MediaAsset }
private struct CurrentUserResponse: Decodable { let user: AccountUser }
private struct GroupResponse: Decodable { let group: CloudGroup }
private struct ExpenseResponse: Decodable { let expense: CloudExpense }
private struct InviteResponse: Decodable { let invite: Invite }
private struct Invite: Decodable { let code: String }
private struct EmptyResponse: Decodable { let ok: Bool }
