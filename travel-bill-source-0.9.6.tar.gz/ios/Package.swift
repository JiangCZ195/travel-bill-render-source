// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TravelBillCore",
    platforms: [
        .iOS(.v17),
        .macOS(.v13),
    ],
    products: [
        .library(name: "TravelBillCore", targets: ["TravelBillCore"]),
        .executable(name: "TravelBillCoreChecks", targets: ["TravelBillCoreChecks"]),
    ],
    dependencies: [
        .package(url: "https://github.com/weichsel/ZIPFoundation.git", .upToNextMajor(from: "0.9.12")),
    ],
    targets: [
        .target(
            name: "TravelBillCore",
            dependencies: ["ZIPFoundation"],
            path: "TravelBillApp/Core"
        ),
        .executableTarget(
            name: "TravelBillCoreChecks",
            dependencies: ["TravelBillCore", "ZIPFoundation"],
            path: "TravelBillCoreChecks"
        ),
    ]
)
