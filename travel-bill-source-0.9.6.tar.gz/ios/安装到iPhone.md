# 安装“旅迹账单”到 iPhone

不需要购买开发者会员，也不会发布到 App Store。免费 Apple 账号会在 Xcode 中显示为 `Personal Team`。

## 第一次安装

1. 在 Mac App Store 安装 Xcode，并首次打开一次，让它完成组件安装。
2. 双击 `TravelBill.xcodeproj`。
3. 在 Xcode 顶部菜单打开 `Xcode → Settings → Accounts`，登录你的 Apple 账号。
4. 用数据线连接 iPhone，按手机提示选择“信任此电脑”。
5. 在左侧点蓝色的 `TravelBill` 项目，再点中间的 `TravelBill` Target。
6. 打开 `Signing & Capabilities`，勾选 `Automatically manage signing`，在 `Team` 选择你的名字和 `Personal Team`。
7. 如果 Bundle Identifier 显示占用，把 `com.jcz.TravelBill` 改成只属于你的名称，例如在末尾加自己的英文缩写。
8. 在 Xcode 顶部设备列表选择你的 iPhone，然后点击左上角三角形运行按钮。
9. 如果手机提示开发者模式，到 `设置 → 隐私与安全性 → 开发者模式` 打开，重启手机后再运行一次。

安装完成后，桌面会出现浅蓝色“旅迹账单”图标。以后直接点图标打开，不需要连接 Mac；免费签名到期后例外。

## iPhone 独立使用

当前版本已部署到 HTTPS 云端，iPhone 不依赖 Mac，也不要求两台设备在同一个 Wi-Fi。第一次打开 App 后，在“账号同步”中输入邮箱，获取并填写一次性验证码即可登录；页面不再显示服务地址输入框。

账单和聊天数据按当前账号保存到云端加密状态中，原图和视频在接收方完成本地缓存后可保存到系统相册。Mac App 仍可单独使用，暂不要求与 iPhone 同步。

## 免费账号限制

Apple 当前规定 Personal Team 的设备注册和安装描述文件有效期为 7 天；到期后要把手机连接 Mac，在 Xcode 再点一次运行。最多可登记 3 台设备，每台最多安装 3 个这类测试 App。

朋友要使用时，可以把朋友的 iPhone 连接到这台 Mac，重复选择设备并运行；同样受 7 天有效期和 3 台设备限制。

## 保存 Excel

在 App 中点“生成 Excel 账单”，核验成功后点“保存或分享 Excel”，再选择“存储到文件”并指定 iCloud Drive、我的 iPhone 或其他文件夹。
