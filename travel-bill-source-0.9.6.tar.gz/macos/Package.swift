// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TravelBillMac",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "TravelBillMac", targets: ["TravelBillMac"]),
    ],
    targets: [
        .executableTarget(
            name: "TravelBillMac",
            path: "Sources/TravelBillMac"
        ),
    ]
)
