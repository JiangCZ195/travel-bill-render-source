#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

if [[ -d "/Applications/Xcode-beta.app/Contents/Developer" ]]; then
  export DEVELOPER_DIR="/Applications/Xcode-beta.app/Contents/Developer"
fi

swift build -c release
EXECUTABLE="$(find .build -type f \( -path '*/release/TravelBillMac' -o -path '*/Products/Release/TravelBillMac' \) -perm -111 -print -quit)"
if [[ -z "$EXECUTABLE" ]]; then
  print -u2 "找不到 TravelBillMac 可执行文件"
  exit 1
fi

APP_DIR="${1:-$SCRIPT_DIR/dist/旅迹账单.app}"
mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"
cp "$EXECUTABLE" "$APP_DIR/Contents/MacOS/TravelBillMac"
cp "$SCRIPT_DIR/Info.plist" "$APP_DIR/Contents/Info.plist"
chmod +x "$APP_DIR/Contents/MacOS/TravelBillMac"
xattr -cr "$APP_DIR"
codesign --force --deep --sign - "$APP_DIR" >/dev/null
xattr -cr "$APP_DIR"
codesign --verify --deep --strict "$APP_DIR"
print "已生成：$APP_DIR"
