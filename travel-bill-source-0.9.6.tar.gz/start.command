#!/bin/zsh
cd "$(dirname "$0")"
NODE_BIN="/Users/jcz/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
PNPM_BIN="/Users/jcz/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm"
if [ ! -d node_modules ]; then
  "$PNPM_BIN" install --ignore-scripts
fi
HOST="${HOST:-0.0.0.0}" PORT="${PORT:-4174}" APPLE_AUTH_MODE="${APPLE_AUTH_MODE:-development}" "$NODE_BIN" server.mjs
