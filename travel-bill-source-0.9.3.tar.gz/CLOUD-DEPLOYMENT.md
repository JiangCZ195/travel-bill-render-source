# iPhone 独立登录部署清单

目标是：账单、聊天和原始媒体长期保存在各自设备；公网只保存加密账单状态快照和加密临时中转媒体。

## 已写入项目

- `TRAVEL_BILL_STATE_STORE=supabase`：账号、账单组、费用和好友关系加密后写入 Supabase 表。
- `TRAVEL_BILL_MEDIA_STORE=supabase`：上传媒体先由 API 使用 AES-256-GCM 加密，再写入私有 Storage bucket。
- 消息送达确认或 7 天有效期到达后，API 删除消息和中转媒体。
- Render 只运行 API，根网页入口已关闭；`/api/health` 保留给健康检查。

## 需要用户完成的外部步骤

1. 创建 Supabase 项目。
2. 在 Supabase SQL Editor 执行 `supabase/schema.sql`。
3. 创建 Render Web Service，使用仓库中的 `render.yaml`。
4. 在 Render 填入 `SUPABASE_URL` 和 `SUPABASE_SERVICE_ROLE_KEY`；服务角色密钥只放 Render，不能写入 iPhone 或仓库。
5. 生产登录使用 Supabase 邮箱一次性验证码（`TRAVEL_BILL_OTP_PROVIDER=supabase`），不依赖 Apple Developer Program；Apple 登录仍可作为后续可选方式配置。
6. 得到 Render 的 HTTPS 地址后，才把 iOS `TravelBillAPIURL` 改成该地址并重新安装 App。

## 验收条件

- `GET https://你的地址/api/health` 返回 `ok: true`。
- 普通浏览器访问根路径返回 410，不再提供网页端。
- 两台 iPhone 使用不同账号登录后，可以加入同一账单组。
- 发送文字、原图和视频后，接收方本地缓存完成并回执，云端中转对象被清理。
- 关闭发送方 App、断开 Mac，再从 iPhone 登录仍能读取账号和账单组。
