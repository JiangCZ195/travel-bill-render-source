# 安装“旅迹账单”到 iPhone

不需要购买开发者会员，也不会发布到 App Store。免费 Apple 账号会在 Xcode 中显示为 `Personal Team`。

## 第一次安装

1. 在 Mac App Store 安装 Xcode，并首次打开一次，让它完成组件安装。
2. 双击 `TravelBill.xcodeproj`。
3. 在 Xcode 顶部菜单打开 `Xcode → Settings → Accounts`，登录你的 Apple 账号。
4. 用数据线连接 iPhone，按手机提示选择“信任此电脑”。
5. 在左侧点蓝色的 `TravelBill` 项目，再点中间的 `TravelBill` Target。
6. 打开 `Signing & Capabilities`，勾选 `Automatically manage signing`，在 `Team` 选择你的名字和 `Personal Team`。
7. 如果 Bundle Identifier 显示占用，把 `com.jcz.TravelBill` 改成只属于你的名称，例如在末尾加自己的英文缩写。
8. 在 Xcode 顶部设备列表选择你的 iPhone，然后点击左上角三角形运行按钮。
9. 如果手机提示开发者模式，到 `设置 → 隐私与安全性 → 开发者模式` 打开，重启手机后再运行一次。

安装完成后，桌面会出现浅蓝色“旅迹账单”图标。以后直接点图标打开，不需要连接 Mac；免费签名到期后例外。

## 让 iPhone 连接 Mac 账单服务

如果只是先在家里和朋友试用，iPhone 可以直接连接同一 Wi-Fi 下的 Mac，不需要购买服务器：

1. 让 Mac 和 iPhone 连接同一个 Wi-Fi。
2. 在 Mac 上双击项目里的 `start.command` 启动服务；它已经允许同一 Wi-Fi 下的 iPhone 访问。
3. 在 Mac 的“系统设置 → 网络 → Wi-Fi”查看 Mac 的局域网 IP，例如 `192.168.1.23`。
4. 第一次打开 App 时允许“本地网络”权限，在“账号同步”里的“服务地址”填入 `http://192.168.1.23:4174` 并保存。
5. 使用 Apple ID 登录。若 Mac 网页端已经配置 Apple 网页登录，可以直接使用同一个 Apple ID；如果 Mac 端暂时使用“本地预览账号”，就在 Mac 的账号窗口点击“用 iPhone 绑定此 Mac”，再把 Mac 显示的绑定码填入 iPhone，两个设备会合并到同一个账号。

`127.0.0.1` 只代表当前设备本身，所以 iPhone 不能直接使用这个地址访问 Mac。以后要在外网或离开 Mac 时使用，需要把服务部署到 HTTPS 地址，再把 `TravelBillAPIURL` 改成该地址。

## 免费账号限制

Apple 当前规定 Personal Team 的设备注册和安装描述文件有效期为 7 天；到期后要把手机连接 Mac，在 Xcode 再点一次运行。最多可登记 3 台设备，每台最多安装 3 个这类测试 App。

朋友要使用时，可以把朋友的 iPhone 连接到这台 Mac，重复选择设备并运行；同样受 7 天有效期和 3 台设备限制。

## 保存 Excel

在 App 中点“生成 Excel 账单”，核验成功后点“保存或分享 Excel”，再选择“存储到文件”并指定 iCloud Drive、我的 iPhone 或其他文件夹。
