import Charts
import AVFoundation
import CoreLocation
import MapKit
import Photos
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers
import ZIPFoundation

private struct ChatMediaPayload {
    let data: Data
    let metadata: MediaUploadMetadata
    let messageType: String
    let mediaType: String?
}

struct ContentView: View {
    @EnvironmentObject private var store: BillStore
    @Environment(\.scenePhase) private var scenePhase
    private enum AppTab: Hashable { case personal, friends, footprints, me }
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var avatarItems: [PhotosPickerItem] = []
    @State private var chatMediaItems: [PhotosPickerItem] = []
    @State private var selectedTab: AppTab = .personal
    @State private var showCamera = false
    @State private var showFiles = false
    @State private var personalSearch = ""
    @State private var friendsSearch = ""
    @State private var friendsMode = 0
    @State private var showFriendsDetail = false
    @State private var showChat = false
    @State private var chatReturnToDetail = false
    @State private var chatText = ""
    @State private var showChatSearch = false
    @StateObject private var voiceRecorder = ChatVoiceRecorder()

    var body: some View {
        NavigationStack {
            TabView(selection: $selectedTab) {
                personalPage
                    .tabItem { Label("个人账单", systemImage: "person.crop.circle") }
                    .tag(AppTab.personal)
                friendsPage
                    .tabItem { Label("好友账单", systemImage: "person.2") }
                    .badge(store.unreadChatCount > 0 ? store.unreadChatCount : 0)
                    .tag(AppTab.friends)
                footprintPage
                    .tabItem { Label("我的足迹", systemImage: "map") }
                    .tag(AppTab.footprints)
                mePage
                    .tabItem { Label("我的", systemImage: "person") }
                    .tag(AppTab.me)
            }
            .tint(Color.deepBlue)
            .toolbarBackground(.ultraThinMaterial, for: .tabBar)
            .background(Color.appBackground.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
        }
        .sheet(isPresented: $showCamera) {
            CameraPicker { image in
                guard let image else { return }
                Task { await store.importImages([image]) }
            }
        }
        .fileImporter(
            isPresented: $showFiles,
            allowedContentTypes: [.image, .commaSeparatedText, UTType(filenameExtension: "xlsx") ?? .data],
            allowsMultipleSelection: true,
            onCompletion: importFiles
        )
        .sheet(isPresented: $showPersonalCreate) { personalCreateSheet }
        .sheet(isPresented: $showGroupCreate) { groupCreateSheet }
        .onChange(of: photoItems) { _, items in
            Task {
                var images: [UIImage] = []
                for item in items {
                    if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) { images.append(image) }
                }
                photoItems = []
                await store.importImages(images)
            }
        }
        .onChange(of: chatMediaItems) { _, items in
            guard !items.isEmpty else { return }
            chatMediaItems = []
            Task { await importChatMedia(items) }
        }
        .onChange(of: avatarItems) { _, items in
            guard let item = items.first else { return }
            avatarItems = []
            Task {
                guard let data = try? await item.loadTransferable(type: Data.self) else { return }
                let mime = item.supportedContentTypes.first?.preferredMIMEType ?? "image/jpeg"
                await MainActor.run { store.updateAvatar(data: data, filename: "avatar.jpg", mimeType: mime) }
            }
        }
        .onChange(of: selectedTab) { _, tab in
            showFriendsDetail = false
            showChat = false
            showChatSearch = false
            chatReturnToDetail = false
            store.chatGroupID = nil
            store.chatFriendID = nil
            configure(tab)
        }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active, store.currentUser != nil else { return }
            Task { await store.refreshGroups() }
        }
        .onAppear { configure(selectedTab) }
        .overlay(alignment: .top) {
            if store.isShowingChatNotification {
                Button {
                    guard let groupID = store.chatNotificationGroupID else { return }
                    store.dismissChatNotification()
                    selectedTab = .friends
                    showFriendsDetail = false
                    showChat = true
                    chatReturnToDetail = false
                    store.openChat(groupID: groupID)
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "message.badge.filled.fill")
                            .foregroundStyle(.white)
                            .frame(width: 24, height: 24)
                            .background(Color.red, in: Circle())
                        VStack(alignment: .leading, spacing: 2) {
                            Text(store.chatNotificationTitle).font(.subheadline.weight(.semibold)).foregroundStyle(Color.ink)
                            Text(store.chatNotificationBody).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer()
                        Image(systemName: "chevron.right").foregroundStyle(Color.deepBlue)
                    }
                    .padding(13)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.8)))
                    .shadow(color: Color.deepBlue.opacity(0.18), radius: 18, y: 8)
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 16)
                .padding(.top, 8)
            }
        }
    }

    @State private var showPersonalCreate = false
    @State private var showGroupCreate = false

    @ViewBuilder private var personalPage: some View {
        if store.activePersonalTripID == nil {
            personalHistoryPage
        } else {
            personalDetailPage
        }
    }

    private var personalDetailPage: some View {
        pageScroll {
            header
            detailBackButton(title: "我的账单") {
                store.activePersonalTripID = nil
                Task { await store.refreshPersonalTrips() }
            }
            tripCard
            imageSection
            manualSection
            expenseSection
            chartSection
            exportSection
        }
        .simultaneousGesture(backSwipeGesture())
    }

    @ViewBuilder private var friendsPage: some View {
        if showChat {
            chatPage
        } else if showFriendsDetail {
            friendsDetailPage
        } else {
            friendsHistoryPage
        }
    }

    private var friendsDetailPage: some View {
        pageScroll {
            header
            detailBackButton(title: "好友账单") {
                showFriendsDetail = false
                store.chatGroupID = nil
                store.chatFriendID = nil
            }
            groupSection
            if let group = store.activeGroup {
                Button {
                    chatReturnToDetail = true
                    store.openChat(groupID: group.id)
                    showChat = true
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "message.fill")
                            .font(.headline)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("进入账单群聊").font(.headline)
                            Text("在这次共同旅行中聊天、发图片和语音").font(.caption2).opacity(0.72)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .padding(15)
                    .foregroundStyle(Color.ink)
                    .background(Color.farPeakBlue, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                }
                .buttonStyle(.plain)
            }
            participantSection
            tripCard
            imageSection
            manualSection
            expenseSection
            chartSection
            exportSection
        }
        .simultaneousGesture(backSwipeGesture())
    }

    private var personalHistoryPage: some View {
        pageScroll {
            header
            historyHeader(
                eyebrow: "我的账单",
                title: "个人旅行",
                subtitle: "每一次独自出游，都有一份自己的账单",
                actionTitle: "新建",
                action: { showPersonalCreate = true }
            )
            historySearch(text: $personalSearch, placeholder: "查找旅程或花费")
            if filteredPersonalTrips.isEmpty {
                emptyHistory(icon: "suitcase", title: "还没有个人旅行", message: "点击右上角“新建”，开始记录下一次旅途。")
            } else {
                tripListCard {
                    ForEach(filteredPersonalTrips) { trip in
                        Button {
                            Task { await store.selectPersonalTrip(trip.id) }
                        } label: {
                            tripRow(
                                title: trip.name,
                                subtitle: personalTripSubtitle(trip),
                                total: Double(trip.totalCents) / 100,
                                icon: "person.crop.circle"
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            if !store.message.isEmpty { statusLine(store.message) }
        }
    }

    private var friendsHistoryPage: some View {
        pageScroll {
            header
            historyHeader(
                eyebrow: "好友账单",
                title: "共同旅行",
                subtitle: "公共消费与私人小项目分开记录",
                actionTitle: "+",
                action: { showGroupCreate = true }
            )
            Picker("好友账单模式", selection: $friendsMode) {
                Text("共同旅程").tag(0)
                Text("好友列表").tag(1)
            }
            .pickerStyle(.segmented)
            historySearch(text: $friendsSearch, placeholder: friendsMode == 0 ? "查找共同旅程或花费" : "查找好友")
            if friendsMode == 0 {
                if filteredGroups.isEmpty {
                    emptyHistory(icon: "person.2", title: "还没有共同旅程", message: "点击右上角“+”，新建账单组或加入朋友的账单组。")
                } else {
                    tripListCard {
                        ForEach(filteredGroups) { group in
                            Button {
                                store.selectGroup(group.id)
                                showFriendsDetail = true
                            } label: {
                                tripRow(
                                    title: group.name,
                                    subtitle: "(group.memberCount) 人共同旅行 · 点击查看账单",
                                    total: group.id == store.activeGroup?.id ? store.total : nil,
                                    icon: "person.2"
                                )
                                .overlay(alignment: .topTrailing) {
                                    unreadBubble(store.unreadByGroup[group.id] ?? 0)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            } else {
                if filteredFriends.isEmpty {
                    emptyHistory(icon: "person.crop.circle.badge.plus", title: "还没有好友记录", message: "加入共同账单后，这里会显示同行朋友。")
                } else {
                    friendListCard
                }
            }
            if !store.accountMessage.isEmpty { statusLine(store.accountMessage) }
        }
    }

    private var chatPage: some View {
        pageScroll {
            header
            HStack(spacing: 10) {
                Button {
                    let returnToDetail = chatReturnToDetail
                    showChat = false
                    showFriendsDetail = returnToDetail
                    chatReturnToDetail = false
                    store.chatGroupID = nil
                    store.chatFriendID = nil
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.headline.weight(.semibold))
                        .frame(width: 38, height: 38)
                        .background(Color.field, in: Circle())
                }
                .buttonStyle(.plain)
                VStack(alignment: .leading, spacing: 2) {
                    Text(chatFriendTitle).font(.title3.bold()).foregroundStyle(Color.ink)
                    Text(store.chatFriendID == nil ? "账单组群聊 · \(store.activeGroup?.members.count ?? 0) 人" : "好友私聊").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    showChatSearch.toggle()
                } label: { Image(systemName: "magnifyingglass") }
                    .buttonStyle(.bordered)
                    .tint(Color.deepBlue)
            }
            if showChatSearch {
                    historySearch(text: $store.chatSearch, placeholder: "查找聊天记录")
                    .onChange(of: store.chatSearch) { _, value in
                        if let groupID = store.chatGroupID { store.loadChat(groupID: groupID, search: value) }
                        else if let friendID = store.chatFriendID { store.loadDirectChat(friendID: friendID, search: value) }
                    }
            }
            card(title: "聊天记录") {
                if store.chatMessages.isEmpty {
                    Text(store.chatFriendID == nil ? "还没有群聊记录" : "还没有私聊记录").font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity, minHeight: 230).padding(.vertical, 32)
                } else {
                    LazyVStack(spacing: 11) {
                        ForEach(store.chatMessages) { message in
                            HStack(alignment: .bottom, spacing: 7) {
                                if message.senderId == store.currentUser?.id { Spacer(minLength: 24) }
                                VStack(alignment: message.senderId == store.currentUser?.id ? .trailing : .leading, spacing: 3) {
                                    Text(message.sender?.displayName ?? "旅伴").font(.caption2).foregroundStyle(.secondary)
                                        HStack(spacing: 7) {
                                            if !message.body.isEmpty {
                                                Text(message.body).font(.body)
                                            } else {
                                                Image(systemName: message.type == "video" ? "video.fill" : message.type == "audio" ? "waveform" : message.type == "livePhoto" ? "livephoto" : "photo.fill")
                                                Text(message.type == "video" ? "已发送原视频" : message.type == "audio" ? "已发送语音" : message.type == "livePhoto" ? "已发送实况照片" : "已发送原图").font(.body)
                                            }
                                        }
                                        .padding(.horizontal, 11)
                                        .padding(.vertical, 8)
                                        .background(message.senderId == store.currentUser?.id ? Color.farPeakBlue : Color.field, in: RoundedRectangle(cornerRadius: 14))
                                    if !message.mediaId.isEmpty && message.type != "audio" {
                                        ChatMediaSaveButton(mediaID: message.mediaId, mediaType: message.type)
                                    }
                                }
                                if message.senderId != store.currentUser?.id { Spacer(minLength: 24) }
                            }
                        }
                    }
                }
                HStack(spacing: 8) {
                    PhotosPicker(selection: $chatMediaItems, maxSelectionCount: 1, matching: .any(of: [.images, .videos, .livePhotos])) {
                        Image(systemName: "photo.on.rectangle.angled")
                            .font(.headline)
                            .frame(width: 42, height: 42)
                            .foregroundStyle(Color.deepBlue)
                            .background(Color.farPeakBlue.opacity(0.72), in: RoundedRectangle(cornerRadius: 13))
                    }
                    .accessibilityLabel("发送图片或视频")
                    Button { } label: {
                        Image(systemName: voiceRecorder.isRecording ? "stop.fill" : "mic.fill")
                            .font(.headline)
                            .frame(width: 42, height: 42)
                            .foregroundStyle(voiceRecorder.isRecording ? .white : Color.deepBlue)
                            .background(voiceRecorder.isRecording ? Color.red : Color.field, in: RoundedRectangle(cornerRadius: 13))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("按住录音")
                    .simultaneousGesture(LongPressGesture(minimumDuration: 0.35).onEnded { _ in
                        voiceRecorder.start()
                    })
                    .simultaneousGesture(DragGesture(minimumDistance: 0).onEnded { _ in
                        guard let audio = voiceRecorder.finish() else { return }
                        let metadata = MediaUploadMetadata(
                            filename: "语音消息-\(UUID().uuidString).m4a",
                            mimeType: "audio/m4a",
                            capturedAt: ISO8601DateFormatter().string(from: Date()),
                            latitude: nil, longitude: nil, locationName: "", country: "", region: "", city: "", locationSource: ""
                        )
                        store.sendChatMedia(data: audio, metadata: metadata, type: "audio")
                    })
                    Text(voiceRecorder.isRecording ? "松开发送语音" : "按住说话")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                HStack(spacing: 8) {
                    TextField("发消息", text: $chatText, axis: .vertical)
                        .lineLimit(1...4)
                        .textFieldStyle(.roundedBorder)
                    Button {
                        let text = chatText
                        chatText = ""
                        store.sendChatMessage(text)
                    } label: { Image(systemName: "paperplane.fill") }
                        .buttonStyle(.borderedProminent)
                        .tint(Color.deepBlue)
                }
                Text("图片、实况照片、视频和语音会按原文件发送，接收方可以保存到设备。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .simultaneousGesture(backSwipeGesture())
    }

    private func backSwipeGesture() -> some Gesture {
        DragGesture(minimumDistance: 35)
            .onEnded { value in
                let horizontal = value.translation.width
                let vertical = abs(value.translation.height)
                guard horizontal > 90, horizontal > vertical * 1.25 else { return }
                if showChat {
                    let returnToDetail = chatReturnToDetail
                    showChat = false
                    showChatSearch = false
                    showFriendsDetail = returnToDetail
                    chatReturnToDetail = false
                    store.chatGroupID = nil
                    store.chatFriendID = nil
                } else if showFriendsDetail {
                    showFriendsDetail = false
                } else if store.activePersonalTripID != nil {
                    store.activePersonalTripID = nil
                }
            }
    }

    private var filteredPersonalTrips: [PersonalTripSummary] {
        let query = personalSearch.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return store.personalTrips }
        return store.personalTrips.filter { trip in
            trip.name.lowercased().contains(query) || trip.tripMeta.values.contains { $0.lowercased().contains(query) }
        }
    }

    private var filteredGroups: [CloudGroupSummary] {
        let query = friendsSearch.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return store.groups }
        return store.groups.filter { $0.name.lowercased().contains(query) }
    }

    private var filteredFriends: [CloudFriend] {
        let query = friendsSearch.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return store.friends.filter { friend in
            query.isEmpty || friend.displayName.lowercased().contains(query) || friend.lastGroupName.lowercased().contains(query)
        }
    }

    private var chatFriendTitle: String {
        if let friendID = store.chatFriendID { return store.friends.first(where: { $0.id == friendID })?.displayName ?? "好友私聊" }
        guard let group = store.activeGroup else { return "旅行聊天" }
        let names = group.members.compactMap { member -> String? in
            guard member.userId != store.currentUser?.id else { return nil }
            return member.user?.displayName
        }
        return names.isEmpty ? group.name : names.joined(separator: "、")
    }

    private func personalTripSubtitle(_ trip: PersonalTripSummary) -> String {
        let meta = trip.tripMeta.values.filter { !$0.isEmpty }.joined(separator: " · ")
        return meta.isEmpty ? "(trip.expenseCount) 笔费用 · (trip.mediaCount) 个媒体" : "(meta) · (trip.expenseCount) 笔费用"
    }

    private func historyHeader(eyebrow: String, title: String, subtitle: String, actionTitle: String, action: @escaping () -> Void) -> some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 5) {
                Text(eyebrow).font(.caption.weight(.semibold)).foregroundStyle(Color.deepBlue)
                Text(title).font(.system(size: 30, weight: .bold, design: .rounded)).foregroundStyle(Color.ink)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            Button(action: action) {
                Image(systemName: actionTitle == "+" ? "plus" : "plus")
                    .font(.headline.weight(.bold))
                    .frame(width: 42, height: 42)
                    .foregroundStyle(Color.ink)
                    .background(Color.farPeakBlue, in: Circle())
            }
            .buttonStyle(.plain)
        }
    }

    private func historySearch(text: Binding<String>, placeholder: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass").foregroundStyle(Color.deepBlue)
            TextField(placeholder, text: text)
                .textInputAutocapitalization(.never)
            if !text.wrappedValue.isEmpty {
                Button { text.wrappedValue = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                    .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 13)
        .frame(minHeight: 46)
        .background(Color.field, in: RoundedRectangle(cornerRadius: 15))
        .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.deepBlue.opacity(0.11)))
    }

    private func tripListCard<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        card(title: "历史记录") { VStack(spacing: 0, content: content) }
    }

    private func tripRow(title: String, subtitle: String, total: Double?, icon: String) -> some View {
        HStack(spacing: 11) {
            Image(systemName: icon)
                .font(.headline)
                .foregroundStyle(Color.deepBlue)
                .frame(width: 42, height: 42)
                .background(Color.farPeakBlue.opacity(0.8), in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline).foregroundStyle(Color.ink).lineLimit(1)
                Text(subtitle).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: 4)
            if let total { Text(total, format: .currency(code: "CNY")).font(.caption.weight(.semibold)).foregroundStyle(Color.deepBlue) }
            Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
        }
        .padding(.vertical, 11)
        .overlay(alignment: .bottom) { Divider().opacity(0.45) }
    }

    @ViewBuilder private func unreadBubble(_ count: Int) -> some View {
        if count > 0 {
            Text(count > 99 ? "99+" : "\(count)")
                .font(.system(size: 9, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 5)
                .frame(minWidth: 18, minHeight: 18)
                .background(Color.red, in: Capsule())
        }
    }

    private var friendListCard: some View {
        card(title: "好友") {
            VStack(spacing: 0) {
                ForEach(filteredFriends) { friend in
                    Button {
                        chatReturnToDetail = false
                        store.openFriendChat(friendID: friend.id)
                        showChat = true
                    } label: {
                        HStack(spacing: 11) {
                            Text(String(friend.displayName.prefix(1)))
                                .font(.headline)
                                .foregroundStyle(Color.ink)
                                .frame(width: 42, height: 42)
                                .background(Color.farPeakBlue, in: Circle())
                            VStack(alignment: .leading, spacing: 4) {
                                Text(friend.displayName).font(.headline).foregroundStyle(Color.ink)
                                Text("好友私聊 · \(friend.sharedGroupCount) 个共同账单").font(.caption2).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").foregroundStyle(.tertiary)
                        }
                        .padding(.vertical, 11)
                        .overlay(alignment: .bottom) { Divider().opacity(0.45) }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func emptyHistory(icon: String, title: String, message: String) -> some View {
        card(title: "暂无记录") {
            VStack(spacing: 9) {
                Image(systemName: icon).font(.system(size: 30)).foregroundStyle(Color.deepBlue)
                Text(title).font(.headline).foregroundStyle(Color.ink)
                Text(message).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 23)
        }
    }

    private func statusLine(_ text: String) -> some View {
        Text(text).font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
    }

    private func detailBackButton(title: String, action: @escaping () -> Void) -> some View {
        HStack(spacing: 8) {
            Button(action: action) {
                Image(systemName: "chevron.left")
                    .font(.headline.weight(.semibold))
                    .frame(width: 36, height: 36)
                    .background(Color.field, in: Circle())
            }
            .buttonStyle(.plain)
            Text(title).font(.headline).foregroundStyle(Color.ink)
            Spacer()
        }
    }

    private var personalCreateSheet: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 14) {
                Text("给这次旅程起一个名字").font(.headline).foregroundStyle(Color.ink)
                TextField("例如：杭州周末", text: $store.manualGroupName)
                    .textFieldStyle(.roundedBorder)
                Button {
                    let name = store.manualGroupName
                    store.manualGroupName = ""
                    showPersonalCreate = false
                    store.createPersonalTrip(name: name)
                } label: {
                    Text("创建个人账单").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 13)
                }
                .buttonStyle(.plain).foregroundStyle(Color.ink).background(Color.farPeakBlue, in: RoundedRectangle(cornerRadius: 15))
                Spacer()
            }
            .padding(20)
            .navigationTitle("新建个人账单")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { showPersonalCreate = false } } }
        }
        .presentationDetents([.medium])
    }

    private var groupCreateSheet: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 14) {
                Text("新建共同旅行").font(.headline).foregroundStyle(Color.ink)
                TextField("账单组名称", text: $store.manualGroupName).textFieldStyle(.roundedBorder)
                Button {
                    showGroupCreate = false
                    store.createGroup()
                } label: {
                    Label("新建账单组", systemImage: "plus").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 13)
                }
                .buttonStyle(.plain).foregroundStyle(Color.ink).background(Color.farPeakBlue, in: RoundedRectangle(cornerRadius: 15))
                Divider()
                TextField("输入好友邀请码", text: $store.manualInviteCode).textFieldStyle(.roundedBorder).textInputAutocapitalization(.characters)
                Button {
                    showGroupCreate = false
                    store.joinGroup()
                } label: {
                    Label("加入账单组", systemImage: "person.badge.plus").font(.headline).frame(maxWidth: .infinity).padding(.vertical, 13)
                }
                .buttonStyle(.plain).foregroundStyle(Color.ink).background(Color.field, in: RoundedRectangle(cornerRadius: 15))
                Spacer()
            }
            .padding(20)
            .navigationTitle("好友账单")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { showGroupCreate = false } } }
        }
        .presentationDetents([.medium])
    }

    private var footprintPage: some View {
        pageScroll {
            header
            footprintSection
        }
    }

    private var mePage: some View {
        pageScroll {
            header
            accountSection
            card(title: "使用说明") {
                VStack(alignment: .leading, spacing: 8) {
                    Text("个人账单只记录自己的旅行；好友账单用于共同出游，并同时保留公共消费和你的私人小项目。")
                    Text("好友聊天支持文字、按住录音、发送图片、实况照片和视频；接收方可以保存原文件。")
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
        }
    }

    private func pageScroll<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        ScrollView {
            VStack(spacing: 16, content: content)
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 34)
        }
        .scrollIndicators(.hidden)
    }

    private func configure(_ tab: AppTab) {
        switch tab {
        case .friends:
            store.workspace = .friends
            store.manualVisibility = .group
        case .personal, .me:
            store.workspace = .personal
            store.manualVisibility = .private
        case .footprints:
            store.workspace = .personal
            store.manualVisibility = .private
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("AppMark")
                .resizable()
                .scaledToFit()
                .frame(width: 52, height: 52)
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text("旅迹账单").font(.system(size: 27, weight: .bold, design: .rounded)).foregroundStyle(Color.ink)
                Text("旅行账单与 Excel").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if store.isWorking { ProgressView().tint(Color.deepBlue) }
        }
        .padding(.top, 12)
    }

    private var accountSection: some View {
        card(title: "账号同步") {
            if let account = store.currentUser {
                HStack(spacing: 10) {
                    Image(systemName: "person.crop.circle.fill")
                        .font(.title2)
                        .foregroundStyle(Color.deepBlue)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(account.displayName).font(.headline)
                        Text(account.email.isEmpty ? "邮箱 / 手机号账号已连接" : account.email)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    PhotosPicker(selection: $avatarItems, maxSelectionCount: 1, matching: .images) {
                        Label("更换头像", systemImage: "camera.fill")
                    }
                    .buttonStyle(.bordered)
                    .tint(Color.deepBlue)
                    Button("退出") { store.signOut() }
                        .buttonStyle(.bordered)
                        .tint(Color.deepBlue)
                }
                HStack(spacing: 8) {
                    TextField("输入 Mac 配对码", text: $store.manualPairingCode)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.numberPad)
                    Button("配对 Mac") { store.claimMacPairing() }
                        .buttonStyle(.bordered)
                        .tint(Color.deepBlue)
                }
                Text("在 Mac 登录窗口生成 6 位配对码后输入；配对码 5 分钟内有效且只能使用一次。")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    TextField("邮箱或手机号", text: $store.loginIdentifier)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .textFieldStyle(.roundedBorder)
                    HStack(spacing: 8) {
                        TextField("姓名（首次登录填写）", text: $store.loginDisplayName)
                            .textFieldStyle(.roundedBorder)
                        Button("获取验证码") { store.requestLoginCode() }
                            .buttonStyle(.borderedProminent)
                            .tint(Color.deepBlue)
                    }
                    HStack(spacing: 8) {
                        TextField("6 位验证码", text: $store.loginCode)
                            .keyboardType(.numberPad)
                            .textFieldStyle(.roundedBorder)
                        Button("登录") { store.verifyLoginCode() }
                            .buttonStyle(.bordered)
                            .tint(Color.deepBlue)
                    }
                    if !store.loginCodeHint.isEmpty {
                        Text(store.loginCodeHint)
                            .font(.caption2)
                            .foregroundStyle(Color.deepBlue)
                    }
                }
                    Text("生产版使用邮箱验证码，iPhone 可独立登录；Mac 与 iPhone 可使用同一个账号。")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            if !store.accountMessage.isEmpty {
                Text(store.accountMessage)
                    .font(.caption2)
                    .foregroundStyle(store.accountMessage.contains("失败") ? .red : .secondary)
            }
        }
    }

    private var groupSection: some View {
        card(title: "账单组") {
            if store.currentUser == nil {
                Text("登录后可以创建旅行账单组，邀请朋友共同记录公共费用。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                HStack(spacing: 8) {
                    TextField("新建旅行账单组", text: $store.manualGroupName)
                        .textFieldStyle(.roundedBorder)
                    Button("创建") { store.createGroup() }
                        .buttonStyle(.bordered)
                        .tint(Color.deepBlue)
                }
                HStack(spacing: 8) {
                    TextField("输入好友邀请码", text: $store.manualInviteCode)
                        .textFieldStyle(.roundedBorder)
                        .textInputAutocapitalization(.characters)
                    Button("加入") { store.joinGroup() }
                        .buttonStyle(.bordered)
                        .tint(Color.deepBlue)
                }
                if !store.groups.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(store.groups) { group in
                                Button {
                                    store.selectGroup(group.id)
                                } label: {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(group.name).font(.caption.weight(.semibold))
                                        Text("\(group.memberCount) 人")
                                            .font(.caption2)
                                            .foregroundStyle(.secondary)
                                    }
                                    .padding(.horizontal, 11)
                                    .padding(.vertical, 8)
                                    .background(store.activeGroup?.id == group.id ? Color.farPeakBlue : Color.field, in: RoundedRectangle(cornerRadius: 12))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                if let group = store.activeGroup {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(group.name).font(.headline)
                                Text("成员：\(group.members.map { $0.user?.displayName ?? "旅伴" }.joined(separator: "、"))")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(2)
                            }
                            Spacer()
                            Button("邀请朋友") { store.createInvite() }
                                .buttonStyle(.bordered)
                                .tint(Color.deepBlue)
                        }
                        if !store.inviteCode.isEmpty {
                            Text("邀请码：\(store.inviteCode)")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(Color.deepBlue)
                                .textSelection(.enabled)
                        }
                    }
                    .padding(11)
                    .background(Color.farPeakBlue.opacity(0.45), in: RoundedRectangle(cornerRadius: 14))
                } else {
                    Text("还没有账单组，可以先创建一个旅行账单组。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var tripCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "sparkles")
                .font(.title2.weight(.semibold))
                .foregroundStyle(Color.deepBlue)
                .frame(width: 46, height: 46)
                .background(.white.opacity(0.58), in: RoundedRectangle(cornerRadius: 14))
            VStack(alignment: .leading, spacing: 4) {
                Text(store.trip.title.isEmpty ? "等待费用内容" : store.trip.title)
                    .font(.headline)
                    .foregroundStyle(Color.ink)
                    .lineLimit(2)
                Text(store.currentEntries.isEmpty ? "日期、地点与国旗会自动生成" : TripInference.filename(for: store.trip))
                    .font(.caption2)
                    .foregroundStyle(Color.ink.opacity(0.66))
                    .lineLimit(1)
            }
            Spacer()
        }
        .padding(16)
        .background(Color.farPeakBlue, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .shadow(color: Color.deepBlue.opacity(0.12), radius: 18, y: 8)
    }

    private var imageSection: some View {
        card(title: "图片识别") {
            HStack(spacing: 10) {
                PhotosPicker(selection: $photoItems, maxSelectionCount: 30, matching: .images) {
                    actionLabel("图片识别", systemImage: "photo.on.rectangle.angled", primary: true)
                }
                Button { showCamera = true } label: { actionLabel("拍照", systemImage: "camera", primary: false) }
                Button { showFiles = true } label: { actionLabel("文件/油耗表", systemImage: "doc", primary: false) }
            }
            if !store.message.isEmpty {
                Text(store.message)
                    .font(.caption)
                    .foregroundStyle(store.message.contains("失败") || store.message.contains("无法") ? .red : Color.ink.opacity(0.68))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var footprintSection: some View {
        card(title: "我的足迹") {
            footprintMapView
            Text(store.footprintSummary.places.isEmpty
                ? "发送带定位信息的照片或视频后，这里会显示国家、地区和城市。"
                : "已记录 \(store.footprintSummary.countries.count) 个国家/地区、\(store.footprintSummary.cities.count) 个城市或景点。")
                .font(.caption)
                .foregroundStyle(.secondary)
            if !store.footprintSummary.places.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 7) {
                        ForEach(store.footprintSummary.places) { place in
                            Text([place.country, place.region, place.city.isEmpty ? place.locationName : place.city].filter { !$0.isEmpty }.joined(separator: " · "))
                                .font(.caption2)
                                .padding(.horizontal, 9)
                                .padding(.vertical, 7)
                                .background(Color.farPeakBlue.opacity(0.6), in: Capsule())
                        }
                    }
                }
            }
        }
    }

    private var footprintMapView: some View {
        let world = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 25, longitude: 105),
            span: MKCoordinateSpan(latitudeDelta: 105, longitudeDelta: 220)
        )
        return Map(initialPosition: .region(world)) {
            ForEach(store.footprintSummary.places) { place in
                if let latitude = place.latitude, let longitude = place.longitude {
                    Marker(
                        [place.city, place.locationName].first(where: { !$0.isEmpty }) ?? "足迹",
                        coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
                    )
                    .tint(Color.deepBlue)
                }
            }
        }
        .mapStyle(.standard(elevation: .flat))
        .frame(height: 180)
        .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 17).stroke(Color.deepBlue.opacity(0.12)))
    }

    private func importChatMedia(_ items: [PhotosPickerItem]) async {
        guard !items.isEmpty else { return }
        for item in items {
            do {
                let payload = try await chatMediaPayload(for: item)
                store.sendChatMedia(data: payload.data, metadata: payload.metadata, type: payload.messageType, mediaType: payload.mediaType)
            } catch {
                await MainActor.run { store.message = "媒体文件无法读取：\(error.localizedDescription)" }
            }
        }
    }

    private func chatMediaPayload(for item: PhotosPickerItem) async throws -> ChatMediaPayload {
        if isLivePhoto(item) {
            guard let identifier = item.itemIdentifier,
                  let asset = PHAsset.fetchAssets(withLocalIdentifiers: [identifier], options: nil).firstObject else {
                throw NSError(domain: "TravelBillMedia", code: 1, userInfo: [NSLocalizedDescriptionKey: "无法读取实况照片资源"])
            }
            let resources = PHAssetResource.assetResources(for: asset)
            guard let photo = resources.first(where: { $0.type == .photo }),
                  let pairedVideo = resources.first(where: { $0.type == .pairedVideo }) else {
                throw NSError(domain: "TravelBillMedia", code: 2, userInfo: [NSLocalizedDescriptionKey: "实况照片缺少配对视频"])
            }
            let photoData = try await loadAssetResource(photo)
            let videoData = try await loadAssetResource(pairedVideo)
            let archive = try Archive(accessMode: .create)
            let photoName = photo.originalFilename.isEmpty ? "live-photo.heic" : photo.originalFilename
            let videoName = pairedVideo.originalFilename.isEmpty ? "live-photo.mov" : pairedVideo.originalFilename
            try addArchiveEntry(photoData, named: photoName, to: archive)
            try addArchiveEntry(videoData, named: videoName, to: archive)
            guard let archiveData = archive.data else {
                throw NSError(domain: "TravelBillMedia", code: 3, userInfo: [NSLocalizedDescriptionKey: "实况照片打包失败"])
            }
            var metadata = await mediaMetadata(for: item)
            metadata.filename = "实况照片-\(UUID().uuidString).zip"
            metadata.mimeType = "application/zip"
            return ChatMediaPayload(data: archiveData, metadata: metadata, messageType: "livePhoto", mediaType: "livePhoto")
        }

        guard let data = try await item.loadTransferable(type: Data.self) else {
            throw NSError(domain: "TravelBillMedia", code: 4, userInfo: [NSLocalizedDescriptionKey: "媒体文件无法读取"])
        }
        let metadata = await mediaMetadata(for: item)
        let isVideo = item.supportedContentTypes.contains { $0.conforms(to: .movie) }
        return ChatMediaPayload(data: data, metadata: metadata, messageType: isVideo ? "video" : "image", mediaType: nil)
    }

    private func isLivePhoto(_ item: PhotosPickerItem) -> Bool {
        if item.supportedContentTypes.contains(where: { $0.identifier == "com.apple.live-photo" }) { return true }
        guard let identifier = item.itemIdentifier,
              let asset = PHAsset.fetchAssets(withLocalIdentifiers: [identifier], options: nil).firstObject else { return false }
        return asset.mediaSubtypes.contains(.photoLive)
    }

    private func loadAssetResource(_ resource: PHAssetResource) async throws -> Data {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("travel-bill-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: url) }
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            PHAssetResourceManager.default().writeData(for: resource, toFile: url, options: nil) { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: ()) }
            }
        }
        return try Data(contentsOf: url)
    }

    private func addArchiveEntry(_ data: Data, named name: String, to archive: Archive) throws {
        try archive.addEntry(with: name, type: .file, uncompressedSize: Int64(data.count), compressionMethod: .deflate) { position, size in
            let start = Int(position)
            let end = min(start + size, data.count)
            return data.subdata(in: start..<end)
        }
    }

    private func mediaMetadata(for item: PhotosPickerItem) async -> MediaUploadMetadata {
        let isVideo = item.supportedContentTypes.contains { $0.conforms(to: .movie) }
        let asset = item.itemIdentifier.flatMap { PHAsset.fetchAssets(withLocalIdentifiers: [$0], options: nil).firstObject }
        let location = asset?.location
        var placemark: CLPlacemark?
        if let location { placemark = try? await CLGeocoder().reverseGeocodeLocation(location).first }
        let date = asset?.creationDate ?? Date()
        let capturedAt = ISO8601DateFormatter().string(from: date)
        let type = item.supportedContentTypes.first
        let mimeType = type?.preferredMIMEType ?? (isVideo ? "video/mp4" : "image/jpeg")
        let suffix = isVideo ? ".mp4" : (mimeType.contains("heic") ? ".heic" : ".jpg")
        return MediaUploadMetadata(
            filename: "旅途-\(UUID().uuidString)\(suffix)",
            mimeType: mimeType,
            capturedAt: capturedAt,
            latitude: location?.coordinate.latitude,
            longitude: location?.coordinate.longitude,
            locationName: placemark?.name ?? "",
            country: placemark?.country ?? "",
            region: placemark?.administrativeArea ?? "",
            city: placemark?.locality ?? placemark?.subAdministrativeArea ?? "",
            locationSource: location == nil ? "" : "照片定位"
        )
    }

    private var participantSection: some View {
        card(title: "同行人") {
            HStack(spacing: 8) {
                TextField("输入姓名后加入", text: $store.manualParticipantName)
                    .onSubmit { store.addParticipant() }
                Button("＋加入") { store.addParticipant() }
                    .buttonStyle(.bordered)
                    .tint(Color.deepBlue)
            }
            if !store.participants.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 7) {
                        ForEach(store.participants, id: \.self) { name in
                            Button {
                                store.removeParticipant(name)
                            } label: {
                                HStack(spacing: 4) {
                                    Text(name)
                                    Text("×").foregroundStyle(.secondary)
                                }
                                .font(.caption)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.farPeakBlue.opacity(0.55), in: Capsule())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            Text(store.participants.isEmpty ? "未填写姓名时按个人账处理，只保留每笔总金额；填写姓名后才启用分账。" : "每笔费用都可以选择 AA、指定人员平摊、按人填写金额或不分账。")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }

    private var manualSection: some View {
        card(title: "添加花费") {
            VStack(spacing: 11) {
                HStack(spacing: 10) {
                    fieldShell {
                        MonthDayPicker(date: $store.manualDate)
                    }
                    fieldShell {
                        Picker("分类", selection: $store.manualCategory) {
                            ForEach(ExpenseCategory.allCases) { Text($0.rawValue).tag($0) }
                        }
                        .pickerStyle(.menu)
                        .tint(Color.ink)
                    }
                }
                fieldShell {
                    TextField("项目", text: $store.manualItem)
                        .textInputAutocapitalization(.never)
                        .onChange(of: store.manualItem) { _, _ in store.scheduleManualClassification() }
                }
                fieldShell {
                    HStack {
                        Text("¥").foregroundStyle(.secondary)
                        TextField("金额", text: $store.manualAmount).keyboardType(.decimalPad)
                    }
                }
                if store.workspace == .friends, store.activeGroup != nil {
                    fieldShell {
                        Picker("账单范围", selection: $store.manualVisibility) {
                            Text("公共账单").tag(ExpenseVisibility.group)
                            Text("私人小项目").tag(ExpenseVisibility.private)
                        }
                        .pickerStyle(.menu)
                        .tint(Color.ink)
                    }
                }
                if !store.classificationReason.isEmpty {
                    Text(store.classificationReason).font(.caption2).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading)
                }
                Button(action: store.addManualEntry) {
                    Label("加入账单", systemImage: "plus")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                }
                .buttonStyle(.plain)
                .foregroundStyle(Color.ink)
                .background(Color.farPeakBlue, in: RoundedRectangle(cornerRadius: 15))
            }
        }
    }

    private var expenseSection: some View {
        card(title: "费用明细") {
            HStack {
                Text("\(store.currentEntries.count) 笔").font(.caption).foregroundStyle(.secondary)
                if store.reviewCount > 0 || store.splitReviewCount > 0 { Text("\(store.reviewCount + store.splitReviewCount) 笔待确认").font(.caption.weight(.semibold)).foregroundStyle(.orange) }
                Spacer()
                if !store.currentEntries.isEmpty { Button("清空", role: .destructive, action: store.clearAll).font(.caption) }
            }
            if store.currentEntries.isEmpty {
                Text("暂无费用").foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(.vertical, 34)
            } else {
                ScrollView {
                    LazyVStack(spacing: 10) {
                        ForEach(store.currentEntries) { entry in
                            ExpenseEditorRow(entry: entryBinding(for: entry))
                                .environmentObject(store)
                        }
                    }
                }
                .frame(maxHeight: 430)
                .scrollIndicators(.visible)
            }
        }
    }

    private var chartSection: some View {
        card(title: "统计图表") {
            Chart(ExpenseCategory.allCases) { category in
                BarMark(x: .value("分类", category.rawValue), y: .value("金额", store.categoryTotals[category, default: 0]))
                    .foregroundStyle(Color(hex: category.colorHex))
                    .annotation(position: .top) {
                        let value = store.categoryTotals[category, default: 0]
                        if value > 0 { Text(value, format: .number.precision(.fractionLength(0...2))).font(.caption2) }
                    }
            }
            .chartLegend(.hidden)
            .frame(height: 170)
            Chart(ExpenseCategory.allCases) { category in
                SectorMark(
                    angle: .value("金额", max(store.categoryTotals[category, default: 0], 0.0001)),
                    innerRadius: .ratio(0.58),
                    angularInset: 1.5
                )
                .cornerRadius(3)
                .foregroundStyle(Color(hex: category.colorHex))
            }
            .chartLegend(position: .bottom, spacing: 10)
            .frame(height: 220)
            .overlay {
                VStack(spacing: 2) {
                    Text("总计").font(.caption).foregroundStyle(.secondary)
                    Text(store.total, format: .currency(code: "CNY")).font(.headline)
                    if store.workspace == .friends, store.currentUser != nil, store.activeGroup != nil {
                        Text("我的承担：")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(store.personalTotal, format: .currency(code: "CNY"))
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(Color.deepBlue)
                    }
                }
            }
        }
    }

    private var exportSection: some View {
        VStack(spacing: 10) {
            Button(action: store.exportExcel) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("生成 Excel 账单").font(.headline)
                        Text(store.reviewCount > 0 || store.splitReviewCount > 0 ? "请先完成待确认项目" : "生成后可保存到“文件”或发给朋友").font(.caption2).opacity(0.72)
                    }
                    Spacer()
                    Image(systemName: "arrow.up.right")
                }
                .padding(16)
            }
            .buttonStyle(.plain)
            .foregroundStyle(Color.ink)
            .background(Color.farPeakBlue, in: RoundedRectangle(cornerRadius: 18))
            .opacity(store.canExport ? 1 : 0.55)

            if let url = store.lastExportURL {
                ShareLink(item: url) {
                    Label("保存或分享 Excel", systemImage: "square.and.arrow.up")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.white)
                .background(Color.deepBlue, in: RoundedRectangle(cornerRadius: 15))
            }
        }
    }

    @ViewBuilder private func card<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        let base = VStack(alignment: .leading, spacing: 13) {
            Text(title).font(.title3.bold()).foregroundStyle(Color.ink)
            content()
        }
        .padding(16)
        if #available(iOS 26.0, *) {
            base
                .glassEffect(.regular, in: .rect(cornerRadius: 24))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.55)))
                .shadow(color: Color.deepBlue.opacity(0.09), radius: 16, y: 7)
        } else {
            base
                .background(Color.field.opacity(0.92), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.deepBlue.opacity(0.08)))
                .shadow(color: Color.deepBlue.opacity(0.07), radius: 16, y: 7)
        }
    }

    private func entryBinding(for entry: ExpenseEntry) -> Binding<ExpenseEntry> {
        Binding(
            get: { store.entries.first(where: { $0.id == entry.id }) ?? entry },
            set: { store.updateEntry($0) }
        )
    }

    private func actionLabel(_ text: String, systemImage: String, primary: Bool) -> some View {
        Label(text, systemImage: systemImage)
            .font(.caption.weight(.semibold))
            .lineLimit(1)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .foregroundStyle(Color.ink)
            .background(primary ? Color.farPeakBlue : Color.field, in: RoundedRectangle(cornerRadius: 14))
    }

    private func fieldShell<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        content()
            .frame(maxWidth: .infinity, minHeight: 46, alignment: .leading)
            .padding(.horizontal, 12)
            .background(Color.field, in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.deepBlue.opacity(0.11)))
    }

    private func importFiles(_ result: Result<[URL], Error>) {
        Task {
            do {
                let urls = try result.get()
                var images: [UIImage] = []
                for url in urls {
                    let accessed = url.startAccessingSecurityScopedResource()
                    defer { if accessed { url.stopAccessingSecurityScopedResource() } }
                    let data = try Data(contentsOf: url)
                    if ["xlsx", "csv"].contains(url.pathExtension.lowercased()) {
                        await store.importFuelTable(data: data, filename: url.lastPathComponent)
                    } else if let image = UIImage(data: data) { images.append(image) }
                }
                await store.importImages(images)
            } catch { store.message = error.localizedDescription }
        }
    }
}

private struct ChatMediaSaveButton: View {
    let mediaID: String
    let mediaType: String
    @State private var isSaving = false
    @State private var status = ""

    var body: some View {
        Button {
            guard !isSaving else { return }
            Task { await save() }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: isSaving ? "hourglass" : "square.and.arrow.down")
                Text(status.isEmpty ? (mediaType == "livePhoto" ? "保存实况" : mediaType == "video" ? "保存原视频" : "保存原图") : status)
            }
            .font(.caption2.weight(.semibold))
            .padding(.horizontal, 9)
            .padding(.vertical, 6)
            .foregroundStyle(Color.deepBlue)
            .background(Color.farPeakBlue.opacity(0.72), in: Capsule())
        }
        .buttonStyle(.plain)
        .disabled(isSaving)
    }

    private func save() async {
        guard await requestPhotoAccess() else {
            status = "需允许照片权限"
            return
        }
        isSaving = true
        defer { isSaving = false }
        do {
            let data: Data
            if let localData = LocalChatStore.mediaData(mediaID: mediaID) {
                data = localData
            } else {
                guard let session = UserDefaults.standard.string(forKey: "TravelBillSessionV1"), !session.isEmpty else {
                    status = "当前媒体尚未缓存，请先登录联网加载"
                    return
                }
                let (remoteData, _) = try await AuthAPI.mediaData(id: mediaID, session: session)
                data = remoteData
                LocalChatStore.saveMedia(remoteData, mediaID: mediaID)
            }
            if mediaType == "livePhoto" {
                try await saveLivePhotoArchive(data)
            } else if mediaType == "video" {
                try await saveVideo(data)
            } else {
                try await saveImage(data)
            }
            status = "已保存"
        } catch {
            status = "保存失败"
        }
    }

    private func requestPhotoAccess() async -> Bool {
        let status = await withCheckedContinuation { continuation in
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
                continuation.resume(returning: status)
            }
        }
        return status == .authorized || status == .limited
    }

    private func saveImage(_ data: Data) async throws {
        guard let image = UIImage(data: data) else { throw NSError(domain: "TravelBillMedia", code: 10) }
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetChangeRequest.creationRequestForAsset(from: image)
        }
    }

    private func saveVideo(_ data: Data) async throws {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("travel-bill-video-\(UUID().uuidString).mp4")
        defer { try? FileManager.default.removeItem(at: url) }
        try data.write(to: url, options: .atomic)
        try await PHPhotoLibrary.shared().performChanges {
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
        }
    }

    private func saveLivePhotoArchive(_ data: Data) async throws {
        let archive = try Archive(data: data, accessMode: .read, pathEncoding: nil)
        var photoData: Data?
        var videoData: Data?
        for entry in archive {
            var contents = Data()
            _ = try archive.extract(entry) { contents.append($0) }
            if entry.path.lowercased().hasSuffix(".mov") || entry.path.lowercased().hasSuffix(".mp4") {
                videoData = contents
            } else if entry.path.lowercased().hasSuffix(".heic") || entry.path.lowercased().hasSuffix(".heif") || entry.path.lowercased().hasSuffix(".jpg") || entry.path.lowercased().hasSuffix(".jpeg") {
                photoData = contents
            }
        }
        guard let photoData, let videoData else { throw NSError(domain: "TravelBillMedia", code: 11) }
        let photoURL = FileManager.default.temporaryDirectory.appendingPathComponent("travel-bill-live-\(UUID().uuidString).heic")
        let videoURL = FileManager.default.temporaryDirectory.appendingPathComponent("travel-bill-live-\(UUID().uuidString).mov")
        defer {
            try? FileManager.default.removeItem(at: photoURL)
            try? FileManager.default.removeItem(at: videoURL)
        }
        try photoData.write(to: photoURL, options: .atomic)
        try videoData.write(to: videoURL, options: .atomic)
        try await PHPhotoLibrary.shared().performChanges {
            let request = PHAssetCreationRequest.forAsset()
            request.addResource(with: .photo, fileURL: photoURL, options: nil)
            request.addResource(with: .pairedVideo, fileURL: videoURL, options: nil)
        }
    }
}

private struct ExpenseEditorRow: View {
    @EnvironmentObject private var store: BillStore
    @Binding var entry: ExpenseEntry
    @State private var itemTask: Task<Void, Never>?

    private var dateBinding: Binding<Date> {
        Binding(get: { DateText.date(from: entry.date) ?? Date() }, set: { entry.date = DateText.isoDate($0); store.updateEntry(entry) })
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 8) {
                MonthDayPicker(date: dateBinding)
                Picker("分类", selection: $entry.category) {
                    ForEach(ExpenseCategory.allCases) { Text($0.rawValue).tag($0) }
                }
                .pickerStyle(.menu)
                .tint(Color.ink)
                .onChange(of: entry.category) { _, category in store.setCategory(id: entry.id, category: category) }
                Spacer()
                Button(role: .destructive) { store.deleteEntry(id: entry.id) } label: { Image(systemName: "trash") }
            }
            TextField("项目", text: $entry.item)
                .font(.body)
                .onChange(of: entry.item) { _, item in
                    store.updateEntry(entry)
                    itemTask?.cancel()
                    itemTask = Task {
                        try? await Task.sleep(for: .milliseconds(550))
                        if !Task.isCancelled { store.reclassifyEntry(id: entry.id, item: item) }
                    }
                }
            HStack {
                Text("¥").foregroundStyle(.secondary)
                TextField("金额", value: $entry.amount, format: .number.precision(.fractionLength(0...2)))
                    .keyboardType(.decimalPad)
                    .onChange(of: entry.amount) { _, _ in store.updateEntry(entry) }
                Spacer()
                if entry.needsReview { Label("待确认", systemImage: "exclamationmark.circle.fill").font(.caption2).foregroundStyle(.orange) }
            }
            if !store.participants.isEmpty {
                SplitEditor(entry: $entry)
            }
            if let fuelID = entry.fuelID, let record = store.fuelRecords.first(where: { $0.id == fuelID }) {
                FuelControls(record: record)
            } else if !entry.reason.isEmpty {
                Text(entry.reason).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            }
        }
        .padding(12)
        .background(Color(hex: entry.category.paleHex).opacity(0.72), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(entry.needsReview ? Color.orange.opacity(0.55) : Color.clear))
    }
}

private struct SplitEditor: View {
    @EnvironmentObject private var store: BillStore
    @Binding var entry: ExpenseEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 8) {
                Text("分账").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                Picker("分账方式", selection: Binding(get: { entry.splitMode }, set: { store.setSplitMode(id: entry.id, mode: $0) })) {
                    ForEach(SplitMode.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                .pickerStyle(.menu)
                .tint(Color.ink)
                Spacer()
            }
            Text(SplitDetails.suggest(item: entry.item, category: entry.category).reason)
                .font(.caption2)
                .foregroundStyle(.secondary)
            if entry.splitMode == .all {
                if store.participants.isEmpty {
                    Text("请先填写姓名").font(.caption2).foregroundStyle(.orange)
                } else {
                    let count = store.participants.count
                    Text(String(format: "每人约 ¥%.2f（%d人）", entry.amount / Double(count), count))
                        .font(.caption2)
                        .foregroundStyle(Color.deepBlue)
                }
            } else if entry.splitMode == .selected {
                if store.participants.isEmpty {
                    Text("请先填写姓名").font(.caption2).foregroundStyle(.orange)
                } else {
                    splitPeople
                }
            } else if entry.splitMode == .custom {
                if store.participants.isEmpty {
                    Text("请先填写姓名").font(.caption2).foregroundStyle(.orange)
                } else {
                    customAmounts
                }
            }
            if let issue = SplitDetails.issue(for: entry, participants: store.participants) {
                Text(issue).font(.caption2).foregroundStyle(.orange)
            }
        }
        .padding(10)
        .background(Color.white.opacity(0.48), in: RoundedRectangle(cornerRadius: 12))
    }

    private var splitPeople: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(store.participants, id: \.self) { name in
                    Button {
                        store.toggleSplitParticipant(id: entry.id, name: name)
                    } label: {
                        Text(name)
                            .font(.caption2)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 5)
                            .background(entry.splitParticipants.contains(name) ? Color.farPeakBlue : Color.field, in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var customAmounts: some View {
        VStack(spacing: 6) {
            ForEach(store.participants, id: \.self) { name in
                HStack {
                    Text(name).font(.caption2)
                    Spacer()
                    Text("¥").foregroundStyle(.secondary)
                    TextField("0.00", value: Binding(get: { entry.splitAmounts[name] ?? 0 }, set: { store.setSplitAmount(id: entry.id, name: name, amount: $0) }), format: .number.precision(.fractionLength(0...2)))
                        .keyboardType(.decimalPad)
                        .multilineTextAlignment(.trailing)
                        .frame(width: 88)
                }
            }
        }
    }
}

private struct FuelControls: View {
    @EnvironmentObject private var store: BillStore
    let record: FuelRecord
    private let provinces = ["北京", "上海", "浙江", "江苏", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "广西", "海南", "重庆", "四川", "贵州", "云南", "陕西", "甘肃", "青海", "宁夏", "新疆", "西藏", "河北", "山西", "辽宁", "吉林", "黑龙江", "内蒙古"]

    var body: some View {
        HStack(spacing: 8) {
            Menu(record.province.isEmpty ? "选择省份" : record.province) {
                ForEach(provinces, id: \.self) { province in
                    Button(province) { Task { await store.refreshFuel(id: record.id, province: province, grade: record.grade) } }
                }
            }
            Menu(record.grade) {
                ForEach(["92#", "95#", "98#"], id: \.self) { grade in
                    Button(grade) { Task { await store.refreshFuel(id: record.id, province: record.province, grade: grade) } }
                }
            }
            Spacer()
            Text(record.price > 0 ? String(format: "¥%.2f/L", record.price) : "油价待确认").font(.caption2).foregroundStyle(.secondary)
        }
        .font(.caption.weight(.semibold))
    }
}

private struct CameraPicker: UIViewControllerRepresentable {
    let completion: (UIImage?) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let completion: (UIImage?) -> Void
        init(completion: @escaping (UIImage?) -> Void) { self.completion = completion }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            completion(info[.originalImage] as? UIImage); picker.dismiss(animated: true)
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { completion(nil); picker.dismiss(animated: true) }
    }
}

private struct MonthDayPicker: View {
    @Binding var date: Date
    @State private var presented = false

    var body: some View {
        Button { presented = true } label: {
            HStack(spacing: 6) {
                Text(DateText.display(DateText.isoDate(date)))
                Image(systemName: "chevron.down").font(.caption2.weight(.bold)).foregroundStyle(.secondary)
            }
            .foregroundStyle(Color.ink)
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $presented) {
            NavigationStack {
                DatePicker("选择日期", selection: $date, displayedComponents: .date)
                    .datePickerStyle(.graphical)
                    .padding()
                    .navigationTitle("选择日期")
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { presented = false } } }
            }
            .presentationDetents([.medium])
        }
    }
}

@MainActor
private final class ChatVoiceRecorder: NSObject, ObservableObject {
    @Published private(set) var isRecording = false
    private var recorder: AVAudioRecorder?
    private var recordingURL: URL?

    func start() {
        guard recorder == nil else { return }
        let session = AVAudioSession.sharedInstance()
        switch AVAudioApplication.shared.recordPermission {
        case .denied:
            return
        case .undetermined:
            AVAudioApplication.requestRecordPermission { [weak self] granted in
                guard granted else { return }
                Task { @MainActor in self?.start() }
            }
            return
        case .granted:
            break
        @unknown default:
            return
        }
        do {
            try session.setCategory(.record, mode: .spokenAudio, options: [.allowBluetoothHFP])
            try session.setActive(true, options: .notifyOthersOnDeactivation)
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("travel-bill-voice-\(UUID().uuidString).m4a")
            let recorder = try AVAudioRecorder(url: url, settings: [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44_100,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
            ])
            recorder.prepareToRecord()
            recorder.record()
            self.recorder = recorder
            recordingURL = url
            isRecording = true
        } catch {
            try? session.setActive(false, options: .notifyOthersOnDeactivation)
        }
    }

    func finish() -> Data? {
        guard let recorder, isRecording else { return nil }
        recorder.stop()
        self.recorder = nil
        isRecording = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        guard let recordingURL else { return nil }
        defer {
            try? FileManager.default.removeItem(at: recordingURL)
            self.recordingURL = nil
        }
        return try? Data(contentsOf: recordingURL)
    }
}

private extension Color {
    static let farPeakBlue = Color(lightHex: "C1F2FB", darkHex: "1E4C59")
    static let deepBlue = Color(lightHex: "4F8390", darkHex: "8ADBEA")
    static let appBackground = Color(lightHex: "F5FBFC", darkHex: "000000")
    static let field = Color(lightHex: "F2F7F8", darkHex: "151B1E")
    static let ink = Color(lightHex: "263D44", darkHex: "F2F7F8")

    init(lightHex: String, darkHex: String) {
        self.init(uiColor: UIColor { traits in
            let hex = traits.userInterfaceStyle == .dark ? darkHex : lightHex
            let value = UInt64(hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted), radix: 16) ?? 0
            return UIColor(
                red: CGFloat((value >> 16) & 0xFF) / 255,
                green: CGFloat((value >> 8) & 0xFF) / 255,
                blue: CGFloat(value & 0xFF) / 255,
                alpha: 1
            )
        })
    }

    init(hex: String) {
        self.init(lightHex: hex, darkHex: hex)
    }
}
