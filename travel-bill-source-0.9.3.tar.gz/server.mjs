import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import express from "express";
import multer from "multer";
import { buildWorkbook, readFuelWorkbook, verifyWorkbookBuffer } from "./lib/excel.mjs";
import { deduplicateOcrResults, recognizeImage } from "./lib/ocr.mjs";
import { inferTrip } from "./lib/trip.mjs";
import { formatTransportItem } from "./lib/transport-details.mjs";
import { classifyItemsWithWeb } from "./lib/web-classifier.mjs";
import { authRequired, createSession, normalizeLoginIdentifier, requestSupabaseEmailOtp, resolveAppleIdentity, sessionUserId, verifySupabaseEmailOtp } from "./lib/auth.mjs";
import { acknowledgeDirectMessage, acknowledgeGroupMessage, archivePersonalTrip, claimPairing, consumePairing, createDirectMessage, createExpense, createGroup, createGroupMessage, createInvite, createMedia, createOtpChallenge, createPairing, createPersonalExpense, createPersonalTrip, deleteExpense, deleteMedia, deletePersonalExpense, findOrCreateUser, findUser, getFootprints, getGroup, getMediaFile, getPersonalTrip, joinGroup, listDirectMessages, listFriends, listGroupMedia, listGroupMessages, listGroups, listPersonalTrips, otpIsDevelopmentMode, publicUser, setUserAvatar, updateExpense, updatePersonalExpense, verifyOtpChallenge } from "./lib/account-store.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
process.chdir(__dirname);

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 30 },
});
const mediaIncomingDirectory = path.join(__dirname, "data", "media", ".incoming");
await fs.mkdir(mediaIncomingDirectory, { recursive: true });
const mediaUpload = multer({
  storage: multer.diskStorage({
    destination: mediaIncomingDirectory,
    filename: (_req, file, callback) => callback(null, `${Date.now()}-${randomUUID()}`),
  }),
  limits: { fileSize: 250 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, callback) => callback(null, /^(image|video|audio)\//i.test(file.mimetype) || /zip/i.test(file.mimetype || "") || /\.zip$/i.test(file.originalname || "")),
});
const port = Number(process.env.PORT) || 4173;
const host = process.env.HOST || "127.0.0.1";
let oilPriceCache = null;
const pairingClaimAttempts = new Map();
const pairingClaimWindowMs = 5 * 60 * 1000;
const pairingClaimMaxAttempts = 8;

function allowPairingClaim(userId) {
  const now = Date.now();
  const recent = (pairingClaimAttempts.get(userId) || []).filter((timestamp) => now - timestamp < pairingClaimWindowMs);
  if (recent.length >= pairingClaimMaxAttempts) {
    pairingClaimAttempts.set(userId, recent);
    return false;
  }
  recent.push(now);
  pairingClaimAttempts.set(userId, recent);
  return true;
}

function clearPairingClaims(userId) {
  pairingClaimAttempts.delete(userId);
}

app.use(express.json({ limit: "8mb" }));
// 网页端已停用。macOS App 仍通过内嵌 WKWebView 使用同一套本地资源，
// 但普通 Safari/Chrome 访问根页面和静态资源时不再提供网页界面。
app.use((req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  if (String(req.headers["user-agent"] || "").startsWith("TravelBillMacApp/")) return next();
  res.status(410).type("text").send("网页端已停用，请打开旅迹账单 macOS App。\n");
});
app.use(express.static(path.join(__dirname, "public")));
app.get("/split-details.mjs", (_req, res) => res.sendFile(path.join(__dirname, "lib/split-details.mjs"), { headers: { "Content-Type": "text/javascript; charset=utf-8" } }));

app.get("/api/health", (_req, res) => {
  const appleConfigured = Boolean(process.env.APPLE_CLIENT_ID || process.env.APPLE_SERVICE_ID);
  const otpProvider = String(process.env.TRAVEL_BILL_OTP_PROVIDER || "").toLowerCase();
  const productionAuthConfigured = appleConfigured || otpProvider === "supabase";
  const cloudStateConfigured = process.env.TRAVEL_BILL_STATE_STORE !== "supabase" || Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);
  const cloudMediaConfigured = process.env.TRAVEL_BILL_STATE_STORE !== "supabase" || (process.env.TRAVEL_BILL_MEDIA_STORE === "supabase" && Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY));
  const authSecretConfigured = process.env.NODE_ENV !== "production" || Boolean(process.env.TRAVEL_BILL_AUTH_SECRET);
  const productionReady = process.env.NODE_ENV !== "production" || (productionAuthConfigured && cloudStateConfigured && cloudMediaConfigured && authSecretConfigured);
  const payload = {
    ok: productionReady,
    version: "0.9.3",
    auth: { appleConfigured, otpProvider, productionAuthConfigured, developmentMode: process.env.APPLE_AUTH_MODE !== "production" && otpProvider !== "supabase" },
    storage: { state: process.env.TRAVEL_BILL_STATE_STORE === "supabase" ? "supabase" : "local", media: process.env.TRAVEL_BILL_MEDIA_STORE === "supabase" ? "supabase" : "local" },
  };
  res.status(productionReady ? 200 : 503).json(payload);
});

app.get("/api/auth/config", (_req, res) => res.json({
  appleConfigured: Boolean(process.env.APPLE_CLIENT_ID || process.env.APPLE_SERVICE_ID),
  appleWebConfigured: Boolean(process.env.APPLE_SERVICE_ID && process.env.APPLE_REDIRECT_URI),
  appleWebClientId: process.env.APPLE_SERVICE_ID || "",
  appleWebRedirectURI: process.env.APPLE_REDIRECT_URI || "",
  otpEnabled: true,
  otpProvider: String(process.env.TRAVEL_BILL_OTP_PROVIDER || "").toLowerCase(),
  otpEmailOnly: String(process.env.TRAVEL_BILL_OTP_PROVIDER || "").toLowerCase() === "supabase",
  otpDevelopmentMode: otpIsDevelopmentMode(),
}));

app.get("/api/auth/me", async (req, res) => {
  const user = await findUser(sessionUserId(req));
  if (!user) return res.status(401).json({ error: "请先登录" });
  return res.json({ user: publicUser(user) });
});

app.get("/api/friends", authRequired, async (req, res, next) => {
  try { res.json({ friends: await listFriends(req.userId) }); } catch (error) { next(error); }
});

app.post("/api/auth/dev-login", async (req, res, next) => {
  try {
    if (process.env.NODE_ENV === "production" || process.env.TRAVEL_BILL_DISABLE_DEV_AUTH === "1") return res.status(404).json({ error: "开发登录已关闭" });
    const displayName = String(req.body?.displayName || "旅伴").trim();
    if (!displayName) return res.status(400).json({ error: "请输入姓名" });
    const user = await findOrCreateUser({ provider: "development", providerSubject: displayName.toLowerCase(), displayName });
    res.json({ session: createSession(user.id), user: publicUser(user), development: true });
  } catch (error) { next(error); }
});

app.post("/api/auth/request-code", async (req, res, next) => {
  try {
    const identifier = normalizeLoginIdentifier(req.body?.identifier);
    if (!identifier) return res.status(400).json({ error: "请输入有效的邮箱或手机号" });
    if (String(process.env.TRAVEL_BILL_OTP_PROVIDER || "").toLowerCase() === "supabase") return res.json(await requestSupabaseEmailOtp(identifier));
    res.json(await createOtpChallenge(req.body.identifier));
  } catch (error) {
    if (/请输入|尚未配置|过多/.test(error.message || "")) return res.status(400).json({ error: error.message });
    next(error);
  }
});

app.post("/api/auth/verify-code", async (req, res, next) => {
  try {
    const identifier = normalizeLoginIdentifier(req.body?.identifier);
    if (!identifier) return res.status(400).json({ error: "请输入有效的邮箱或手机号" });
    let user;
    if (String(process.env.TRAVEL_BILL_OTP_PROVIDER || "").toLowerCase() === "supabase") {
      const verified = await verifySupabaseEmailOtp({ email: identifier.value, code: req.body?.code });
      if (!verified.user?.id) throw new Error("云端验证码验证未返回账号");
      user = await findOrCreateUser({ provider: "supabase", providerSubject: verified.user.id, email: verified.user.email || identifier.value, displayName: req.body?.displayName });
    } else {
      const verified = await verifyOtpChallenge({ challengeId: req.body?.challengeId, identifier: req.body.identifier, code: req.body?.code });
      user = await findOrCreateUser({ provider: "otp", providerSubject: verified.value, email: verified.type === "email" ? verified.value : "", displayName: req.body?.displayName });
    }
    res.json({ session: createSession(user.id), user: publicUser(user), development: otpIsDevelopmentMode() });
  } catch (error) {
    if (/验证码|邮箱|手机号|token|otp/i.test(error.message || "")) return res.status(400).json({ error: error.message });
    next(error);
  }
});

app.post("/api/auth/apple", async (req, res, next) => {
  try {
    const identity = await resolveAppleIdentity({ identityToken: req.body?.identityToken, appleSubject: req.body?.appleSubject, email: req.body?.email, displayName: req.body?.displayName });
    const user = await findOrCreateUser({ provider: "apple", providerSubject: identity.subject, email: identity.email, displayName: identity.displayName });
    res.json({ session: createSession(user.id), user: publicUser(user), development: process.env.APPLE_AUTH_MODE !== "production" });
  } catch (error) { next(error); }
});

app.post("/api/pairing/create", async (req, res, next) => {
  try { res.json(await createPairing({ deviceName: req.body?.deviceName })); } catch (error) { next(error); }
});

app.post("/api/pairing/claim", authRequired, async (req, res, next) => {
  try {
    const user = await findUser(req.userId);
    if (!user) return res.status(401).json({ error: "当前账号会话已失效，请退出后重新登录" });
    if (!allowPairingClaim(req.userId)) return res.status(429).json({ error: "配对码尝试次数过多，请 5 分钟后再试" });
    const claimed = await claimPairing(req.userId, String(req.body?.id || ""), String(req.body?.code || ""));
    if (claimed) clearPairingClaims(req.userId);
    res.status(claimed ? 200 : 404).json(claimed ? { ok: true } : { error: "配对码无效、已使用或已过期" });
  } catch (error) { next(error); }
});

app.get("/api/pairing/status", async (req, res, next) => {
  try {
    const userId = await consumePairing(String(req.query.id || ""), String(req.query.token || ""));
    if (!userId) return res.json({ status: "pending" });
    const user = await findUser(userId);
    res.json({ status: "claimed", session: createSession(userId), user: publicUser(user) });
  } catch (error) { next(error); }
});

app.get("/api/bills", authRequired, async (req, res, next) => {
  try { res.json({ groups: await listGroups(req.userId) }); } catch (error) { next(error); }
});

app.post("/api/bills", authRequired, async (req, res, next) => {
  try {
    const created = await createGroup(req.userId, req.body || {});
    const group = await getGroup(req.userId, created.id);
    res.status(201).json({ group });
  } catch (error) { next(error); }
});

app.get("/api/personal/trips", authRequired, async (req, res, next) => {
  try { res.json({ trips: await listPersonalTrips(req.userId, req.query.q || "") }); } catch (error) { next(error); }
});

app.post("/api/personal/trips", authRequired, async (req, res, next) => {
  try { res.status(201).json({ trip: await createPersonalTrip(req.userId, req.body || {}) }); } catch (error) { next(error); }
});

app.get("/api/personal/trips/:tripId", authRequired, async (req, res, next) => {
  try {
    const trip = await getPersonalTrip(req.userId, req.params.tripId);
    if (!trip) return res.status(404).json({ error: "个人旅程不存在或无权访问" });
    res.json({ trip });
  } catch (error) { next(error); }
});

app.delete("/api/personal/trips/:tripId", authRequired, async (req, res, next) => {
  try {
    const archived = await archivePersonalTrip(req.userId, req.params.tripId);
    if (!archived) return res.status(404).json({ error: "个人旅程不存在或无权删除" });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post("/api/personal/trips/:tripId/expenses", authRequired, async (req, res, next) => {
  try {
    const expense = await createPersonalExpense(req.userId, req.params.tripId, req.body || {});
    if (!expense) return res.status(404).json({ error: "个人旅程不存在或无权访问" });
    res.status(201).json({ expense });
  } catch (error) { next(error); }
});

app.delete("/api/personal/trips/:tripId/expenses/:expenseId", authRequired, async (req, res, next) => {
  try {
    const deleted = await deletePersonalExpense(req.userId, req.params.tripId, req.params.expenseId);
    if (!deleted) return res.status(404).json({ error: "费用不存在或无权删除" });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.put("/api/personal/trips/:tripId/expenses/:expenseId", authRequired, async (req, res, next) => {
  try {
    const expense = await updatePersonalExpense(req.userId, req.params.tripId, req.params.expenseId, req.body || {});
    if (!expense) return res.status(404).json({ error: "费用不存在或无权修改" });
    res.json({ expense });
  } catch (error) { next(error); }
});

app.get("/api/bills/:groupId", authRequired, async (req, res, next) => {
  try {
    const group = await getGroup(req.userId, req.params.groupId);
    if (!group) return res.status(404).json({ error: "账单组不存在或无权访问" });
    res.json({ group });
  } catch (error) { next(error); }
});

app.get("/api/bills/:groupId/media", authRequired, async (req, res, next) => {
  try {
    const media = await listGroupMedia(req.userId, req.params.groupId);
    if (!media) return res.status(404).json({ error: "账单组不存在或无权访问" });
    res.json({ media });
  } catch (error) { next(error); }
});

app.get("/api/bills/:groupId/messages", authRequired, async (req, res, next) => {
  try {
    const messages = await listGroupMessages(req.userId, req.params.groupId, req.query.q || "");
    if (!messages) return res.status(404).json({ error: "账单组不存在或无权访问" });
    res.json({ messages });
  } catch (error) { next(error); }
});

app.post("/api/bills/:groupId/messages", authRequired, async (req, res, next) => {
  try {
    const message = await createGroupMessage(req.userId, req.params.groupId, req.body || {});
    if (!message) return res.status(404).json({ error: "账单组不存在或无权访问" });
    res.status(201).json({ message });
  } catch (error) { next(error); }
});

app.post("/api/bills/:groupId/messages/:messageId/ack", authRequired, async (req, res, next) => {
  try {
    const acknowledged = await acknowledgeGroupMessage(req.userId, req.params.groupId, req.params.messageId);
    if (!acknowledged) return res.status(404).json({ error: "消息不存在或无权确认" });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get("/api/friends/:friendId/messages", authRequired, async (req, res, next) => {
  try {
    const messages = await listDirectMessages(req.userId, req.params.friendId, req.query.q || "");
    if (!messages) return res.status(404).json({ error: "好友不存在或暂未建立共同账单" });
    res.json({ messages });
  } catch (error) { next(error); }
});

app.post("/api/friends/:friendId/messages", authRequired, async (req, res, next) => {
  try {
    const message = await createDirectMessage(req.userId, req.params.friendId, req.body || {});
    if (!message) return res.status(404).json({ error: "好友不存在或暂未建立共同账单" });
    res.status(201).json({ message });
  } catch (error) { next(error); }
});

app.post("/api/friends/:friendId/messages/:messageId/ack", authRequired, async (req, res, next) => {
  try {
    const acknowledged = await acknowledgeDirectMessage(req.userId, req.params.friendId, req.params.messageId);
    if (!acknowledged) return res.status(404).json({ error: "消息不存在或无权确认" });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post("/api/friends/:friendId/media", authRequired, mediaUpload.single("file"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "请选择图片、视频或语音" });
    if (!(await listFriends(req.userId)).some((friend) => friend.id === req.params.friendId)) return res.status(404).json({ error: "好友不存在或暂未建立共同账单" });
    const media = await createMedia(req.userId, { tripKey: `direct:${req.params.friendId}`, visibility: "private", sharedWith: [req.params.friendId], mediaType: req.body?.mediaType, file: req.file, relayOnly: true });
    res.status(201).json({ media });
  } catch (error) { next(error); }
});

app.post("/api/bills/:groupId/media", authRequired, mediaUpload.single("file"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "请选择图片、视频或语音" });
    const media = await createMedia(req.userId, {
      groupId: req.params.groupId,
      tripKey: req.body?.tripKey,
      visibility: req.body?.visibility,
      mediaType: req.body?.mediaType,
      file: req.file,
      capturedAt: req.body?.capturedAt,
      latitude: req.body?.latitude,
      longitude: req.body?.longitude,
      locationName: req.body?.locationName,
      country: req.body?.country,
      region: req.body?.region,
      city: req.body?.city,
      locationSource: req.body?.locationSource,
      relayOnly: true,
    });
    if (!media) return res.status(404).json({ error: "账单组不存在或无权访问" });
    res.status(201).json({ media });
  } catch (error) { next(error); }
});

app.post("/api/bills/:groupId/invites", authRequired, async (req, res, next) => {
  try {
    const invite = await createInvite(req.userId, req.params.groupId);
    if (!invite) return res.status(404).json({ error: "账单组不存在或无权邀请" });
    res.status(201).json({ invite });
  } catch (error) { next(error); }
});

app.post("/api/bills/join", authRequired, async (req, res, next) => {
  try {
    const joined = await joinGroup(req.userId, req.body?.code);
    if (!joined) return res.status(404).json({ error: "邀请码无效或已过期" });
    const group = await getGroup(req.userId, joined.id);
    res.json({ group });
  } catch (error) { next(error); }
});

app.post("/api/account/avatar", authRequired, mediaUpload.single("file"), async (req, res, next) => {
  try {
    if (!req.file || !String(req.file.mimetype || "").startsWith("image/")) return res.status(400).json({ error: "请选择头像图片" });
    const media = await createMedia(req.userId, { tripKey: "avatar", visibility: "private", file: req.file });
    const user = await setUserAvatar(req.userId, media.id);
    res.status(201).json({ media, user });
  } catch (error) { next(error); }
});

app.get("/api/footprints", authRequired, async (req, res, next) => {
  try { res.json(await getFootprints(req.userId)); } catch (error) { next(error); }
});

app.get("/api/media/:mediaId/file", authRequired, async (req, res, next) => {
  try {
    const result = await getMediaFile(req.userId, req.params.mediaId);
    if (!result) return res.status(404).json({ error: "媒体不存在或无权访问" });
    res.type(result.asset.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename*=UTF-8''${encodeURIComponent(result.asset.originalName || "media")}`);
    res.send(result.data);
  } catch (error) { next(error); }
});

app.delete("/api/media/:mediaId", authRequired, async (req, res, next) => {
  try {
    const deleted = await deleteMedia(req.userId, req.params.mediaId);
    if (!deleted) return res.status(404).json({ error: "媒体不存在或无权删除" });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post("/api/bills/:groupId/expenses", authRequired, async (req, res, next) => {
  try {
    const expense = await createExpense(req.userId, req.params.groupId, req.body || {});
    if (!expense) return res.status(404).json({ error: "账单组不存在或无权访问" });
    res.status(201).json({ expense });
  } catch (error) { next(error); }
});

app.delete("/api/bills/:groupId/expenses/:expenseId", authRequired, async (req, res, next) => {
  try {
    const deleted = await deleteExpense(req.userId, req.params.groupId, req.params.expenseId);
    if (!deleted) return res.status(404).json({ error: "费用不存在或无权删除" });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.put("/api/bills/:groupId/expenses/:expenseId", authRequired, async (req, res, next) => {
  try {
    const expense = await updateExpense(req.userId, req.params.groupId, req.params.expenseId, req.body || {});
    if (!expense) return res.status(404).json({ error: "费用不存在或无权修改" });
    res.json({ expense });
  } catch (error) { next(error); }
});

app.post("/api/classify", async (req, res, next) => {
  try {
  const items = Array.isArray(req.body?.items) ? req.body.items.map(String) : [];
    res.json({ results: await classifyItemsWithWeb(items, req.body?.learned || {}) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/infer-trip", (req, res) => {
  const entries = Array.isArray(req.body?.entries) ? req.body.entries : [];
  const fuelRows = Array.isArray(req.body?.fuelRows) ? req.body.fuelRows : [];
  res.json(inferTrip(entries, fuelRows));
});

app.post("/api/ocr", upload.array("images", 30), async (req, res, next) => {
  try {
    if (!req.files?.length) return res.status(400).json({ error: "请选择图片" });
    const learned = req.body.learned ? JSON.parse(req.body.learned) : {};
    const results = [];
    for (const file of req.files) {
      const result = await recognizeImage(file, learned);
      if (result.kind === "expense" && result.entries?.length) {
        const classified = await classifyItemsWithWeb(result.entries.map((entry) => entry.item), learned);
        result.entries = result.entries.map((entry, index) => ({
          ...entry,
          ...(entry.reason?.startsWith("图片账单标注为") || entry.classificationSource === "image-context" ? {} : {
            category: classified[index].category,
            confidence: classified[index].confidence,
            reason: classified[index].reason,
            webLookup: classified[index].webLookup,
          }),
          item: formatTransportItem(entry.item, entry.category),
        }));
      }
      results.push(result);
    }
    res.json(deduplicateOcrResults(results));
  } catch (error) {
    next(error);
  }
});

app.post("/api/fuel-import", upload.single("file"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "请选择油耗表" });
    const rows = await readFuelWorkbook(req.file.buffer, req.file.originalname);
    res.json({ rows });
  } catch (error) {
    next(error);
  }
});

async function fetchOilPriceTable() {
  if (oilPriceCache?.expiresAt > Date.now()) return oilPriceCache.value;
  try {
    const response = await fetch("https://v1.apizero.cn/api/oil-price-forecast?action=price-all", { signal: AbortSignal.timeout(8000) });
    const payload = await response.json();
    if (!response.ok || payload.code !== 0 || !payload.data?.prices) throw new Error(payload.message || "全国油价接口返回异常");
    const value = {
      date: new Date().toISOString().slice(0, 10),
      source: "极数本源全国油价",
      note: payload.data.note || "参考价，实际以加油站挂牌价为准",
      table: payload.data.prices,
    };
    oilPriceCache = { value, expiresAt: Date.now() + 6 * 60 * 60 * 1000 };
    return value;
  } catch (primaryError) {
    const response = await fetch("https://v2.xxapi.cn/api/oilPrice", { signal: AbortSignal.timeout(8000) });
    const payload = await response.json();
    if (!response.ok || payload.code !== 200 || !Array.isArray(payload.data)) throw primaryError;
    const table = Object.fromEntries(payload.data.map((row) => [String(row.province || "").replace(/[省市]$/, ""), {
      92: Number(row.n92), 95: Number(row.n95), 98: Number(row.n98), 0: Number(row.n0),
    }]));
    const value = {
      date: payload.date || new Date().toISOString().slice(0, 10),
      source: "小小API全国油价",
      note: "参考价，实际以加油站挂牌价为准",
      table,
    };
    oilPriceCache = { value, expiresAt: Date.now() + 3 * 60 * 60 * 1000 };
    return value;
  }
}

app.post("/api/oil-price", async (req, res, next) => {
  try {
    const province = String(req.body?.province || "").trim().replace(/[省市]$/, "");
    if (!province) return res.status(400).json({ error: "请先填写省份" });
    const data = await fetchOilPriceTable();
    const prices = data.table[province] || data.table[`${province}省`] || data.table[`${province}市`];
    if (!prices) return res.status(404).json({ error: `暂未查到${province}油价，请稍后重试或手动填写` });
    res.json({
      province,
      date: data.date,
      source: data.source,
      note: data.note,
      prices: { 92: Number(prices[92]), 95: Number(prices[95]), 98: Number(prices[98]) },
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/export", async (req, res, next) => {
  try {
    const entries = Array.isArray(req.body?.entries) ? req.body.entries : [];
    if (!entries.length) return res.status(400).json({ error: "请至少加入一条费用" });
    const { buffer, filename } = await buildWorkbook({
      entries,
      fuelRows: Array.isArray(req.body.fuelRows) ? req.body.fuelRows : [],
      participants: Array.isArray(req.body.participants) ? req.body.participants.map(String).map((name) => name.trim()).filter(Boolean) : [],
      personalUserId: String(req.body?.personalUserId || ""),
      personalName: String(req.body?.personalName || ""),
    });
    const verification = await verifyWorkbookBuffer(buffer);
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    res.setHeader("X-Travel-Bill-Verified", verification.ok ? "ok" : "failed");
    res.setHeader("X-Travel-Bill-Charts", String(verification.charts));
    res.send(buffer);
  } catch (error) {
    next(error);
  }
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: error.message || "程序处理失败" });
});

app.listen(port, host, () => {
  const url = `http://${host}:${port}`;
  console.log(`旅迹账单 App 预览已启动：${url}`);
  // macOS App 使用内嵌 WKWebView；服务默认不再唤起 Safari/Chrome。
  // 如需网页调试，必须显式设置 AUTO_OPEN=1。
  if (process.env.AUTO_OPEN === "1") execFile("open", [url]);
});
